import React from 'react'

export default function Content10() {
    return (
        <section id="content-10" className="content-10 pb-100 content-section division">
            <div className="container">


                { //<!-- SECTION TITLE -->	
                }
                <div className="row justify-content-center">
                    <div className="col-md-10 col-lg-8">
                        <div className="section-title title-02 mb-60">

                            { //<!-- Section ID -->	
                            }
                            <span className="section-id txt-upcase">Your road to success</span>

                            { //<!-- Title -->	
                            }
                            <h2 className="h2-xs">Marketing solutions that fuel your business growth</h2>

                            { //<!-- Text -->	
                            }
                            <p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque at dolor primis libero
                                tempus, blandit and cursus varius and magnis sapien
                            </p>

                        </div>
                    </div>
                </div>


                { //<!-- IMAGE BLOCK -->	
                }
                <div className="row">
                    <div className="col">
                        <div className="img-block text-center video-preview">

                            { //<!-- Play Icon -->	
                            }
                            <a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
                                <div className="video-btn video-btn-xl bg-green ico-90">
                                    <div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
                                </div>
                            </a>

                            { //<!-- Preview Image -->	
                            }
                            <img className="img-fluid" src="images/seo-07.png" alt="video-preview" />

                        </div>
                    </div>
                </div>


                { //<!-- ADVANTAGES LIST -->	
                }
                <div className="row">
                    <div className="col">
                        <div className="content-10-btn">
                            <ul className="advantages mt-25 clearfix">
                                <li className="first-li"><p>Free 30 days trial</p></li>
                                <li><p>Exclusive Support</p></li>
                                <li className="last-li"><p>No Fees</p></li>
                            </ul>
                        </div>
                    </div>
                </div>


            </div>	   { //<!-- End container -->	
            }
        </section>
    )
}
