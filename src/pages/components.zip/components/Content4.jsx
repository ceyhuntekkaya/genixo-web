import React from 'react'

export default function Content4() {
    return (
        <section id="content-4" className="content-4 pt-80 content-section">
            <div className="bg-inner bg-whitesmoke-gradient division">
                <div className="container">
                    <div className="row d-flex align-items-center">

                        <div className="col-md-5 col-lg-6 order-end order-md-2">
                            <div className="content-4-img left-column wow fadeInRight">
                                <img className="img-fluid" src="images/img-01.png" alt="content-image" />
                            </div>
                        </div>
                        <div className="col-md-7 col-lg-6 order-first order-md-2">
                            <div className="txt-block right-column wow fadeInLeft">
                                <h2 className="h2-xs">Unlimited calling, texting and picture messaging</h2>
                                <p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
                                    laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
                                </p>
                                <div className="btns-group mb-30">
                                    <a href="download.html" className="btn btn-orange-red tra-orange-red-hover mr-15">Let's Get Started</a>
                                    <a href="pricing.html" className="btn btn-tra-grey tra-orange-red-hover">View Pricing</a>
                                </div>
                                <ul className="advantages clearfix">
                                    <li className="first-li"><p>Free 14 days trial</p></li>
                                    <li><p>Exclusive Support</p></li>
                                    <li className="last-li"><p>No Fees</p></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
