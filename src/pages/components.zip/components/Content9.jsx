import React from 'react'

export default function Content9() {
    return (
        <section id="content-9" className="content-9 bg-01 pt-100 content-section division">
            <div className="container white-color">


                <div className="row justify-content-center">
                    <div className="col-md-10 col-lg-8">
                        <div className="section-title title-02 mb-60">
                            <h2 className="h2-xs">Discover powerful features to boost your productivity</h2>
                        </div>
                    </div>
                </div>


                <div className="row">
                    <div className="col">
                        <div className="content-9-img video-preview wow fadeInUp">

                            <a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
                                <div className="video-btn video-btn-xl bg-orange-red ico-90">
                                    <div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
                                </div>
                            </a>

                            <img className="img-fluid" src="images/dashboard-07.png" alt="video-preview" />

                        </div>
                    </div>
                </div>


            </div>
        </section>
    )
}
