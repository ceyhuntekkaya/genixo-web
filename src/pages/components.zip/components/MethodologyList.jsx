import React from 'react'

export default function MethodologyList() {
    return (
        <section id="features-8" className="wide-60 features-section division">
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-lg-10 col-xl-8">
                        <div className="section-title title-01 mb-70">
                            <h2 className="h2-md">Transparent Operation Methodology</h2>
                            <p className="p-xl">Transparent Operation Methodology
                            </p>
                        </div>
                    </div>
                </div>




                <div className="fbox-8-wrapper text-center">
                    <div className="row row-cols-1 row-cols-md-3">



                        <div className="col">
                            <div className="fbox-4 mb-10 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-21.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Discovery</h5>
                                <p className="p-l">The discovery phase is the first step we take when starting a process. The process is encountered, the data needs are determined. The detected data is collected.
                                </p>
                            </div>
                        </div>

                        <div className="col">
                            <div className="fbox-8 mb-40 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-21.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Analysis</h5>
                                <p className="p-lg">Process analysis is carried out using the collected data, so that the data is meaningful. 
                                </p>
                            </div>
                        </div>

                        <div className="col">
                            <div className="fbox-8 mb-40 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-21.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Projection</h5>
                                <p className="p-lg">A process projection is designed in the light of the analyzed data.
                                </p>
                            </div>
                        </div>

                        <div className="col">
                            <div className="fbox-8 mb-40 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-21.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Construction</h5>
                                <p className="p-lg">The designed process projection is implemented and the process is completed.
                                </p>
                            </div>
                        </div>

                        <div className="col">
                            <div className="fbox-8 mb-40 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-21.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Revision</h5>
                                <p className="p-lg">The completed process is subject to revision first by us and then by you.
                                </p>
                            </div>
                        </div>

                        <div className="col">
                            <div className="fbox-8 mb-40 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-21.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Improvement</h5>
                                <p className="p-lg">Improvements are made based on the determinations made after the revision.
                                </p>
                            </div>
                        </div>

                        <div className="col">
                            <div className="fbox-8 mb-40 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-21.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Management</h5>
                                <p className="p-lg">After the revision, what has been done in the whole process is managed safely.
                                </p>
                            </div>
                        </div>







                    </div>
                </div>
            </div>
        </section>
    )
}
