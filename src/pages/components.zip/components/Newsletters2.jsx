import React from 'react'

export default function Newsletters2() {
	return (
		<section id="newsletter-2" className="pt-60 pb-60 newsletter-section division">
			<div className="container">
				<div className="row d-flex align-items-center row-cols-1 row-cols-lg-2">


					<div className="col">
						<div className="newsletter-txt pr-20">
							<h3 className="h3-xs">Stay up to date with our news, ideas and updates</h3>
						</div>
					</div>


					<div className="col">
						<form className="newsletter-form">

							<div className="input-group">
								<input type="email" autoComplete="off" className="form-control" placeholder="Your email address" required id="s-email" />
								<span className="input-group-btn">
									<button type="submit" className="btn btn-violet-red black-hover">Subscribe Now</button>
								</span>
							</div>

							<label htmlFor="s-email" className="form-notification"></label>

						</form>
					</div>


				</div>
			</div>
		</section>
	)
}
