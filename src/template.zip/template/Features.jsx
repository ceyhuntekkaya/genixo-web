import React from 'react'
import Faq2 from './components/Faq2'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import TrialLink from './components/TrialLink'
import Features8 from './components/Features8'
import Reviews1 from './components/Reviews1'
import Brands from './components/Brands'
import Statistic2 from './components/Statistic2'
import Features4 from './components/Features4'

export default function Features() {
	return (
		<React.Fragment>
			<div id="page" className="page">
				<Header mainCssClass="header tra-menu navbar-dark" />
				{ //<!-- CONTENT-1

				}
				<section id="content-1" className="content-1 wide-60 inner-page-hero content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Pixel Perfect</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">We're making design better for everyone</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6 order-first order-md-2">
								<div className="rel img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-07.png" alt="content-image" />
								</div>
							</div>


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-1 -->	
				}
				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="bg-snow content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-09.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Totally Optimized</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">Work smarter with powerful features</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

										{ //<!-- Tools List -->	
										}
										<div className="tools-list ico-40 mt-30">

											{ //<!-- Text -->	
											}
											<h6 className="h6-xl">Technologies We Use:</h6>

											{ //<!-- Icons -->	
											}
											<span className="flaticon-html-5 text-black-50"></span>
											<span className="flaticon-css-3 text-black-50"></span>
											<span className="flaticon-wordpress-logo text-black-50"></span>
											<span className="flaticon-js text-black-50"></span>
											<span className="flaticon-diamond-1 text-black-50"></span>

										</div>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-lg-6 order-last order-lg-2">
									<div className="txt-block slim-column left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Advanced Performance Made Easy</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">The Complete Software Solution</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- CB WRAPPER -->	
								}
								<div className="col-lg-6 order-first order-lg-2">
									<div className="cb-wrapper">

										{ //<!-- CB HOLDER -->	
										}
										<div className="cb-holder wow fadeInLeft">

											{ //<!-- CB BOX #1 -->	
											}
											<div className="cb-single-box">
												<p className="p-lg cb-header">New Customers</p>
												<h2 className="h2-title-xs statistic-number"><sup>+</sup><span className="count-element">784</span></h2>
												<p className="p-md mt-5 ico-10">
													<span className="green-color"><span className="flaticon-"></span> 4.6%</span> vs last 7 days
												</p>
											</div>

											<hr className="divider" />

											{ //<!-- CB BOX #2 -->	
											}
											<div className="cb-single-box">
												<ul className="simple-list">
													<li className="list-item">
														<p className="p-md">Fringilla risus luctus mauris auctor and purus euismod purus</p>
													</li>

													<li className="list-item">
														<p className="p-md">Nemo ipsam volute turpis dolores ut quaerat sodales sapien</p>
													</li>
												</ul>
											</div>

											{ //<!-- CB BOX #3 -->	
											}
											<div className="cb-single-box cb-box-rounded bg-green white-color mt-25">
												<h4 className="h4-lg">98.245</h4>
												<p className="p-lg">Ligula risus auctor tempus</p>
											</div>

										</div>	{ //<!-- END CB HOLDER -->	
										}


										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-1">
											<img className="img-fluid" src="images/bg-shape-1.png" alt="content-image" />
										</div>

										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-2">
											<img className="img-fluid" src="images/bg-shape-2.png" alt="content-image" />
										</div>


									</div>
								</div>	{ //<!-- END CB WRAPPER -->	
								}


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}

<Features8/>
				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 bg-04 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column video-preview wow fadeInRight">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-pink ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/img-08.png" alt="video-preview" />

								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column white-color wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Fast Performance</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Make it simpler with Quick Commands</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}

				{ //<!-- TABS-2

				}
				<section id="tabs-2" className="wide-60 tabs-section division">
					<div className="container">
						<div className="row row-cols-1 row-cols-md-2 d-flex align-items-center">


							{ //<!-- TABS NAVIGATION -->	
							}
							<div className="col">
								<div className="tabs-nav clearfix">
									<ul className="tabs-1">


										{ //<!-- TAB-1 LINK -->	
										}
										<li className="tab-link current" data-tab="tab-1">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">Perfect Integration</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Semper lacus cursus porta feugiat primis a luctus ultrice tellus potenti
												neque dolor in primis
											</p>

										</li>

										{ //<!-- TAB-2 LINK -->	
										}
										<li className="tab-link" data-tab="tab-2">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">Speed Optimized</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Semper lacus cursus porta feugiat primis a luctus ultrice tellus potenti
												neque dolor in primis
											</p>

										</li>

										{ //<!-- TAB-3 LINK -->	
										}
										<li className="tab-link" data-tab="tab-3">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">Advanced Security</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Semper lacus cursus porta feugiat primis a luctus ultrice tellus potenti
												neque dolor in primis
											</p>

										</li>


									</ul>
								</div>
							</div>	{ //<!-- END TABS NAVIGATION -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col">
								<div className="img-block right-column wow fadeInLeft">
									<div className="tabs-content">

										{ //<!-- TAB #1 IMAGE -->	
										}
										<div id="tab-1" className="tab-content current">
											<img className="img-fluid" src="images/img-06.png" alt="tab-image" />
										</div>

										{ //<!-- TAB #2 IMAGE -->	
										}
										<div id="tab-2" className="tab-content">
											<img className="img-fluid" src="images/img-10.png" alt="tab-preview" />
										</div>

										{ //<!-- TAB #3 IMAGE -->	
										}
										<div id="tab-3" className="tab-content">
											<img className="img-fluid" src="images/img-14.png" alt="tab-image" />
										</div>


									</div>
								</div>
							</div>	{ //<!-- END IMAGE BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	    { //<!-- End container -->	
					}
				</section>	 { //<!-- END TABS-2 -->	
				}
				<Brands/>
				{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 wide-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Extremely Flexible</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Discover powerful features to boost your productivity</h2>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center video-preview wow fadeInUp">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-pink ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10 -->	
				}

				{ //<!-- FEATURES-4

				}
			<Features4/>
				
				<hr className="divider" />

				<Statistic2/>
				<hr className="divider" />
				<Reviews1/>
				{ //<!-- CONTENT-2A

				}
				<section id="content-2a" className="content-2 bg-lightgrey wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-05.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Handling With Ease</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">More productivity with less effort</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2A -->	
				}

				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-25">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Manage Everything in One Place</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Advanced Control and Privacy</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-04.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}
				<Faq2 />
				<TrialLink />
				<Footer1 mainCssClass="bg-lightgrey footer division" />
			</div>
		</React.Fragment>
	)
}
