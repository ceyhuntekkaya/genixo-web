import React from 'react'
import Footer1 from './components/Footer1'
import Header from './components/Header'

export default function LoginBoxed() {
	return (
		<React.Fragment>
			<div id="page" className="page">
				<section id="login-2" className="login-section division">
					<div className="container">
						<div className="row">
							<div className="col-md-8 col-lg-6 offset-md-2 offset-lg-3">
								<div className="login-page-logo">
									<img className="img-fluid" src="images/logo-01.png" alt="logo-image" />
								</div>
								<div className="register-form">
									<form name="signinform" className="row sign-in-form">
										<div className="col-md-12">
											<div className="register-form-title text-center">
												<h4 className="h4-lg">Welcome Back!</h4>
												<p className="p-xl">Log in to your account</p>
											</div>
										</div>
										<div className="col-md-12">
											<input className="form-control email" type="email" name="email" placeholder="example@example.com" />
										</div>
										<div className="col-md-12">
											<div className="wrap-input">
												<span className="btn-show-pass ico-20"><span className="flaticon-visible eye-pass"></span></span>
												<input className="form-control password" type="password" name="password" placeholder="Password" />
											</div>
										</div>
										<div className="col-md-12">
											<button type="submit" className="btn btn-md btn-skyblue tra-black-hover submit">Log In</button>
										</div>
										<div className="col-md-12">
											<div className="d-flex justify-content-around align-items-center form-data">
												<div className="form-check">
													<input type="checkbox" className="form-check-input" id="exampleCheck1" checked />
													<label className="form-check-label" for="exampleCheck1">Remember Me</label>
												</div>
												<p className="forgot-password"><a href="reset-password-2.html">Forgot your password?</a></p>
											</div>
										</div>
										<div className="col-md-12 text-center">
											<div className="login-separator">
												<span className="login-separator-txt">OR</span>
											</div>
										</div>
										<div className="col-md-12">
											<a href="#" className="btn btn-google ico-left mb-10">
												<img src="images/png-icons/google.png" alt="google-icon" /> Sign in with Google
											</a>
										</div>
										<div className="col-md-12">
											<a href="#" className="btn btn-facebook ico-left">
												<img src="images/png-icons/facebook.png" alt="google-icon" /> Sign in with Facebook
											</a>
										</div>
										<div className="col-md-12 text-center">
											<p className="create-account">
												Don't have an account? <a href="signup-2.html" className="skyblue-color">Sign up</a>
											</p>
										</div>
									</form>
								</div>
								<div className="sign-in-notice text-center">
									<p>By clicking “Log in”, you agree to our <a href="terms.html">Terms</a> and that you have read our
										<a href="terms.html"> Privacy Policy</a>
									</p>
								</div>
								<div className="sign-in-footer text-center">
									<p>Copyright 2021 OLMO. All Rights Reserved</p>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>
		</React.Fragment>
	)
}
