import React from 'react'
import Footer1 from './components/Footer1'
import Header from './components/Header'

export default function LoginImage() {
	return (
		<React.Fragment>



			<div id="page" className="page">


				<Header mainCssClass="header tra-menu navbar-dark reg-nav" />



				{ //<!-- SIGN IN PAGE

				}
				<section id="login-3" className="rel bg-fixed login-section division">
					<div className="container">
						<div className="row">


							{ //<!-- SIGN IN FORM -->	
							}
							<div className="col-lg-5">


								{ //<!-- REGISTER FORM -->	
								}
								<div className="register-form">
									<form name="signinform" className="row sign-in-form">

										{ //<!-- Title-->	
										}
										<div className="col-md-12">
											<div className="register-form-title">
												<h3 className="h3-xs">Log in to OLMO</h3>
												<p className="p-lg">Don't have an account? <a href="signup-3.html" className="skyblue-color">Sign up</a></p>
											</div>
										</div>

										{ //<!-- Form Input -->	
										}
										<div className="col-md-12">
											<input className="form-control email" type="email" name="email" placeholder="example@example.com" />
										</div>

										{ //<!-- Form Input -->	
										}
										<div className="col-md-12">
											<div className="wrap-input">
												<span className="btn-show-pass ico-20"><span className="flaticon-visible eye-pass"></span></span>
												<input className="form-control password" type="password" name="password" placeholder="Password" />
											</div>
										</div>

										{ //<!-- Form Submit Button -->	
										}
										<div className="col-md-12">
											<button type="submit" className="btn btn-md btn-skyblue tra-black-hover submit">Log In</button>
										</div>

										{ //<!-- Form Data  -->	
										}
										<div className="col-md-12">
											<div className="d-flex justify-content-around align-items-center form-data">

												{ //<!-- Checkbox -->	
												}
												<div className="form-check">
													<input type="checkbox" className="form-check-input" id="exampleCheck1" checked />
													<label className="form-check-label" for="exampleCheck1">Remember Me</label>
												</div>

												{ //<!-- Forgot Password Link -->	
												}
												<p className="forgot-password"><a href="reset-password-1.html">Forgot your password?</a></p>

											</div>
										</div>

										{ //<!-- Login Separator -->	
										}
										<div className="col-md-12 text-center">
											<div className="login-separator">
												<span className="login-separator-txt">OR</span>
											</div>
										</div>

										{ //<!-- Google Button -->	
										}
										<div className="col-md-12">
											<a href="#" className="btn btn-google ico-left mb-10">
												<img src="images/png-icons/google.png" alt="google-icon" /> Sign in with Google
											</a>
										</div>

										{ //<!-- Facebook Button -->	
										}
										<div className="col-md-12">
											<a href="#" className="btn btn-facebook ico-left">
												<img src="images/png-icons/facebook.png" alt="google-icon" /> Sign in with Facebook
											</a>
										</div>


									</form>
								</div>   { //<!-- END REGISTER FORM -->	
								}


								{ //<!-- SIGN IN PAGE FOOTER -->	
								}
								<div className="sign-in-footer text-center">
									<p>Copyright 2021 OLMO. All Rights Reserved</p>
								</div>


							</div>	{ //<!-- END SIGN IN FORM -->	
							}


							{ //<!-- SIGN IN IMAGE -->	
							}
							<div className="col-lg-7">
								<div className="login-3-img text-center">
									<img className="img-fluid" src="images/register.png" alt="register-image" />
								</div>
							</div>


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END SIGN IN PAGE -->	
				}




			</div>
		</React.Fragment>
	)
}
