import React from 'react'

export default function LoginSimple() {
	return (
		<React.Fragment>
			<div id="page" className="page">
				<section id="login-1" className="login-section division">
					<div className="container">
						<div className="row">
							<div className="col-md-8 col-lg-6 offset-md-2 offset-lg-3">
								<div className="register-form">
									<form name="signinform" className="row sign-in-form">
										<div className="col-md-12">
											<div className="register-form-title">
												<h3 className="h3-xs">Log in to OLMO</h3>
												<p className="p-lg">Don't have an account? <a href="signup-1.html" className="skyblue-color">Sign up</a></p>
											</div>
										</div>
										<div className="col-md-12">
											<input className="form-control email" type="email" name="email" placeholder="example@example.com" />
										</div>
										<div className="col-md-12">
											<div className="wrap-input">
												<span className="btn-show-pass ico-20"><span className="flaticon-visible eye-pass"></span></span>
												<input className="form-control password" type="password" name="password" placeholder="Password" />
											</div>
										</div>
										<div className="col-md-12">
											<button type="submit" className="btn btn-md btn-skyblue tra-black-hover submit">Log In</button>
										</div>
										<div className="col-md-12">
											<div className="d-flex justify-content-around align-items-center form-data">
												<div className="form-check">
													<input type="checkbox" className="form-check-input" id="exampleCheck1" checked />
													<label className="form-check-label" for="exampleCheck1">Remember Me</label>
												</div>
												<p className="forgot-password"><a href="reset-password-1.html">Forgot your password?</a></p>
											</div>
										</div>
										<div className="col-md-12">
											<div className="login-separator">
												<span className="login-separator-txt">OR</span>
											</div>
										</div>
										<div className="col-md-12">
											<a href="#" className="btn btn-google ico-left mb-10">
												<img src="images/png-icons/google.png" alt="google-icon" /> Sign in with Google
											</a>
										</div>
										<div className="col-md-12">
											<a href="#" className="btn btn-facebook ico-left">
												<img src="images/png-icons/facebook.png" alt="google-icon" /> Sign in with Facebook
											</a>
										</div>
									</form>
								</div>
								<div className="sign-in-notice text-center">
									<p>By clicking “Log in”, you agree to our <a href="terms.html">Terms</a> and that you have read our
										<a href="terms.html"> Privacy Policy</a>
									</p>
								</div>
								<div className="sign-in-footer text-center">
									<p>Copyright 2021 OLMO. All Rights Reserved</p>
								</div>
							</div>
						</div>	  
					</div>	  
				</section>	
			</div>
		</React.Fragment>
	)
}
