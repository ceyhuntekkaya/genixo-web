import React from 'react'
import Header from './components/Header'
import Loading from './components/Loading'
import Hero1 from './components/Hero1'
import Features2 from './components/Features2'
import Content2 from './components/Content2'
import Content5 from './components/Content5'
import Content3 from './components/Content3'
import Content2a from './components/Content2a'
import Footer1 from './components/Footer1'
import Features8 from './components/Features8'
import Content1 from './components/Content1'
import Content10 from './components/Content10'
import Reviews1 from './components/Reviews1'
import Content6 from './components/Content6'
import Content9 from './components/Content9'
import Statistic2 from './components/Statistic2'
import Faq2 from './components/Faq2'
import Content4 from './components/Content4'

export default function Page1() {
    return (
        <React.Fragment>
            {/* <Loading /> */}
            <div id="page" className="page">
                <Header mainCssClass="header tra-menu navbar-light" />
                <Hero1 />
                <Features2 />
                <hr className="divider" />
                <Content2 />
                <Content5 />
                <Content3 />
                <Content2a />
                <Features8 />
                <Content1 />
                <Content10 />
                <Reviews1 />
                <Content6 />
                <Content9 />
                <Statistic2 />
                <Faq2 />
                <hr className="divider" />
                <Content4 />
                <Footer1 mainCssClass="footer division" />
            </div>
        </React.Fragment>
    )
}
