import React from 'react'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Features8 from './components/Features8'
import Reviews1 from './components/Reviews1'
import Statistic2 from './components/Statistic2'
import Features4 from './components/Features4'

export default function Page11() {
	return (
		<React.Fragment>


			<div id="page" className="page">





				<Header mainCssClass="header tra-menu navbar-dark" />





				{ //<!-- HERO-11

				}
				<section id="hero-11" className="bg-whitesmoke-gradient hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- HERO IMAGE -->	
							}
							<div className="col-md-5 col-lg-6 order-last order-md-2">
								<div className="hero-11-img text-center">
									<img className="img-fluid" src="images/img-07.png" alt="hero-image" />
								</div>
							</div>


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-md-7 col-lg-6 order-first order-md-2">
								<div className="hero-11-txt">

									{ //<!-- Title -->	
									}
									<h2 className="h2-lg">Keeps Your Data Private & Safe</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Feugiat primis ligula risus auctor egestas and augue viverra mauri tortor in
										iaculis magna feugiat
									</p>

									{ //<!-- DOWNLOAD BUTTON -->	
									}
									<a href="#" className="os-btn bg-white d-flex align-items-center">

										{ //<!-- Icon -->	
										}
										<div className="os-btn-ico">
											<div className="ico-50">
												<img src="images/png-icons/windows.png" alt="os-icon" />
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="os-btn-txt">
											<h6 className="h6-lg">Download for Windows</h6>
											<p>try 30 days free trial</p>
										</div>

									</a>

									{ //<!-- DOWNLOAD BUTTON -->	
									}
									<a href="#" className="os-btn mac-os-btn bg-white d-flex align-items-center">

										{ //<!-- Icon -->	
										}
										<div className="os-btn-ico">
											<div className="ico-50">
												<img src="images/png-icons/mac-os.png" alt="os-icon" />
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="os-btn-txt">
											<h6 className="h6-lg">Download for Mac</h6>
											<p>try 30 days free trial</p>
										</div>

									</a>

								</div>
							</div>	{ //<!-- END HERO TEXT -->	
							}


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-11 -->	
				}




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Security, Simplicity, Easiness</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-last order-lg-2">
									<div className="txt-block left-column wow fadeInRight">

									
										<h2 className="h2-xs">More productivity with less effort</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-first order-md-2">
									<div className="img-block left-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-14.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-09.png" alt="video-preview" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Advanced Performance Made Easy</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Manage Your Workflow Easily</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				{ //<!-- CONTENT-9

				}
				<section id="content-9" className="content-9 bg-04 pt-100 content-section division">
					<div className="container white-color">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id rounded-id bg-tra-white white-color txt-upcase">
										Extremely Flexible
									</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Discover powerful features to boost your productivity</h2>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-9-img video-preview wow fadeInUp">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-pink ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-9 -->	
				}




<Features4/>




				{ //<!-- CONTENT-5

				}
				<section id="content-5" className="content-5 ws-wrapper content-section division">
					<div className="container">
						<div className="content-5-wrapper bg-whitesmoke">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- Section ID -->	
										}
										<span className="section-id rounded-id bg-tra-purple purple-color txt-upcase">
											Fast Performance
										</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">Work smarter with powerful features</h2>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat sapien rutrum mauris auctor
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores ligula and aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-10.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-5 -->	
				}




<Features8/>




<Reviews1/>



<Brands/>



				
				<hr className="divider" />




				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-25">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Manage Everything in One Place</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Advanced Control and Privacy</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-05.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




				
				<hr className="divider" />




				<Statistic2/>




				
				<hr className="divider" />




				<Faq2/>




				{ //<!-- CALL TO ACTION-9

				}
				<section id="cta-9" className="bg-tra-purple wide-80 cta-section division">
					<div className="container">
						<div className="row justify-content-md-center">


							{ //<!-- CALL TO ACTION TEXT -->	
							}
							<div className="col col-lg-8">
								<div className="cta-9-txt text-center">

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Getting Started is Fast & Easy</h2>
									<p className="p-xl mb-35">Download OLMO on your Windows or Mac and get 30 days free trial.</p>

									{ //<!-- DOWNLOAD BUTTON -->	
									}
									<a href="#" className="os-btn bg-white d-flex align-items-center">

										{ //<!-- Icon -->	
										}
										<div className="os-btn-ico">
											<div className="ico-50">
												<img src="images/png-icons/windows.png" alt="os-icon" />
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="os-btn-txt">
											<h6 className="h6-lg">Download for Windows</h6>
											<p>try 30 days free trial</p>
										</div>

									</a>

									{ //<!-- DOWNLOAD BUTTON -->	
									}
									<a href="#" className="os-btn mac-os-btn bg-white d-flex align-items-center">

										{ //<!-- Icon -->	
										}
										<div className="os-btn-ico">
											<div className="ico-50">
												<img src="images/png-icons/mac-os.png" alt="os-icon" />
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="os-btn-txt">
											<h6 className="h6-lg">Download for Mac</h6>
											<p>try 30 days free trial</p>
										</div>

									</a>

								</div>
							</div>	{ //<!-- END CALL TO ACTION TEXT -->	
							}


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CALL TO ACTION-9 -->	
				}



				<Footer1 mainCssClass="footer division" />





			</div>
		</React.Fragment>
	)
}
