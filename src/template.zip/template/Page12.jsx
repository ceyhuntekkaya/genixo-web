import React from 'react'
import Journey from '../pages/Journey'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Features4 from './components/Features4'
import Features8 from './components/Features8'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews1 from './components/Reviews1'
import Statistic2 from './components/Statistic2'
export default function Page12() {
	return (
		<React.Fragment>



			<div id="page" className="page">




				<Header mainCssClass="header tra-menu navbar-dark" />




				{ //<!-- HERO-12

				}
				<section id="hero-12" className="rel hero-section division">
					<div className="container">


						{ //<!-- HERO TEXT -->	
						}
						<div className="row">
							<div className="col-lg-8 offset-lg-1">
								<div className="hero-12-txt">

									{ //<!-- Rounded Logo -->	
									}
									<div className="hero-logo-rounded bg-grey mb-40">
										<img className="img-fluid" src="images/logo-01-sm.png" alt="hero-logo" />
										<span>OLMO.DESIGN</span>
									</div>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xl">Minimum cost solutions for all your web needs</h2>

									{ //<!-- Text -->	
									}
									<p>Handcrafted HTML5 landing page template. High quality solution for those who want a beautiful
										and powerful website
									</p>

								</div>
							</div>
						</div>	{ //<!-- HERO TEXT -->	
						}


						{ //<!-- HERO IMAGE -->	
						}
						<div className="row">
							<div className="col">
								<div className="hero-12-img video-preview">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-violet-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-07.png" alt="content-image" />

								</div>
							</div>
						</div>	{ //<!-- END HERO IMAGE -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-12 -->	
				}




<Features4/>


				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Beautiful Creative Solutions</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-last order-lg-2">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- Section ID -->	
										}
										<span className="section-id rounded-id bg-tra-purple purple-color txt-upcase">
											Fast Performance
										</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">More productivity with less effort</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-first order-md-2">
									<div className="img-block left-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-06.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-09.png" alt="video-preview" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Advanced Performance Made Easy</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">The Complete Software Solution</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				{ //<!-- PROJECTS-2

				}
				<section id="projects-2" className="pb-60 projects-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">We Care About The Details</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PROJECTS-2 WRAPPER -->	
						}
						<div className="row">
							<div className="col gallery-items-list">
								<div className="masonry-wrap grid-loaded">


									{ //<!-- PROJECT #1 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-05.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">A ligula risus auctor and justo tempus blandit</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Graphic Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #1 -->	
									}


									{ //<!-- PROJECT #2 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-02.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Integer urna turpis donec and ipsum porta justo</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #2 -->	
									}


									{ //<!-- PROJECT #3 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-04.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien augue undo integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UX, Illustration</p>

										</div>

									</div>	{ //<!-- END PROJECT #3 -->	
									}


									{ //<!-- PROJECT #4 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-01.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Laoreet undo magna at suscipit undo magna</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #4 -->	
									}


									{ //<!-- PROJECT #5 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-03.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #5 -->	
									}


									{ //<!-- PROJECT #6 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-06.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #6 -->	
									}


								</div>
							</div>
						</div>	{ //<!-- END PROJECTS-1 WRAPPER -->	
						}


						{ //<!-- MORE PROJECTS -->	
						}
						<div className="row">
							<div className="col">
								<div className="more-btn mt-20">
									<a href="projects.html" className="btn btn-violet-red tra-grey-hover">View More Projects</a>
								</div>
							</div>
						</div>	{ //<!-- END DOWNLOAD BUTTON -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PROJECTS-2 -->	
				}




				{ //<!-- CONTENT-1

				}
				<section id="content-1" className="content-1 bg-04 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6 order-last order-md-2">
								<div className="txt-block left-column white-color wow fadeInRight">

									
									<h2 className="h2-xs">Work smarter with powerful features</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6 order-first order-md-2">
								<div className="rel img-block right-column video-preview wow fadeInLeft">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-violet-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/img-08.png" alt="video-preview" />

								</div>
							</div>


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-1 -->	
				}




<Features8/>



				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 bg-whitesmoke-gradient wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id rounded-id bg-tra-purple purple-color txt-upcase">
										Easy Integration
									</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Intuitive features, powerful results</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
												magna purus pretium ligula purus and quaerat
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
												at sodales sapien purus
											</p>
										</li>

									</ul>

									{ //<!-- Tools List -->	
									}
									<div className="tools-list ico-40 mt-30">

										{ //<!-- Text -->	
										}
										<h6 className="h6-lg">Technologies We Use:</h6>

										{ //<!-- Icons -->	
										}
										<span className="flaticon-html-5 text-black-50"></span>
										<span className="flaticon-css-3 text-black-50"></span>
										<span className="flaticon-wordpress-logo text-black-50"></span>
										<span className="flaticon-js text-black-50"></span>
										<span className="flaticon-diamond-1 text-black-50"></span>

									</div>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-05.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




				{ //<!-- CONTENT-2A

				}
				<section id="content-2a" className="content-2 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-10.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-25">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Editing Tools and Exports</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Multiplatform. Always Synced</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2A -->	
				}




				
				<hr className="divider" />




				<Statistic2/>


				
				<hr className="divider" />




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Creative and Practical</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit undo vitae ipsum primis and cubilia
											a laoreet augue and luctus magna dolor egestas luctus sapien vitae nemo egestas volute
											and turpis
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Multiplatform. Always Synced</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris an auctor purus euismod iaculis luctus
													magna purus pretium ligula and quaerat luctus magna
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													sodales
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-19.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




<Brands/>



<Reviews1/>



<Faq2/>




				
				<hr className="divider" />




				{ //<!-- NEWSLETTER-2

				}
				<section id="newsletter-2" className="pt-60 pb-60 newsletter-section division">
					<div className="container">
						<div className="row d-flex align-items-center row-cols-1 row-cols-lg-2">


							{ //<!-- NEWSLETTER TEXT -->	
							}
							<div className="col">
								<div className="newsletter-txt pr-20">
									<h3 className="h3-xs">Stay up to date with our news, ideas and updates</h3>
								</div>
							</div>


							{ //<!-- NEWSLETTER FORM -->	
							}
							<div className="col">
								<form className="newsletter-form">

									<div className="input-group">
										<input type="email" autoComplete="off" className="form-control" placeholder="Your email address" required id="s-email" />
										<span className="input-group-btn">
											<button type="submit" className="btn btn-violet-red black-hover">Subscribe Now</button>
										</span>
									</div>

									{ //<!-- Newsletter Form Notification -->	
									}
									<label for="s-email" className="form-notification"></label>

								</form>
							</div>	  { //<!-- END NEWSLETTER FORM -->	
							}


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END NEWSLETTER-2 -->	
				}




				
				<hr className="divider" />




				{ //<!-- BLOG-1

				}
				<section id="blog-1" className="wide-60 blog-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Our Stories & Latest News</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- BLOG POSTS -->	
						}
						<div className="row row-cols-1 row-cols-md-2 row-cols-lg-3">


							{ //<!-- BLOG POST #1 -->	
							}
							<div className="col">
								<div id="bp-1-1" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-1-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">OLMO News &ensp;|&ensp; June 12, 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">Integer urna turpis donec ipsum a porta justo auctor</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Donec sapien augue integer turpis urna cursus porta, mauris augue...</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">9 Comments</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #1 -->	
							}


							{ //<!-- BLOG POST #2 -->	
							}
							<div className="col">
								<div id="bp-1-2" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-5-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">Tutorials &ensp;|&ensp; June 3, 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">A ligula risus auctor tempus</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Donec sapien augue integer turpis urna cursus porta a mauris dolor...</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">12 Comments</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #2 -->	
							}


							{ //<!-- BLOG POST #3 -->	
							}
							<div className="col">
								<div id="bp-1-3" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-2-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">Inspiration &ensp;|&ensp; May 18, 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">Donec sapien augue integer turpis at cursus porta mauris</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Donec sapien augue integer turpis urna cursus porta, mauris augue...</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">3 Comments</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #3 -->	
							}


						</div>	{ //<!-- END BLOG POSTS -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END BLOG-1 -->	
				}




				{ //<!-- CALL TO ACTION-11

				}
					<Journey className="bg-snow cta-section division"/>

			


				<Footer1 mainCssClass="bg-snow footer division" />





			</div>
		</React.Fragment>
	)
}
