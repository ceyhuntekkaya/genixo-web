import React from 'react'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Features4 from './components/Features4'
import Features8 from './components/Features8'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews1 from './components/Reviews1'
import Statistic2 from './components/Statistic2'
export default function Page13() {
	return (
		<React.Fragment>




			<div id="page" className="page">



				<Header mainCssClass="header tra-menu navbar-dark" />




				{ //<!-- HERO-13

				}
				<section id="hero-13" className="bg-scroll hero-section division">
					<div className="container">


						{ //<!-- HERO TITLE -->	
						}
						<div className="row">
							<div className="col-md-9 col-lg-8">
								<div className="hero-13-title mb-40">
									<h2 className="h2-lg">Convert your ideas into workable solutions</h2>
								</div>
							</div>
						</div>


						<div className="row">


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="hero-13-txt">

									<p className="p-title-sm">Fringilla risus, luctus mauris</p>
									<p className="p-title-sm">Nemo ipsam egestas volute turpis</p>
									<p className="p-title-sm">Mauris in cubilia rutrum</p>
									<p className="p-title-sm">Mullam a donec nihil impedit</p>
									<p className="p-title-sm">Feugiat primis a ligula</p>

									{ //<!-- Tools List -->	
									}
									<div className="tools-list ico-40 mt-50">

										{ //<!-- Text -->	
										}
										<h6 className="h6-xl">Technologies We Use:</h6>

										{ //<!-- Icons -->	
										}
										<span className="flaticon-html-5"></span>
										<span className="flaticon-css-3"></span>
										<span className="flaticon-wordpress-logo"></span>
										<span className="flaticon-js"></span>
										<span className="flaticon-diamond-1"></span>

									</div>

								</div>
							</div>	{ //<!-- END HERO TEXT -->	
							}


							{ //<!-- HERO IMAGE -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="hero-13-img video-preview">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-violet-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-04.png" alt="hero-image" />

								</div>
							</div>


						</div>	    { //<!-- End row -->	
						}
					</div>	    { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-13 -->	
				}




				{ //<!-- FEATURES-1

				}
				<section id="features-1" className="wide-60 features-section division">
					<div className="container">


						{ //<!-- FEATURES-1 WRAPPER -->	
						}
						<div className="fbox-1-wrapper text-center">
							<div className="row row-cols-1 row-cols-md-2 row-cols-lg-4">


								{ //<!-- FEATURE BOX #1 -->	
								}
								<div className="col">
									<div className="fbox-1 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="fbox-ico-center ico-60">
											<span className="flaticon-web-browser"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="fbox-txt-center">

											{ //<!-- Title -->	
											}
											<h5 className="h5-sm">Cross-Platform</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Porta semper lacus cursus feugiat and primis ultrice</p>

										</div>

									</div>
								</div>


								{ //<!-- FEATURE BOX #2 -->	
								}
								<div className="col">
									<div className="fbox-1 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="fbox-ico-center ico-60">
											<span className="flaticon-filter-1"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="fbox-txt-center">

											{ //<!-- Title -->	
											}
											<h5 className="h5-sm">Powerful Options</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Porta semper lacus cursus feugiat and primis ultrice</p>

										</div>

									</div>
								</div>


								{ //<!-- FEATURE BOX #3 -->	
								}
								<div className="col">
									<div className="fbox-1 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="fbox-ico-center ico-60">
											<span className="flaticon-arrow"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="fbox-txt-center">

											{ //<!-- Title -->	
											}
											<h5 className="h5-sm">Extremely Flexible</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Porta semper lacus cursus feugiat and primis ultrice</p>

										</div>

									</div>
								</div>


								{ //<!-- FEATURE BOX #4 -->	
								}
								<div className="col">
									<div className="fbox-1 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="fbox-ico-center ico-60">
											<span className="flaticon-web-programming"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="fbox-txt-center">

											{ //<!-- Title -->	
											}
											<h5 className="h5-sm">Easy to Embed</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Porta semper lacus cursus feugiat and primis ultrice</p>

										</div>

									</div>
								</div>


							</div>
						</div>    { //<!-- END FEATURES-1 WRAPPER -->	
						}


					</div>     { //<!-- End container -->	
					}
				</section>	{ //<!-- END FEATURES-1 -->	
				}




				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 bg-snow wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-08.png" alt="video-preview" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Extremely Flexible</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Work smarter with powerful features</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




<Features8/>




				
				<hr className="divider" />




				<Statistic2/>




				
				<hr className="divider" />




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Creative and Practical</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit undo vitae ipsum primis and cubilia
											a laoreet augue and luctus magna dolor egestas luctus sapien vitae nemo egestas volute
											and turpis
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Multiplatform. Always Synced</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris an auctor purus euismod iaculis luctus
													magna purus pretium ligula and quaerat luctus magna
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													sodales
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-19.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




				{ //<!-- CONTENT-9

				}
				<section id="content-9" className="content-9 bg-04 pt-100 content-section division">
					<div className="container white-color">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Handling With Ease</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Discover powerful features to boost your productivity</h2>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-9-img video-preview wow fadeInUp">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-violet-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-9 -->	
				}




<Features4/>




				{ //<!-- CONTENT-5

				}
				<section id="content-5" className="content-5 ws-wrapper content-section division">
					<div className="container">
						<div className="content-5-wrapper bg-whitesmoke">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Fast Performance</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">More productivity with less effort</h2>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat sapien rutrum mauris auctor
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores ligula and aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-10.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-5 -->	
				}




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Beautiful Creative Solutions</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-06.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Easy Integration</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">Intuitive features, powerful results</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-last order-md-2">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Advanced Performance Made Easy</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Creative Alternative Solutions</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-first order-md-2">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-09.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				{ //<!-- PROJECTS-2

				}
				<section id="projects-2" className="pb-60 projects-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">We Care About The Details</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PROJECTS-2 WRAPPER -->	
						}
						<div className="row">
							<div className="col gallery-items-list">
								<div className="masonry-wrap grid-loaded">


									{ //<!-- PROJECT #1 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-05.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">A ligula risus auctor and justo tempus blandit</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Graphic Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #1 -->	
									}


									{ //<!-- PROJECT #2 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-02.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Integer urna turpis donec and ipsum porta justo</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #2 -->	
									}


									{ //<!-- PROJECT #3 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-04.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien augue undo integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UX, Illustration</p>

										</div>

									</div>	{ //<!-- END PROJECT #3 -->	
									}


									{ //<!-- PROJECT #4 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-01.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Laoreet undo magna at suscipit undo magna</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #4 -->	
									}


									{ //<!-- PROJECT #5 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-03.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #5 -->	
									}


									{ //<!-- PROJECT #6 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-06.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #6 -->	
									}


								</div>
							</div>
						</div>	{ //<!-- END PROJECTS-1 WRAPPER -->	
						}


						{ //<!-- MORE PROJECTS -->	
						}
						<div className="row">
							<div className="col">
								<div className="more-btn mt-20">
									<a href="projects.html" className="btn btn-violet-red tra-grey-hover">View More Projects</a>
								</div>
							</div>
						</div>	{ //<!-- END DOWNLOAD BUTTON -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PROJECTS-2 -->	
				}




				{ //<!-- STATISTIC-1

				}
				<div id="statistic-1" className="bg-01 pt-70 pb-70 statistic-section division">
					<div className="container white-color">


						{ //<!-- STATISTIC-1 WRAPPER -->	
						}
						<div className="statistic-1-wrapper">
							<div className="row justify-content-md-center row-cols-1 row-cols-md-3">


								{ //<!-- STATISTIC BLOCK #1 -->	
								}
								<div id="sb-1-1" className="col">
									<div className="statistic-block wow fadeInUp">

										{ //<!-- Digit -->	
										}
										<h2 className="h2-xl statistic-number"><span className="count-element">28</span>%</h2>

										{ //<!-- Text -->	
										}
										<h5 className="h5-lg">Faster Access</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Enim nullam tempor at sapien gravida donec a blandit integer posuere porta
											justo velna
										</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #2 -->	
								}
								<div id="sb-1-2" className="col">
									<div className="statistic-block wow fadeInUp">

										{ //<!-- Digit -->	
										}
										<h2 className="h2-xl statistic-number"><span className="count-element">54</span>%</h2>

										{ //<!-- Text -->	
										}
										<h5 className="h5-lg">Productivity</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Enim nullam tempor at sapien gravida donec a blandit integer posuere porta
											justo velna
										</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #3 -->	
								}
								<div id="sb-1-3" className="col">
									<div className="statistic-block wow fadeInUp">

										{ //<!-- Digit -->	
										}
										<h2 className="h2-xl statistic-number"><span className="count-element">36</span>%</h2>

										{ //<!-- Text -->	
										}
										<h5 className="h5-lg">Secure Access</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Enim nullam tempor at sapien gravida donec a blandit integer posuere porta
											justo velna
										</p>

									</div>
								</div>


							</div>
						</div>	{ //<!-- END STATISTIC-1 WRAPPER -->	
						}


					</div>	 { //<!-- End container -->	
					}
				</div>	 { //<!-- END STATISTIC-1 -->	
				}





<Reviews1/>




<Brands/>




				{ //<!-- PRICING-3

				}
				<section id="pricing-3" className="bg-lightgrey wide-60 pricing-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-80">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Simple And Flexible Pricing</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PRICING TABLES -->	
						}
						<div className="pricing-3-row pc-20">
							<div className="row row-cols-1 row-cols-md-3">


								{ //<!-- BASIC PLAN -->	
								}
								<div className="col">
									<div className="pricing-3-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan">
											<h6 className="h6-xl">Basic</h6>
											<sup className="dark-color">$</sup>
											<span className="price dark-color">11</span>
											<sup className="coins dark-color">99</sup>
											<p className="p-lg">Monthly Payment</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md"><span>10</span> Projects</p></li>
											<li><p className="p-md"><span>15</span> mySQL Database</p></li>
											<li><p className="p-md"><span>30 GB</span> of Storage</p></li>
											<li className="disabled-option"><p className="p-md">No Ads. No Trackers</p></li>
											<li className="disabled-option"><p className="p-md">Daily Data Backup</p></li>
											<li className="disabled-option"><p className="p-md">Extra Features</p></li>
											<li><p className="p-md"><span>12/5</span> Free Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-tra-grey tra-violet-red-hover">Get Started</a>

									</div>
								</div>	{ //<!-- END BASIC PLAN -->	
								}


								{ //<!-- ADVANCED PLAN -->	
								}
								<div className="col">
									<div className="pricing-3-table bg-white rel mb-40 wow fadeInUp">

										{ //<!-- Hightlight Badge -->	
										}
										<div className="badge-wrapper">
											<div className="highlight-badge bg-violet-red white-color">
												<h6 className="h6-md">Most Popular</h6>
											</div>
										</div>

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan">
											<h6 className="h6-xl">Advanced</h6>
											<sup className="dark-color">$</sup>
											<span className="price dark-color">24</span>
											<sup className="coins dark-color">99</sup>
											<p className="p-lg">Monthly Payment</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md"><span>25</span> Projects</p></li>
											<li><p className="p-md"><span>40</span> mySQL Database</p></li>
											<li><p className="p-md"><span>100 GB</span> of Storage</p></li>
											<li><p className="p-md">No Ads. No Trackers</p></li>
											<li><p className="p-md">Daily Data Backup</p></li>
											<li className="disabled-option"><p className="p-md">Extra Features</p></li>
											<li><p className="p-md"><span>24/7</span> Free Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-violet-red tra-grey-hover">Get Started</a>

									</div>
								</div>	{ //<!-- END ADVANCED PLAN -->	
								}


								{ //<!-- PREMIUM PLAN -->	
								}
								<div className="col">
									<div className="pricing-3-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan">
											<h6 className="h6-xl">Premium</h6>
											<sup className="dark-color">$</sup>
											<span className="price dark-color">89</span>
											<sup className="coins dark-color">99</sup>
											<p className="p-lg">Monthly Payment</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md"><span>50</span> Projects</p></li>
											<li><p className="p-md"><span>30</span> mySQL Database</p></li>
											<li><p className="p-md"><span>500 GB</span> of Storage</p></li>
											<li><p className="p-md">No Ads. No Trackers</p></li>
											<li><p className="p-md">Daily Data Backup</p></li>
											<li><p className="p-md">Extra Features</p></li>
											<li><p className="p-md"><span>VIP</span> Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-tra-grey tra-violet-red-hover">Get Started</a>

									</div>
								</div>	{ //<!-- END PREMIUM PLAN -->	
								}


							</div>
						</div>	{ //<!-- END PRICING TABLES -->	
						}


						{ //<!-- PRICING NOTICE TEXT -->	
						}
						<div className="row">
							<div className="col-lg-10 offset-lg-1">
								<div className="pricing-notice text-center mb-40">
									<p>The above prices do not include applicable taxes based on your billing address.The final price
										will be displayed on the checkout page, before the payment is completed
									</p>
								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PRICING-3 -->	
				}



<Faq2/>




				{ //<!-- CALL TO ACTION-6

				}
				<section id="cta-6" className="bg-04 pt-70 pb-70 cta-section division">
					<div className="container">
						<div className="row justify-content-md-center">


							{ //<!-- BANNER TEXT -->	
							}
							<div className="col col-lg-8">
								<div className="cta-6-txt white-color text-center">

									{ //<!-- Title -->	
									}
									<h2 className="h2-sm">Get started with OLMO today and improve your workflow</h2>

									{ //<!-- Buttons Group -->	
									}
									<div className="btns-group mb-30">
										<a href="download.html" className="btn btn-md btn-violet-red tra-white-hover mr-15">Start Free Trial</a>
										<a href="pricing.html" className="btn btn-md btn-tra-white white-hover">View Pricing</a>
									</div>

									{ //<!-- Advantages List -->	
									}
									<ul className="advantages text-center clearfix">
										<li className="first-li"><p>Free 30 days trial</p></li>
										<li><p>Exclusive Support</p></li>
										<li className="last-li"><p>No Fees</p></li>
									</ul>

								</div>
							</div>	{ //<!-- END BANNER TEXT -->	
							}


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CALL TO ACTION-6 -->	
				}



				<Footer1 mainCssClass="footer division" />





			</div>
		</React.Fragment>
	)
}
