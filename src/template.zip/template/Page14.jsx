import React from 'react'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Features4 from './components/Features4'
import Features8 from './components/Features8'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews1 from './components/Reviews1'
import Statistic2 from './components/Statistic2'
export default function Page14() {
	return (
		<React.Fragment>


			<div id="page" className="page">




				<Header mainCssClass="header tra-menu navbar-light" />




				{ //<!-- HERO-14

				}
				<section id="hero-14" className="bg-fixed hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-sm-9 col-md-7 col-lg-5">
								<div className="hero-14-txt white-color wow fadeInRight">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Secure Every Transaction</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xl">Smart & Secure Mobile Banking</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Feugiat primis a ligula auctor mauris auctor laoreet and pretium augue
										an egestas
									</p>

									{ //<!-- STORE BADGES -->	
									}
									<div className="stores-badge">

										{ //<!-- AppStore -->	
										}
										<a href="#" className="store">
											<img className="appstore" src="images/appstore.png" alt="appstore-badge" />
										</a>

										{ //<!-- Google Play -->	
										}
										<a href="#" className="store">
											<img className="googleplay" src="images/googleplay.png" alt="googleplay-badge" />
										</a>

										{ //<!-- Aamazon Market 
											<a href="#" className="store">
												<img className="amazon" src="images/amazon.png" alt="amazon-badge" />
											</a>
										}

										{ //<!-- Mac AppStore 
											<a href="#" className="store">
												<img className="mac-appstore" src="images/macstore.png" alt="macstore-badge" />
											</a>
										}

										{ //<!-- Microsoft Store  
											<a href="#" className="store">
												<img className="microsoft" src="images/microsoft.png" alt="microsoft-badge" />
											</a>
										}

									</div>	{ //<!-- END STORE BADGES -->	
									}

								</div>
							</div>	{ //<!-- END HERO TEXT -->	
							}


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-14 -->	
				}




<Brands/>




<Features8/>



				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">All-in-one banking solutions</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit undo vitae ipsum primis and cubilia
											a laoreet augue and luctus magna dolor egestas luctus sapien vitae nemo egestas volute
											and turpis
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Online invoices and estimates</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris an auctor purus euismod iaculis luctus
													magna purus pretium ligula and quaerat luctus magna
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													sodales
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-20.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




				
				<hr className="divider" />




				<Features4/>




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 bg-snow wide-60 content-section division">
					<div className="container">


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/banking-03.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Concrete Security</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">Your payments are secure, every time</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-last order-md-2">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Always know your account balance</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Send money to your friends and family</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-first order-md-2">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/banking-02.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 wide-60 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Security, Simplicity, Easiness</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/banking-01.png" alt="video-preview" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-20">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Say goodbye to hidden fees</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Block debit card transactions</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




				
				<hr className="divider" />




				<Statistic2/>



				
				<hr className="divider" />




				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Easiest to use</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Send online invites and get bonuses</h2>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
										cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
									</p>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Invoice your customers in seconds</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-01.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




<Reviews1/>



				{ //<!-- CONTENT-1

				}
				<section id="content-1" className="content-1 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-20">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Stay tuned with push-notifications</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">24/7 Access to your card information</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6 order-first order-md-2">
								<div className="rel img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/banking-04.png" alt="content-image" />
								</div>
							</div>


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-1 -->	
				}




				{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 pb-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Premium on Security</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Send money & make purchases at approved merchants</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque at dolor primis libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center wow fadeInUp">
									<img className="img-fluid" src="images/world-map.png" alt="content-image" />
								</div>
							</div>
						</div>


						{ //<!-- ACTION BUTTON -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-10-btn">

									{ //<!-- Button -->	
									}
									<a href="https://www.youtube.com/watch?v=7e90gBu4pas" className="video-popup2 btn btn-md btn-violet-red tra-grey-hover ico-15 ico-left"><span className="flaticon-play"></span> See OLMO in Action</a>

									{ //<!-- Advantages List -->	
									}
									<ul className="advantages mt-25 clearfix">
										<li className="first-li"><p>Free 30 days trial</p></li>
										<li><p>Exclusive Support</p></li>
										<li className="last-li"><p>No Fees</p></li>
									</ul>

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10 -->	
				}




				{ //<!-- PRICING-1

				}
				<section id="pricing-1" className="bg-snow wide-70 pricing-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-80">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Simple and Flexible Pricing</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PRICING TABLES -->	
						}
						<div className="pricing-1-row pc-25">
							<div className="row row-cols-1 row-cols-md-3">


								{ //<!-- FREE PLAN -->	
								}
								<div className="col">
									<div className="pricing-1-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price -->	
										}
										<div className="pricing-plan">

											{ //<!-- Plan Title -->	
											}
											<h5 className="h5-xs">OLMO Free</h5>

											{ //<!-- Price -->	
											}
											<sup className="dark-color">$</sup>
											<span className="dark-color">0</span>
											<sup className="validity dark-color"><span>.00</span> / month</sup>
											<p className="p-md">The price per one user. Change or cancel your plan anytime</p>

											{ //<!-- Pricing Plan Button -->	
											}
											<a href="#" className="btn btn-sm btn-tra-grey tra-violet-red-hover">Select Plan</a>

										</div>

									</div>
								</div>	{ //<!-- END FREE PLAN -->	
								}


								{ //<!-- MONTHLY PLAN -->	
								}
								<div className="col">
									<div className="pricing-1-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price -->	
										}
										<div className="pricing-plan">

											{ //<!-- Plan Title -->	
											}
											<h5 className="h5-xs">Monthly Billing</h5>

											{ //<!-- Price -->	
											}
											<sup className="dark-color">$</sup>
											<span className="dark-color">13</span>
											<sup className="validity dark-color"><span>.99</span> / month</sup>
											<p className="p-md">The price per one user. Change or cancel your plan anytime</p>

											{ //<!-- Pricing Plan Button -->	
											}
											<a href="#" className="btn btn-sm btn-tra-grey tra-violet-red-hover">Select Plan</a>

										</div>

									</div>
								</div>	{ //<!-- END MONTHLY PLAN  -->	
								}


								{ //<!-- ANNUAL PLAN -->	
								}
								<div className="col">
									<div className="pricing-1-table bg-white rel mb-40 wow fadeInUp">

										{ //<!-- Hightlight Badge -->	
										}
										<div className="badge-wrapper">
											<div className="highlight-badge bg-violet-red white-color">
												<h6 className="h6-md">Best Value</h6>
											</div>
										</div>

										{ //<!-- Plan Price -->	
										}
										<div className="pricing-plan highlight">

											{ //<!-- Plan Title -->	
											}
											<h5 className="h5-xs">Annual Billing</h5>

											{ //<!-- Price -->	
											}
											<sup className="dark-color">$</sup>
											<span className="dark-color">10</span>
											<sup className="validity dark-color"><span>.75</span> / month</sup>
											<p className="p-md">The price per one user. Change or cancel your plan anytime</p>

											{ //<!-- Pricing Plan Button -->	
											}
											<a href="#" className="btn btn-sm btn-violet-red tra-grey-hover">Select Plan</a>

										</div>

									</div>
								</div>	{ //<!-- END ANNUAL PLAN -->	
								}


							</div>
						</div>	{ //<!-- END PRICING TABLES -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PRICING-1 -->	
				}



<Faq2/>




				{ //<!-- CONTENT-4

				}
				<section id="content-4" className="content-4 pt-80 content-section">
					<div className="bg-inner bg-04 pb-100 division">
						<div className="container">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-end order-md-2">
									<div className="content-4-img left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-03.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-first order-md-2">
									<div className="txt-block right-column white-color wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Download OLMO</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">The simpler and safer way to pay online</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
										</p>

										{ //<!-- STORE BADGES -->	
										}
										<div className="stores-badge">

											{ //<!-- AppStore -->	
											}
											<a href="#" className="store">
												<img className="appstore" src="images/appstore-white.png" alt="appstore-badge" />
											</a>

											{ //<!-- Google Play -->	
											}
											<a href="#" className="store">
												<img className="googleplay" src="images/googleplay-white.png" alt="googleplay-badge" />
											</a>

											{ //<!-- Aamazon Market 
												<a href="#" className="store">
													<img className="amazon" src="images/amazon.png" alt="amazon-badge" />
												</a>
											}

											{ //<!-- Mac AppStore 
												<a href="#" className="store">
													<img className="mac-appstore" src="images/macstore.png" alt="macstore-badge" />
												</a>
											}

											{ //<!-- Microsoft Store  
												<a href="#" className="store">
													<img className="microsoft" src="images/microsoft.png" alt="microsoft-badge" />
												</a>
											}

										</div>	{ //<!-- END STORE BADGES -->	
										}

									</div>
								</div>	{ //<!-- END CONTENT TXT -->	
								}


							</div>	  { //<!-- End row -->	
							}
						</div>	   { //<!-- End container -->	
						}
					</div>		{ //<!-- End Inner Background -->	
					}
				</section>	{ //<!-- END CONTENT-4 -->	
				}


				<Footer1 mainCssClass="footer division" />





			</div>
		</React.Fragment>
	)
}
