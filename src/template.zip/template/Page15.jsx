import React from 'react'
import Journey from '../pages/Journey'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Statistic2 from './components/Statistic2'
export default function Page15() {
	return (
		<React.Fragment>




			<div id="page" className="page">




				<Header mainCssClass="header tra-menu navbar-light" />




				{ //<!-- HERO-15

				}
				<section id="hero-15" className="bg-scroll hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">
							<div className="col text-center">


								{ //<!-- HERO TEXT -->	
								}
								<div className="hero-15-txt white-color">

									{ //<!-- Title -->	
									}
									<h2 className="h2-lg wow fadeInUp">
										We turn the best ideas into excellent products
									</h2>

									{ //<!-- Buttons Group -->	
									}
									<div className="btns-group wow fadeInUp">
										<a href="#features-7" className="btn btn-md btn-orange-red tra-white-hover mr-15">Core Features</a>
										<a href="https://www.youtube.com/watch?v=7e90gBu4pas" className="video-popup2 btn btn-md btn-transparent ico-20 ico-left">
											<span className="flaticon-play"></span> See OLMO in Action
										</a>
									</div>

								</div>	{ //<!-- END HERO TEXT -->	
								}


								{ //<!-- HERO IMAGE -->	
								}
								<div className="hero-15-img wow fadeInUp">
									<img className="img-fluid" src="images/dashboard-03.png" alt="hero-image" />
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-15 -->	
				}




				{ //<!-- FEATURES-5

				}
				<section id="features-5" className="pt-80 pb-60 features-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-80">

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque at dolor primis libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- FEATURES-5 WRAPPER -->	
						}
						<div className="fbox-5-wrapper text-center">
							<div className="row row-cols-1 row-cols-md-3">


								{ //<!-- FEATURE BOX #1 -->	
								}
								<div className="col">
									<div className="fbox-5 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="ico-rounded-lg ico-45 bg-tra-green green-color">
											<span className="flaticon-web-browser"></span>
										</div>

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Cross-Platform</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Porta semper lacus and cursus blandit at feugiat primis ultrice a purus
											euismod neque
										</p>

									</div>
								</div>


								{ //<!-- FEATURE BOX #2 -->	
								}
								<div className="col">
									<div className="fbox-5 bg-white mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="ico-rounded-lg ico-45 bg-tra-purple purple-color">
											<span className="flaticon-arrow"></span>
										</div>

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Extremely Flexible</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Porta semper lacus and cursus blandit at feugiat primis ultrice a purus
											euismod neque
										</p>

									</div>
								</div>


								{ //<!-- FEATURE BOX #3 -->	
								}
								<div className="col">
									<div className="fbox-5 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="ico-rounded-lg ico-45 bg-tra-orange orange-color">
											<span className="flaticon-web-programming"></span>
										</div>

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Easy to Embed</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Porta semper lacus and cursus blandit at feugiat primis ultrice a purus
											euismod neque
										</p>

									</div>
								</div>


							</div>  { //<!-- End row -->	
							}
						</div>	{ //<!-- END FEATURES-5 WRAPPER -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END FEATURES-5 -->	
				}




				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-10.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id rounded-id bg-tra-purple purple-color txt-upcase">
										Extremely Flexible
									</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Work smarter with powerful features</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




				{ //<!-- CONTENT-5

				}
				<section id="content-5" className="content-5 ws-wrapper content-section division">
					<div className="container">
						<div className="content-5-wrapper bg-whitesmoke">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block left-column wow fadeInRight">

										<h2 className="h2-xs">More productivity with less effort</h2>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat sapien rutrum mauris auctor
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores ligula and aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-07.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-5 -->	
				}




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-02.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id rounded-id bg-tra-purple purple-color txt-upcase">
											Fast Performance
										</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">Lightning fast and super powerful</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">All Tools in One Place</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-md">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
														magna purus pretium ligula purus and quaerat tempor sapien rutrum mauris undo
														quaerat ultrice
													</p>
												</li>

												<li className="list-item">
													<p className="p-md">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-last order-md-2">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Advanced Prformance Made Easy</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">The Complete Software Solution</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-first order-md-2">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-06.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				
				<hr className="divider" />




				<Statistic2/>



				
				<hr className="divider" />




				{ //<!-- FEATURES-7

				}
				<section id="features-7" className="wide-70 features-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- FEATURES-7 WRAPPER -->	
							}
							<div className="col-lg-7 order-last order-lg-2">
								<div className="fbox-7-wrapper pr-30">
									<div className="row">


										<div className="col-md-6">

											{ //<!-- FEATURE BOX #1 -->	
											}
											<div id="fb-7-1" className="fbox-7 mt-40 mb-30 wow fadeInUp">

												{ //<!-- Icon -->	
												}
												<div className="fbox-ico-center ico-rounded-md ico-45 bg-tra-purple purple-color">
													<span className="flaticon-dashboard"></span>
												</div>

												{ //<!-- Title -->	
												}
												<h5 className="h5-sm">Friendly Interface</h5>

												{ //<!-- Text -->	
												}
												<p className="p-lg">Porta semper lacus and cursus feugiat at primis ultrice a ligula auctor</p>

											</div>

											{ //<!-- FEATURE BOX #2 -->	
											}
											<div id="fb-7-2" className="fbox-7 mb-30 wow fadeInUp">

												{ //<!-- Icon -->	
												}
												<div className="fbox-ico-center ico-rounded-md ico-45 bg-tra-red red-color">
													<span className="flaticon-tool"></span>
												</div>

												{ //<!-- Title -->	
												}
												<h5 className="h5-sm">Powerful Options</h5>

												{ //<!-- Text -->	
												}
												<p className="p-lg">Porta semper lacus and cursus feugiat at primis ultrice a ligula auctor</p>

											</div>


										</div>


										<div className="col-md-6">


											{ //<!-- FEATURE BOX #3 -->	
											}
											<div id="fb-7-3" className="fbox-7 mb-30 wow fadeInUp">

												{ //<!-- Icon -->	
												}
												<div className="fbox-ico-center ico-rounded-md ico-45 bg-tra-yellow yellow-color">
													<span className="flaticon-layers"></span>
												</div>

												{ //<!-- Title -->	
												}
												<h5 className="h5-sm">Extensions & Addons</h5>

												{ //<!-- Text -->	
												}
												<p className="p-lg">Porta semper lacus and cursus feugiat at primis ultrice a ligula auctor</p>

											</div>

											{ //<!-- FEATURE BOX #4 -->	
											}
											<div id="fb-7-4" className="fbox-7 mb-30 wow fadeInUp">

												{ //<!-- Icon -->	
												}
												<div className="fbox-ico-center ico-rounded-md ico-45 bg-tra-green green-color">
													<span className="flaticon-arrow"></span>
												</div>

												{ //<!-- Title -->	
												}
												<h5 className="h5-sm">Easy To Customize</h5>

												{ //<!-- Text -->	
												}
												<p className="p-lg">Porta semper lacus and cursus feugiat at primis ultrice a ligula auctor</p>

											</div>


										</div>


									</div>
								</div>	{ //<!-- End row -->	
								}
							</div>	{ //<!-- END FEATURES-7 WRAPPER -->	
							}


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-12 col-lg-5 order-first order-lg-2">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id rounded-id bg-tra-purple purple-color txt-upcase">
										Total Control
									</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Work smarter with powerful features</h2>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Semper lacus cursus porta, feugiat and primis donec ultrice ligula tempus an
										auctor ipsum nihil mauris lectus enim ipsum sagittis congue
									</p>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Gravida porta velna vitae auctor congue donec nihil impedit ligula risus mauris
										donec ligula
									</p>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	 { //<!-- End row -->	
						}
					</div>	  { //<!-- End container -->	
					}
				</section>	{ //<!-- END FEATURES-7 -->	
				}




				{ //<!-- PROJECTS-2

				}
				<section id="projects-2" className="pb-60 projects-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">We Care About The Details</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PROJECTS-2 WRAPPER -->	
						}
						<div className="row">
							<div className="col gallery-items-list">
								<div className="masonry-wrap grid-loaded">


									{ //<!-- PROJECT #1 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-05.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">A ligula risus auctor and justo tempus blandit</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Graphic Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #1 -->	
									}


									{ //<!-- PROJECT #2 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-02.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Integer urna turpis donec and ipsum porta justo</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #2 -->	
									}


									{ //<!-- PROJECT #3 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-04.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien augue undo integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UX, Illustration</p>

										</div>

									</div>	{ //<!-- END PROJECT #3 -->	
									}


									{ //<!-- PROJECT #4 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-01.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Laoreet undo magna at suscipit undo magna</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #4 -->	
									}


									{ //<!-- PROJECT #5 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-03.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #5 -->	
									}


									{ //<!-- PROJECT #6 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-06.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #6 -->	
									}


								</div>
							</div>
						</div>	{ //<!-- END PROJECTS-1 WRAPPER -->	
						}


						{ //<!-- MORE PROJECTS -->	
						}
						<div className="row">
							<div className="col">
								<div className="more-btn mt-20">
									<a href="projects.html" className="btn btn-orange-red tra-grey-hover">View More Projects</a>
								</div>
							</div>
						</div>	{ //<!-- END DOWNLOAD BUTTON -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PROJECTS-2 -->	
				}




				{ //<!-- CONTENT-9

				}
				<section id="content-9" className="content-9 bg-04 pt-100 content-section division">
					<div className="container white-color">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id rounded-id bg-tra-white white-color txt-upcase">
										Handling With Ease
									</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Discover powerful features to boost your productivity</h2>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-9-img video-preview wow fadeInUp">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-orange-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-9 -->	
				}




				{ //<!-- TESTIMONIALS-2

				}
				<section id="reviews-2" className="wide-100 reviews-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Stories From Our Customers</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- TESTIMONIALS-2 WRAPPER -->	
						}
						<div className="reviews-2-wrapper">
							<div className="row align-items-center row-cols-1 row-cols-lg-3">


								{ //<!-- TESTIMONIAL #1 -->	
								}
								<div className="col">
									<div id="rw-2-1" className="review-2">

										{ //<!-- Quote Icon -->	
										}
										<div className="review-2-ico ico-25">
											<span className="flaticon-left-quote"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="review-2-txt">

											{ //<!-- Text -->	
											}
											<p className="p-lg">Etiam sapien sagittis congue augue massa varius egestas ultrice
												varius magna a tempus aliquet undo cursus suscipit
											</p>

											{ //<!-- Testimonial Author -->	
											}
											<div className="author-data clearfix">

												{ //<!-- Testimonial Avatar -->	
												}
												<div className="review-avatar">
													<img src="images/review-author-2.jpg" alt="review-avatar" />
												</div>

												{ //<!-- Testimonial Author -->	
												}
												<div className="review-author">

													<h6 className="h6-xl">Scott Boxer</h6>
													<p>@scott_boxer</p>

													{ //<!-- Rating -->	
													}
													<div className="review-rating ico-15 yellow-color">
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-half-empty"></span>
													</div>

												</div>

											</div>	{ //<!-- End Testimonial Author -->	
											}

										</div>	{ //<!-- End Text -->	
										}

									</div>
								</div>	{ //<!-- END TESTIMONIAL #1 -->	
								}


								{ //<!-- TESTIMONIAL #2 -->	
								}
								<div className="col">
									<div id="rw-2-2" className="review-2">

										{ //<!-- Quote Icon -->	
										}
										<div className="review-2-ico ico-25">
											<span className="flaticon-left-quote"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="review-2-txt">

											{ //<!-- Text -->	
											}
											<p className="p-lg">At sagittis congue augue and egestas magna ipsum vitae a purus ipsum
												primis in cubilia laoreet augue egestas luctus and donec diam ultrice ligula magna
												suscipit lectus gestas augue into cubilia
											</p>

											{ //<!-- Testimonial Author -->	
											}
											<div className="author-data clearfix">

												{ //<!-- Testimonial Avatar -->	
												}
												<div className="review-avatar">
													<img src="images/review-author-6.jpg" alt="review-avatar" />
												</div>

												{ //<!-- Testimonial Author -->	
												}
												<div className="review-author">

													<h6 className="h6-xl">Joel Peterson</h6>
													<p>Internet Surfer</p>

													{ //<!-- Rating -->	
													}
													<div className="review-rating ico-15 yellow-color">
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-half-empty"></span>
													</div>

												</div>

											</div>	{ //<!-- End Testimonial Author -->	
											}

										</div>	{ //<!-- End Text -->	
										}

									</div>
								</div>	{ //<!-- END TESTIMONIAL #2 -->	
								}


								{ //<!-- TESTIMONIAL #3 -->	
								}
								<div className="col">
									<div id="rw-2-3" className="review-2">

										{ //<!-- Quote Icon -->	
										}
										<div className="review-2-ico ico-25">
											<span className="flaticon-left-quote"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="review-2-txt">

											{ //<!-- Text -->	
											}
											<p className="p-lg">Mauris donec magnis sapien etiam sapien congue augue egestas et ultrice
												vitae purus diam integer congue magna ligula undo egestas magna at suscipit feugiat
												primis
											</p>

											{ //<!-- Testimonial Author -->	
											}
											<div className="author-data clearfix">

												{ //<!-- Testimonial Avatar -->	
												}
												<div className="review-avatar">
													<img src="images/review-author-5.jpg" alt="review-avatar" />
												</div>

												{ //<!-- Testimonial Author -->	
												}
												<div className="review-author">

													<h6 className="h6-xl">Marisol19</h6>
													<p>@marisol19</p>

													{ //<!-- Rating -->	
													}
													<div className="review-rating ico-15 yellow-color">
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-1"></span>
														<span className="flaticon-star-half-empty"></span>
													</div>

												</div>

											</div>	{ //<!-- End Testimonial Author -->	
											}

										</div>	{ //<!-- End Text -->	
										}

									</div>
								</div>	{ //<!-- END TESTIMONIAL #3 -->	
								}


							</div>	{ //<!-- End row -->	
							}
						</div>	{ //<!-- END TESTIMONIALS-2 WRAPPER -->	
						}


					</div>     { //<!-- End container -->	
					}
				</section>	{ //<!-- END TESTIMONIALS-2 -->	
				}




<Brands/>



<Faq2/>




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Editing Tools and Exports</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit undo vitae ipsum primis and cubilia
											a laoreet augue and luctus magna dolor egestas luctus sapien vitae nemo egestas volute
											and turpis
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Multiplatform. Always Synced</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris an auctor purus euismod iaculis luctus
													magna purus pretium ligula and quaerat luctus magna
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													sodales
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-20.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




				{ //<!-- BLOG-1

				}
				<section id="blog-1" className="pb-60 blog-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Our Stories & Latest News</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- BLOG POSTS -->	
						}
						<div className="row row-cols-1 row-cols-md-2 row-cols-lg-3">


							{ //<!-- BLOG POST #1 -->	
							}
							<div className="col">
								<div id="bp-1-1" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-1-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">OLMO News &ensp;|&ensp; June 12, 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">Integer urna turpis donec ipsum a porta justo auctor</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Donec sapien augue integer turpis urna cursus porta, mauris augue...</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">9 Comments</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #1 -->	
							}


							{ //<!-- BLOG POST #2 -->	
							}
							<div className="col">
								<div id="bp-1-2" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-5-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">Tutorials &ensp;|&ensp; June 3, 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">A ligula risus auctor tempus</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Donec sapien augue integer turpis urna cursus porta a mauris dolor...</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">12 Comments</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #2 -->	
							}


							{ //<!-- BLOG POST #3 -->	
							}
							<div className="col">
								<div id="bp-1-3" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-2-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">Inspiration &ensp;|&ensp; May 18, 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">Donec sapien augue integer turpis at cursus porta mauris</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Donec sapien augue integer turpis urna cursus porta, mauris augue...</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">3 Comments</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #3 -->	
							}


						</div>	{ //<!-- END BLOG POSTS -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END BLOG-1 -->	
				}




				{ //<!-- CALL TO ACTION-11

				}
				<Journey className="bg-snow cta-section division"/>

	

				<Footer1 mainCssClass="footer division" />





			</div>
		</React.Fragment>
	)
}
