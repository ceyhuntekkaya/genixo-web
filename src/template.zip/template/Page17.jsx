import React from 'react'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Features8 from './components/Features8'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews1 from './components/Reviews1'
import Statistic2 from './components/Statistic2'
export default function Page17() {
	return (
		<React.Fragment>
			<div id="page" className="page">
				<Header mainCssClass="header tra-menu navbar-light" />
				{ //{ //<!-- HERO-17

				}
				<section id="hero-17" className="bg-scroll rel hero-section division">
					<div className="container">



						{ //{ //<!-- HERO TITLE -->	
						}
						<div className="row">
							<div className="col-md-9 col-lg-8">
								<div className="hero-17-title white-color mb-50">
									<h2 className="h2-xl">Boost your design workflow with OLMO</h2>
								</div>
							</div>
						</div>


						<div className="row">


							{ //{ //<!-- HERO TEXT -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="hero-17-txt">

									{ //{ //<!-- Text -->	
									}
									<p className="p-xl white-color">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
										cubilia laoreet augue luctus magna dolor luctus sapien
									</p>

									{ //{ //<!-- DOWNLOAD BUTTON -->	
									}
									<a href="#" className="os-btn bg-white d-flex align-items-center">

										{ //{ //<!-- Icon -->	
										}
										<div className="os-btn-ico">
											<div className="ico-50">
												<img src="images/png-icons/windows.png" alt="os-icon" />
											</div>
										</div>

										{ //{ //<!-- Text -->	
										}
										<div className="os-btn-txt">
											<h6 className="h6-lg">Download for Windows</h6>
											<p>try 30 days free trial</p>
										</div>

									</a>

									{ //{ //<!-- DOWNLOAD BUTTON -->	
									}
									<a href="#" className="os-btn mac-os-btn bg-white d-flex align-items-center">

										{ //{ //<!-- Icon -->	
										}
										<div className="os-btn-ico">
											<div className="ico-50">
												<img src="images/png-icons/mac-os.png" alt="os-icon" />
											</div>
										</div>

										{ //{ //<!-- Text -->	
										}
										<div className="os-btn-txt">
											<h6 className="h6-lg">Download for Mac</h6>
											<p>try 30 days free trial</p>
										</div>

									</a>

									{ //{ //<!-- Advantages List -->	
									}
									<ul className="advantages white-color clearfix mt-30">
										<li className="first-li"><p>Version 2.10.074</p></li>
										<li className="last-li"><p>Free 30 days trial</p></li>
									</ul>

								</div>
							</div>


							{ //{ //<!-- HERO IMAGE -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="hero-17-img video-preview">
									<img className="img-fluid" src="images/dashboard-04.png" alt="hero-image" />
								</div>
							</div>


						</div>    { //{ //<!-- End row -->	
						}
					</div>	   { //{ //<!-- End container -->	
					}
				</section>	{ //{ //<!-- END HERO-17 -->	
				}
				<Brands />
				{ //{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-10.png" alt="content-image" />
								</div>
							</div>


							{ //{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Lightning fast and super powerful</h2>

									{ //{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
										laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
									</p>

									{ //{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
										laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
										turpis dolores aliquam quaerat sodales a sapien
									</p>

								</div>
							</div>	{ //{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //{ //<!-- End row -->	
						}
					</div>	   { //{ //<!-- End container -->	
					}
				</section>	{ //{ //<!-- END CONTENT-2 -->	
				}

				<Features8 />

				{ //{ //<!-- CONTENT-9

				}
				<section id="content-9" className="content-9 bg-whitesmoke-gradient pt-100 content-section division">
					<div className="container">


						{ //{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">
									<h2 className="h2-xs">Discover powerful features to boost your productivity</h2>
								</div>
							</div>
						</div>


						{ //{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-9-img video-preview wow fadeInUp">

									{ //{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //{ //<!-- End container -->	
					}
				</section>	{ //{ //<!-- END CONTENT-9 -->	
				}

				<Statistic2 />

				<hr className="divider" />

				{ //{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //{ //<!-- Title -->	
									}
									<h2 className="h2-md">Get Ready to Be Surprised</h2>

									{ //{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-01.png" alt="content-image" />
									</div>
								</div>


								{ //{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //{ //<!-- Title -->	
										}
										<h2 className="h2-xs">More productivity with less effort</h2>

										{ //{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //{ //<!-- Title -->	
											}
											<h5 className="h5-md">All Tools in One Place</h5>

											{ //{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-md">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
														magna purus pretium ligula purus and quaerat tempor sapien rutrum mauris undo
														quaerat ultrice
													</p>
												</li>

												<li className="list-item">
													<p className="p-md">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>

									</div>
								</div>	{ //{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //{ //<!-- END TOP ROW -->	
						}


						{ //{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-last order-md-2">
									<div className="txt-block left-column wow fadeInRight">

										{ //{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Advanced Prformance Made Easy</h5>

											{ //{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //{ //<!-- Title -->	
											}
											<h5 className="h5-lg">The Complete Software Solution</h5>

											{ //{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //{ //<!-- END TEXT BLOCK -->	
								}


								{ //{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-first order-md-2">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-11.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>	{ //{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //{ //<!-- End container -->	
					}
				</section>	{ //{ //<!-- END CONTENT-3 -->	
				}
				<Reviews1 />

				{ //{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 wide-100 content-section division">
					<div className="container">


						{ //{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //{ //<!-- Title -->	
									}
									<h2 className="h2-md">Share Moments. Share Life.</h2>

									{ //{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center wow fadeInUp">
									<img className="img-fluid" src="images/social-networks.png" alt="content-image" />
								</div>
							</div>
						</div>


						{ //{ //<!-- ACTION BUTTON -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-10-btn">

									{ //{ //<!-- Button -->	
									}
									<a href="https://www.youtube.com/watch?v=7e90gBu4pas" className="video-popup2 btn btn-md btn-red tra-grey-hover ico-15 ico-left"><span className="flaticon-play"></span> See OLMO in Action</a>

									{ //{ //<!-- Advantages List -->	
									}
									<ul className="advantages mt-25 clearfix">
										<li className="first-li"><p>Free 30 days trial</p></li>
										<li><p>Exclusive Support</p></li>
										<li className="last-li"><p>No Fees</p></li>
									</ul>

								</div>
							</div>
						</div>


					</div>	   { //{ //<!-- End container -->	
					}
				</section>	{ //{ //<!-- END CONTENT-10 -->	
				}

				{ //{ //<!-- CONTENT-2A

				}
				<section id="content-2a" className="content-2 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-07.png" alt="content-image" />
								</div>
							</div>


							{ //{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Make it simpler with Quick Commands</h2>

									{ //{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //{ //<!-- End row -->	
						}
					</div>	   { //{ //<!-- End container -->	
					}
				</section>	{ //{ //<!-- END CONTENT-2A -->	
				}

				<Faq2 />

				{ //{ //<!-- CALL TO ACTION-9

				}
				<section id="cta-9" className="bg-01 wide-80 cta-section division">
					<div className="container">
						<div className="row justify-content-md-center">


							{ //{ //<!-- CALL TO ACTION TEXT -->	
							}
							<div className="col col-lg-8">
								<div className="cta-9-txt text-center">

									{ //{ //<!-- Title -->	
									}
									<h2 className="h2-xs white-color">Getting Started is Fast & Easy</h2>
									<p className="p-xl white-color mb-35">Download OLMO on your Windows or Mac and get 30 days free trial.</p>

									{ //{ //<!-- DOWNLOAD BUTTON -->	
									}
									<a href="#" className="os-btn bg-white d-flex align-items-center">

										{ //{ //<!-- Icon -->	
										}
										<div className="os-btn-ico">
											<div className="ico-50">
												<img src="images/png-icons/windows.png" alt="os-icon" />
											</div>
										</div>

										{ //{ //<!-- Text -->	
										}
										<div className="os-btn-txt">
											<h6 className="h6-lg">Download for Windows</h6>
											<p>try 30 days free trial</p>
										</div>

									</a>

									{ //{ //<!-- DOWNLOAD BUTTON -->	
									}
									<a href="#" className="os-btn mac-os-btn bg-white d-flex align-items-center">

										{ //{ //<!-- Icon -->	
										}
										<div className="os-btn-ico">
											<div className="ico-50">
												<img src="images/png-icons/mac-os.png" alt="os-icon" />
											</div>
										</div>

										{ //{ //<!-- Text -->	
										}
										<div className="os-btn-txt">
											<h6 className="h6-lg">Download for Mac</h6>
											<p>try 30 days free trial</p>
										</div>

									</a>

								</div>
							</div>	{ //{ //<!-- END CALL TO ACTION TEXT -->	
							}


						</div>    { //{ //<!-- End row -->	
						}
					</div>	   { //{ //<!-- End container -->	
					}
				</section>	{ //{ //<!-- END CALL TO ACTION-9 -->	
				}

				<Footer1 mainCssClass="footer division" />
			</div>
		</React.Fragment>
	)
}
