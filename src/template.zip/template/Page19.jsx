import React from 'react'
import Faq2 from './components/Faq2'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import TrialLink from './components/TrialLink'
import Features8 from './components/Features8'
import Reviews1 from './components/Reviews1'
import Brands from './components/Brands'
import Features4 from './components/Features4'


export default function Page19() {
	return (
		<React.Fragment>




			<div id="page" className="page">



				<Header mainCssClass="header tra-menu navbar-light" />




				{ //<!-- HERO-19

				}
				<section id="hero-19" className="bg-scroll hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="hero-19-txt white-color">

									{ //<!-- Rounded Logo -->	
									}
									<div className="hero-logo-rounded bg-tra-white mb-45 wow fadeInUp">
										<img className="img-fluid" src="images/logo-white-sm.png" alt="hero-logo" />
										<span>OLMO.MARKETING</span>
									</div>

									{ //<!-- Title -->	
									}
									<h2 className="h2-lg wow fadeInUp">Creative Solutions for Creative Minds</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl wow fadeInUp">
										Semper lacus cursus porta tellus neque dolor primis magna nullam laoreet potenti undo
										tempor neque and luctus and feugiat. Justo integer at odio
									</p>

									{ //<!-- Watch Video Link -->	
									}
									<div className="watch-video wow fadeInUp">
										<div className=" d-flex align-items-center">

											{ //<!-- Link -->	
											}
											<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
												<div className="watch-video-link bg-tra-white ico-35">
													<span className="flaticon-play-button"></span>
												</div>
											</a>

											{ //<!-- Text -->	
											}
											<div className="watch-video-txt">
												<p className="p-lg video-txt-lg">Watch the Video</p>
												<p className="video-txt-sm">2:40 min</p>
											</div>

										</div>
									</div>	{ //<!-- End Watch Video Link -->	
									}

								</div>
							</div>	 { //<!-- END HERO TEXT -->	
							}


							{ //<!-- HERO IMAGE -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="hero-19-img wow fadeInRight">
									<img className="img-fluid" src="images/tablet-01.png" alt="hero-image" />
								</div>
							</div>


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-19 -->	
				}




<Brands/>




				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-16.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Start, Connect, Enjoy</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Start your online business with OLMO</h2>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
										laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
									</p>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
										laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
										turpis dolores aliquam quaerat sodales a sapien
									</p>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




				{ //<!-- CONTENT-5

				}
				<section id="content-5" className="content-5 ws-wrapper content-section division">
					<div className="container">
						<div className="content-5-wrapper bg-whitesmoke">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Digital Strategy</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">We make your business gain more revenue at a glance</h2>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat sapien rutrum mauris auctor
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores ligula and aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-17.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-5 -->	
				}




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Optimized Business Platform</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-14.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Totally Optimized</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">More productivity with less effort</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-last order-md-2">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Advanced Analytics Review</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Search Engine Optimization (SEO)</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-first order-md-2">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-15.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				{ //<!-- CONTENT-2A

				}
				<section id="content-2a" className="content-2 bg-02 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-10.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column white-color wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Monitor Your Growth</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Committed to top quality and results</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2A -->	
				}



<Features8/>




				
				<hr className="divider" />




				{ //<!-- CONTENT-1

				}
				<section id="content-1" className="content-1 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-20">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">All-in-One Marketing Solutions</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Strategy and Analytics Consulting</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6 order-first order-md-2">
								<div className="rel img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-18.png" alt="content-image" />
								</div>
							</div>


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-1 -->	
				}




				{ //<!-- STATISTIC-3

				}
				<section id="statistic-3" className="bg-03 statistic-section division">
					<div className="container">
						<div className="statistic-3-wrapper white-color text-center">
							<div className="row row-cols-1 row-cols-sm-2 row-cols-md-4">


								{ //<!-- STATISTIC BLOCK #1 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65">
											<span className="flaticon-web-programming"></span>
										</div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">4,<span className="count-element">497</span></h3>
										<p className="p-lg txt-400">Finished Projects</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #2 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65">
											<span className="flaticon-shuttle"></span>
										</div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">3,<span className="count-element">889</span></h3>
										<p className="p-lg txt-400">Websites Improved</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #3 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65">
											<span className="flaticon-speech-bubble-3"></span>
										</div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">5,<span className="count-element">179</span></h3>
										<p className="p-lg txt-400">Happy Customers</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #4 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65"><span className="flaticon-help"></span></div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">1,<span className="count-element">473</span></h3>
										<p className="p-lg txt-400">Tickets Closed</p>

									</div>
								</div>


							</div>    { //<!-- End row -->	
							}
						</div>    { //<!-- End statistic-3-wrapper -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END STATISTIC-3 -->	
				}




				{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 wide-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Your road to success</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Marketing solutions that fuel your business growth</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque at dolor primis libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center video-preview">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-skyblue ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/seo-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10 -->	
				}



<Features4/>


<Reviews1/>




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Advanced Analytics Review</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit undo vitae ipsum primis and cubilia
											a laoreet augue and luctus magna dolor egestas luctus
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Email Marketing Campaigns</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris an auctor purus euismod iaculis luctus
													magna purus pretium ligula and quaerat luctus magna
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													sodales
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-20.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}



<Faq2/>



<TrialLink/>


				<Footer1 mainCssClass="bg-lightgrey footer division" />





			</div>
		</React.Fragment>
	)
}
