import React from 'react'
import Header from './components/Header'
import Hero2 from './components/Hero2'
import Features4 from './components/Features4'
import Content5 from './components/Content5'
import Content2 from './components/Content2'
import Statistic2 from './components/Statistic2'
import Content3 from './components/Content3'
import Content10 from './components/Content10'
import Content1 from './components/Content1'
import Reviews4 from './components/Reviews4'
import Brands from './components/Brands'
import Content6 from './components/Content6'
import Features8 from './components/Features8'
import Faq2 from './components/Faq2'
import Content4 from './components/Content4'
import Blog1 from './components/Blog1'
import Newsletters2 from './components/Newsletters2'
import Footer1 from './components/Footer1'

export default function Page2() {
    return (
        <React.Fragment>
            <div id="page" className="page">
                <Header mainCssClass="header tra-menu navbar-light" />
                <Hero2 />
                <Features4 />
                <Content5 />
                <Content2 />
                <hr className="divider" />
                <Statistic2 />
                <hr className="divider" />
                <Content3 />
                <Content10 />
                <Content1 />
                <Reviews4 />
                <Brands />
                <hr className="divider" />
                <Content6 />
                <Features8 />
                <Faq2 />
                <Content4 />
                <Blog1 />
                <hr className="divider" />
                <Newsletters2 />
                <hr className="divider" />
                <Footer1 mainCssClass="footer division" />
            </div>
        </React.Fragment>
    )
}
