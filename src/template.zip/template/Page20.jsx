import React from 'react'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import TrialLink from './components/TrialLink'
import Features8 from './components/Features8'
import Statistic4 from './components/Statistic4'
import Features4 from './components/Features4'
import Reviews4 from './components/Reviews4'


export default function Page20() {
	return (
		<React.Fragment>





			<div id="page" className="page">


				<Header mainCssClass="header tra-menu navbar-light" />



				{ //<!-- HERO-20

				}
				<section id="hero-20" className="bg-fixed hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-md-8 col-lg-6">
								<div className="hero-20-txt white-color">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Protect yourself from the dangers of cyberspace</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Feugiat primis ligula risus auctor laoreet augue egestas mauris viverra
										in iaculis, placerat
									</p>

									{ //<!-- Buttons Group -->	
									}
									<div className="btns-group">
										<a href="#cta-3" className="btn btn-violet-red tra-white-hover mr-15">Get Started</a>
										<a href="https://www.youtube.com/watch?v=7e90gBu4pas" className="video-popup2 btn btn-md btn-transparent ico-20 ico-left">
											<span className="flaticon-play"></span> See OLMO in Action
										</a>
									</div>

								</div>
							</div> 	  { //<!-- END HERO TEXT -->	
							}


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-20 -->	
				}




				{ //<!-- FEATURES-2

				}
				<section id="features-2" className="wide-60 features-section division">
					<div className="container">


						{ //<!-- FEATURES-2 WRAPPER -->	
						}
						<div className="fbox-2-wrapper text-center">
							<div className="row row-cols-1 row-cols-md-3">


								{ //<!-- FEATURE BOX #1 -->	
								}
								<div className="col">
									<div className="fbox-2 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="fbox-ico-center ico-70 shape-ico violet-red-color">
											<img className="ico-bkg" src="images/ico-bkg.png" alt="ico-bkg" />
											<span className="flaticon-cloud-network"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="fbox-txt-center">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">Network</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Feugiat primis ultrice a semper lacus cursus feugiat a primis ultrice a
												ligula risus auctor tempus feugiat felis
											</p>

										</div>

									</div>
								</div>


								{ //<!-- FEATURE BOX #2 -->	
								}
								<div className="col">
									<div className="fbox-2 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="fbox-ico-center ico-70 shape-ico violet-red-color">
											<img className="ico-bkg" src="images/ico-bkg.png" alt="ico-bkg" />
											<span className="flaticon-keyboard"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="fbox-txt-center">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">EndUser</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Feugiat primis ultrice a semper lacus cursus feugiat a primis ultrice a
												ligula risus auctor tempus feugiat felis
											</p>

										</div>

									</div>
								</div>


								{ //<!-- FEATURE BOX #3 -->	
								}
								<div className="col">
									<div className="fbox-2 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="fbox-ico-center ico-70 shape-ico violet-red-color">
											<img className="ico-bkg" src="images/ico-bkg.png" alt="ico-bkg" />
											<span className="flaticon-server-2"></span>
										</div>

										{ //<!-- Text -->	
										}
										<div className="fbox-txt-center">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">Server</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Feugiat primis ultrice a semper lacus cursus feugiat a primis ultrice a
												ligula risus auctor tempus feugiat felis
											</p>

										</div>

									</div>
								</div>


							</div>
						</div>    { //<!-- END FEATURES-2 WRAPPER -->	
						}


					</div>     { //<!-- End container -->	
					}
				</section>	{ //<!-- END FEATURES-2 -->	
				}




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 bg-snow wide-60 content-section division">
					<div className="container">


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-10.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id violet-red-color txt-upcase">Totally Optimized</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">Work smarter with powerful features</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">All Tools in One Place</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-md">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
														magna purus pretium ligula purus and quaerat tempor sapien rutrum mauris undo
														quaerat ultrice
													</p>
												</li>

												<li className="list-item">
													<p className="p-md">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-last order-md-2">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Take full control of your network</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">One click to secure any device</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-first order-md-2">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-02.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 wide-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Security, Simplicity, Easiness</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center wow fadeInUp">
									<img className="img-fluid" src="images/world-map.png" alt="content-image" />
								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10 -->	
				}




<Features4/>




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 bg-02 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column white-color wow fadeInRight">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Easiest to Use</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Ensure your data privacy in smart way with OLMO</h2>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Aliqum  mullam blandit tempor sapien gravida at donec ipsum porta justo. Velna
										vitae auctor and congue magna impedit luctus dolor volute
									</p>

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-20.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




<Features8/>

				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 bg-snow wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-11.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id violet-red-color txt-upcase">Totally Optimized</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">More productivity with less effort</h2>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
										laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
									</p>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
										laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
										turpis dolores aliquam quaerat sodales a sapien
									</p>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




				{ //<!-- CONTENT-1

				}
				<section id="content-1" className="content-1 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-20">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Two-factor authentication</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Cutting-edge encryption</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6 order-first order-md-2">
								<div className="rel img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-07.png" alt="content-image" />
								</div>
							</div>


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-1 -->	
				}




				
				<hr className="divider" />




				<Statistic4/>




				
				<hr className="divider" />




				<Reviews4/>




<Brands/>




				
				<hr className="divider" />




				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id violet-red-color txt-upcase">Extremely Flexible</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Boost the level of protection on every your device</h2>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien purus blandit a purus ipsum primis in cubilia laoreet
										augue luctus magna dolor luctus egestas sapien vitae blandit and tempor sapien  dolores
									</p>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod undo purus blandit purus cubilia ipsum primis in
										laoreet augue luctus undo magna a dolor luctus sapien vitae a nemo egestas volute
									</p>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/devices.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




<Faq2/>




<TrialLink/>


				<Footer1 mainCssClass="bg-lightgrey footer division" />





			</div>
		</React.Fragment>
	)
}
