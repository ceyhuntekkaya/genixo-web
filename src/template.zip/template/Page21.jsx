import React from 'react'
import Faq2 from './components/Faq2'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Features8 from './components/Features8'
import Reviews1 from './components/Reviews1'
import Brands from './components/Brands'
import Journey from '../pages/Journey'

export default function Page21() {
	return (
		<React.Fragment>


			<div id="page" className="page">


				<Header mainCssClass="header tra-menu navbar-dark" />



				{ //<!-- HERO-21

				}
				<section id="hero-21" className="bg-snow hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-md-10 offset-md-1">
								<div className="hero-21-txt text-center">

									{ //<!-- Title -->	
									}
									<h2 className="h2-lg">Creativity never goes wrong, all you need is right direction</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Mauris donec ociis et magnis sapien sagittis sapien tempor gravida
										and aliquet suscipit in magna dignissim, porttitor hendrerit
									</p>

									{ //<!-- HERO QUICK FORM -->	
									}
									<form name="quickform" className="quick-form">

										{ //<!-- Form Inputs -->	
										}
										<div className="input-group">
											<input type="email" name="email" className="form-control email" placeholder="Your email address" autoComplete="off" required />
											<span className="input-group-btn form-btn">
												<button type="submit" className="btn btn-md btn-stateblue black-hover submit">Get Started</button>
											</span>
										</div>

										{ //<!-- Form Message -->	
										}
										<div className="quick-form-msg"><span className="loading"></span></div>

									</form>

									{ //<!-- Advantages List -->	
									}
									<ul className="advantages mt-35">
										<li className="first-li"><p>14 days free trial</p></li>
										<li className="last-li"><p>No credit card</p></li>
									</ul>

								</div>
							</div>	{ //<!-- END HERO TEXT -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-21 -->	
				}




				{ //<!-- CONTENT-9

				}
				<div id="content-9" className="content-9 bg-snow pt-60 content-section division">
					<div className="container">


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-9-img video-preview wow fadeInUp">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-pink ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-03.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</div>	{ //<!-- END CONTENT-9 -->	
				}




<Brands/>




				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-09.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Fast Performance</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">More productivity with less effort</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




<Features8/>




				{ //<!-- CONTENT-5

				}
				<section id="content-5" className="content-5 ws-wrapper content-section division">
					<div className="container">
						<div className="content-5-wrapper bg-whitesmoke">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- CONTENT BOX #1 -->	
										}
										<div className="cbox mb-40">

											{ //<!-- Icon -->	
											}
											<div className="cbox-ico">
												<div className="ico-65">
													<span className="flaticon-double-click"></span>
												</div>
											</div>

											{ //<!-- Text -->	
											}
											<div className="cbox-txt">
												<h5 className="h5-md">Quick Access</h5>
												<p className="p-lg">Ligula risus auctor tempus dolor feugiat undo lacinia purus lipsum
													quaerat primis ultrice tellus and viverra purus suscipit
												</p>
											</div>

										</div>

										{ //<!-- CONTENT BOX #2 -->	
										}
										<div className="cbox mb-40">

											{ //<!-- Icon -->	
											}
											<div className="cbox-ico">
												<div className="ico-65">
													<span className="flaticon-increase-1"></span>
												</div>
											</div>

											{ //<!-- Text -->	
											}
											<div className="cbox-txt">
												<h5 className="h5-md">Fast Performance</h5>
												<p className="p-lg">Ligula risus auctor tempus dolor feugiat undo lacinia purus lipsum
													quaerat primis ultrice tellus and viverra purus suscipit
												</p>
											</div>

										</div>

										{ //<!-- CONTENT BOX #3 -->	
										}
										<div className="cbox mb-40">

											{ //<!-- Icon -->	
											}
											<div className="cbox-ico">
												<div className="ico-65">
													<span className="flaticon-layers"></span>
												</div>
											</div>

											{ //<!-- Text -->	
											}
											<div className="cbox-txt">
												<h5 className="h5-md">Extensions & Addons</h5>
												<p className="p-lg">Ligula risus auctor tempus dolor feugiat undo lacinia purus lipsum
													quaerat primis ultrice tellus and viverra purus suscipit
												</p>
											</div>

										</div>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-07.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-5 -->	
				}




				{ //<!-- CONTENT-2A

				}
				<section id="content-2a" className="content-2 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-06.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Totally Optimized</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Work smarter with powerful features</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2A -->	
				}




				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-25">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Manage Everything in One Place</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Advanced Control and Privacy</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-05.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




				{ //<!-- PROJECTS-2

				}
				<section id="projects-2" className="pb-60 projects-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">We Care About The Details</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PROJECTS-2 WRAPPER -->	
						}
						<div className="row">
							<div className="col gallery-items-list">
								<div className="masonry-wrap grid-loaded">


									{ //<!-- PROJECT #1 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-05.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">A ligula risus auctor and justo tempus blandit</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Graphic Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #1 -->	
									}


									{ //<!-- PROJECT #2 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-02.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Integer urna turpis donec and ipsum porta justo</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #2 -->	
									}


									{ //<!-- PROJECT #3 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-04.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien augue undo integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UX, Illustration</p>

										</div>

									</div>	{ //<!-- END PROJECT #3 -->	
									}


									{ //<!-- PROJECT #4 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-01.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Laoreet undo magna at suscipit undo magna</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #4 -->	
									}


									{ //<!-- PROJECT #5 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-03.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #5 -->	
									}


									{ //<!-- PROJECT #6 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-06.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #6 -->	
									}


								</div>
							</div>
						</div>	{ //<!-- END PROJECTS-1 WRAPPER -->	
						}


						{ //<!-- MORE PROJECTS -->	
						}
						<div className="row">
							<div className="col">
								<div className="more-btn mt-20">
									<a href="projects.html" className="btn btn-stateblue tra-grey-hover">View More Projects</a>
								</div>
							</div>
						</div>	{ //<!-- END DOWNLOAD BUTTON -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PROJECTS-2 -->	
				}




				{ //<!-- STATISTIC-1

				}
				<div id="statistic-1" className="bg-01 pt-70 pb-70 statistic-section division">
					<div className="container white-color">


						{ //<!-- STATISTIC-1 WRAPPER -->	
						}
						<div className="statistic-1-wrapper">
							<div className="row justify-content-md-center row-cols-1 row-cols-md-3">


								{ //<!-- STATISTIC BLOCK #1 -->	
								}
								<div id="sb-1-1" className="col">
									<div className="statistic-block wow fadeInUp">

										{ //<!-- Digit -->	
										}
										<h2 className="h2-xl statistic-number"><span className="count-element">28</span>%</h2>

										{ //<!-- Text -->	
										}
										<h5 className="h5-lg">Faster Access</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Enim nullam tempor at sapien gravida donec a blandit integer posuere porta
											justo velna
										</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #2 -->	
								}
								<div id="sb-1-2" className="col">
									<div className="statistic-block wow fadeInUp">

										{ //<!-- Digit -->	
										}
										<h2 className="h2-xl statistic-number"><span className="count-element">54</span>%</h2>

										{ //<!-- Text -->	
										}
										<h5 className="h5-lg">Productivity</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Enim nullam tempor at sapien gravida donec a blandit integer posuere porta
											justo velna
										</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #3 -->	
								}
								<div id="sb-1-3" className="col">
									<div className="statistic-block wow fadeInUp">

										{ //<!-- Digit -->	
										}
										<h2 className="h2-xl statistic-number"><span className="count-element">36</span>%</h2>

										{ //<!-- Text -->	
										}
										<h5 className="h5-lg">Secure Access</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Enim nullam tempor at sapien gravida donec a blandit integer posuere porta
											justo velna
										</p>

									</div>
								</div>


							</div>
						</div>	{ //<!-- END STATISTIC-1 WRAPPER -->	
						}


					</div>	 { //<!-- End container -->	
					}
				</div>	 { //<!-- END STATISTIC-1 -->	
				}




				{ //<!-- TABS-2

				}
				<section id="tabs-2" className="wide-60 tabs-section division">
					<div className="container">
						<div className="row row-cols-1 row-cols-md-2 d-flex align-items-center">


							{ //<!-- TABS NAVIGATION -->	
							}
							<div className="col">
								<div className="tabs-nav clearfix">
									<ul className="tabs-1">


										{ //<!-- TAB-1 LINK -->	
										}
										<li className="tab-link current" data-tab="tab-1">

											{ //<!-- Title -->	
											}
											<h5 className="h5-sm">Perfect Integration</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Semper lacus cursus porta feugiat primis a luctus ultrice tellus potenti
												neque dolor in primis
											</p>

										</li>

										{ //<!-- TAB-2 LINK -->	
										}
										<li className="tab-link" data-tab="tab-2">

											{ //<!-- Title -->	
											}
											<h5 className="h5-sm">Speed Optimized</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Semper lacus cursus porta feugiat primis a luctus ultrice tellus potenti
												neque dolor in primis
											</p>

										</li>

										{ //<!-- TAB-3 LINK -->	
										}
										<li className="tab-link" data-tab="tab-3">

											{ //<!-- Title -->	
											}
											<h5 className="h5-sm">Advanced Security</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Semper lacus cursus porta feugiat primis a luctus ultrice tellus potenti
												neque dolor in primis
											</p>

										</li>


									</ul>
								</div>
							</div>	{ //<!-- END TABS NAVIGATION -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col">
								<div className="img-block right-column wow fadeInLeft">
									<div className="tabs-content">

										{ //<!-- TAB #1 IMAGE -->	
										}
										<div id="tab-1" className="tab-content current">
											<img className="img-fluid" src="images/img-05.png" alt="tab-image" />
										</div>

										{ //<!-- TAB #2 IMAGE -->	
										}
										<div id="tab-2" className="tab-content">
											<img className="img-fluid" src="images/img-10.png" alt="tab-preview" />
										</div>

										{ //<!-- TAB #3 IMAGE -->	
										}
										<div id="tab-3" className="tab-content">
											<img className="img-fluid" src="images/img-08.png" alt="tab-image" />
										</div>


									</div>
								</div>
							</div>	{ //<!-- END IMAGE BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	    { //<!-- End container -->	
					}
				</section>	 { //<!-- END TABS-2 -->	
				}




<Reviews1/>



<Faq2/>




				{ //<!-- CALL TO ACTION-11

				}
				<Journey className="cta-section division"/>

				<section id="blog-1" className="wide-60 blog-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Our Stories & Latest News</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- BLOG POSTS -->	
						}
						<div className="row row-cols-1 row-cols-md-2 row-cols-lg-3">


							{ //<!-- BLOG POST #1 -->	
							}
							<div className="col">
								<div id="bp-1-1" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-1-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">OLMO News &ensp;|&ensp; June 12, 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">Integer urna turpis donec ipsum a porta justo auctor</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Donec sapien augue integer turpis urna cursus porta, mauris augue...</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">9 Comments</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #1 -->	
							}


							{ //<!-- BLOG POST #2 -->	
							}
							<div className="col">
								<div id="bp-1-2" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-5-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">Tutorials &ensp;|&ensp; June 3, 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">A ligula risus auctor tempus</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Donec sapien augue integer turpis urna cursus porta a mauris dolor...</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">12 Comments</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #2 -->	
							}


							{ //<!-- BLOG POST #3 -->	
							}
							<div className="col">
								<div id="bp-1-3" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-2-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">Inspiration &ensp;|&ensp; May 18, 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">Donec sapien augue integer turpis at cursus porta mauris</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Donec sapien augue integer turpis urna cursus porta, mauris augue...</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">3 Comments</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #3 -->	
							}


						</div>	{ //<!-- END BLOG POSTS -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END BLOG-1 -->	
				}




				
				<hr className="divider" />




				{ //<!-- NEWSLETTER-2

				}
				<section id="newsletter-2" className="pt-60 pb-60 newsletter-section division">
					<div className="container">
						<div className="row d-flex align-items-center row-cols-1 row-cols-lg-2">


							{ //<!-- NEWSLETTER TEXT -->	
							}
							<div className="col">
								<div className="newsletter-txt pr-20">
									<h3 className="h3-xs">Stay up to date with our news, ideas and updates</h3>
								</div>
							</div>


							{ //<!-- NEWSLETTER FORM -->	
							}
							<div className="col">
								<form className="newsletter-form">

									<div className="input-group">
										<input type="email" autoComplete="off" className="form-control" placeholder="Your email address" required id="s-email" />
										<span className="input-group-btn">
											<button type="submit" className="btn btn-stateblue black-hover">Subscribe Now</button>
										</span>
									</div>

									{ //<!-- Newsletter Form Notification -->	
									}
									<label for="s-email" className="form-notification"></label>

								</form>
							</div>	  { //<!-- END NEWSLETTER FORM -->	
							}


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END NEWSLETTER-2 -->	
				}




				
				<hr className="divider" />


				<Footer1 mainCssClass="footer division" />







			</div>
		</React.Fragment>
	)
}
