import React from 'react'
import Journey from '../pages/Journey'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Features8 from './components/Features8'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews1 from './components/Reviews1'
import Statistic4 from './components/Statistic4'
export default function Page23() {
	return (
		<React.Fragment>



			<div id="page" className="page">

				<Header mainCssClass="header tra-menu navbar-light" />




				{ //<!-- HERO-23

				}
				<section id="hero-23" className="bg-scroll hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-lg-6">
								<div className="hero-23-txt white-color wow fadeInRight">

									{ //<!-- Title -->	
									}
									<h2 className="h2-sm">We craft marketing and digital products that grow business</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Feugiat primis and ligula laoreet auctor mauris auctor laoreet and pretium augue
										cubilia
									</p>

									{ //<!-- Button -->	
									}
									<a href="#" className="btn btn-violet-red tra-white-hover">Find Out More</a>

								</div>
							</div>	{ //<!-- END HERO TEXT -->	
							}


							{ //<!-- HERO IMAGE -->	
							}
							<div className="col-lg-6">
								<div className="hero-23-img video-preview wow fadeInLeft">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-violet-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/hero-23-img.jpg" alt="video-preview" />

								</div>
							</div>


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-23 -->	
				}




<Statistic4/>




				
				<hr className="divider" />




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-15.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">More productivity with less effort</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-lg-6 order-last order-lg-2">
									<div className="txt-block slim-column left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Advanced Performance Made Easy</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">The Complete Software Solution</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- CB WRAPPER -->	
								}
								<div className="col-lg-6 order-first order-lg-2">
									<div className="cb-wrapper">

										{ //<!-- CB HOLDER -->	
										}
										<div className="cb-holder wow fadeInLeft">

											{ //<!-- CB BOX #1 -->	
											}
											<div className="cb-single-box">
												<p className="p-lg cb-header">New Customers</p>
												<h2 className="h2-title-xs statistic-number"><sup>+</sup><span className="count-element">784</span></h2>
												<p className="p-md mt-5 ico-10">
													<span className="violet-red-color"><span className="flaticon-"></span> 4.6%</span> vs last 7 days
												</p>
											</div>

											<hr className="divider" />

											{ //<!-- CB BOX #2 -->	
											}
											<div className="cb-single-box">
												<ul className="simple-list">
													<li className="list-item">
														<p className="p-md">Fringilla risus luctus mauris auctor and purus euismod purus</p>
													</li>

													<li className="list-item">
														<p className="p-md">Nemo ipsam volute turpis dolores ut quaerat sodales sapien</p>
													</li>
												</ul>
											</div>

											{ //<!-- CB BOX #3 -->	
											}
											<div className="cb-single-box cb-box-rounded bg-violet-red white-color mt-25">
												<h4 className="h4-lg">98.245</h4>
												<p className="p-lg">Ligula risus auctor tempus</p>
											</div>

										</div>	{ //<!-- END CB HOLDER -->	
										}


										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-1">
											<img className="img-fluid" src="images/bg-shape-1.png" alt="content-image" />
										</div>

										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-2">
											<img className="img-fluid" src="images/bg-shape-2.png" alt="content-image" />
										</div>


									</div>
								</div>	{ //<!-- END CB WRAPPER -->	
								}


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}



<Features8/>




				{ //<!-- CONTENT-2A

				}
				<section id="content-2a" className="content-2 bg-whitesmoke wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-17.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Committed to top quality and results</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2A -->	
				}




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Quick, Easy and Secure</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit undo vitae ipsum primis and cubilia
											a laoreet augue and luctus magna dolor egestas luctus sapien vitae nemo egestas volute
											and turpis
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Register in 30 Seconds</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris an auctor purus euismod iaculis luctus
													magna purus pretium ligula and quaerat luctus magna
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													sodales
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-20.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




				{ //<!-- PROJECTS-2

				}
				<section id="projects-2" className="pb-60 projects-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">We Care About The Details</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PROJECTS-2 WRAPPER -->	
						}
						<div className="row">
							<div className="col gallery-items-list">
								<div className="masonry-wrap grid-loaded">


									{ //<!-- PROJECT #1 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-05.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">A ligula risus auctor and justo tempus blandit</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Graphic Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #1 -->	
									}


									{ //<!-- PROJECT #2 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-02.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Integer urna turpis donec and ipsum porta justo</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #2 -->	
									}


									{ //<!-- PROJECT #3 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-04.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien augue undo integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UX, Illustration</p>

										</div>

									</div>	{ //<!-- END PROJECT #3 -->	
									}


									{ //<!-- PROJECT #4 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-01.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Laoreet undo magna at suscipit undo magna</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #4 -->	
									}


									{ //<!-- PROJECT #5 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-03.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #5 -->	
									}


									{ //<!-- PROJECT #6 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-06.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

										</div>

									</div>	{ //<!-- END PROJECT #6 -->	
									}


								</div>
							</div>
						</div>	{ //<!-- END PROJECTS-1 WRAPPER -->	
						}


						{ //<!-- MORE PROJECTS -->	
						}
						<div className="row">
							<div className="col">
								<div className="more-btn mt-20">
									<a href="projects.html" className="btn btn-violet-red tra-grey-hover">View More Projects</a>
								</div>
							</div>
						</div>	{ //<!-- END DOWNLOAD BUTTON -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PROJECTS-2 -->	
				}




<Brands/>




				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-25">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Editing Tools and Exports</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Multiplatform. Always Synced</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Volute turpis nemo ipsam egestas dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-01.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




<Reviews1/>




				{ //<!-- STATISTIC-3

				}
				<section id="statistic-3" className="bg-03 statistic-section division">
					<div className="container">
						<div className="statistic-3-wrapper white-color text-center">
							<div className="row row-cols-1 row-cols-sm-2 row-cols-md-4">


								{ //<!-- STATISTIC BLOCK #1 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65">
											<span className="flaticon-web-programming"></span>
										</div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">4,<span className="count-element">497</span></h3>
										<p className="p-lg txt-400">Finished Projects</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #2 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65">
											<span className="flaticon-shuttle"></span>
										</div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">3,<span className="count-element">889</span></h3>
										<p className="p-lg txt-400">Websites Improved</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #3 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65">
											<span className="flaticon-speech-bubble-3"></span>
										</div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">5,<span className="count-element">179</span></h3>
										<p className="p-lg txt-400">Happy Customers</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #4 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65"><span className="flaticon-help"></span></div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">1,<span className="count-element">473</span></h3>
										<p className="p-lg txt-400">Tickets Closed</p>

									</div>
								</div>


							</div>    { //<!-- End row -->	
							}
						</div>    { //<!-- End statistic-3-wrapper -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END STATISTIC-3 -->	
				}



<Faq2/>




				{ //<!-- CALL TO ACTION-11

				}
				<Journey className="cta-section division"/>

			

				<Footer1 mainCssClass="footer division" />






			</div>
		</React.Fragment>
	)
}
