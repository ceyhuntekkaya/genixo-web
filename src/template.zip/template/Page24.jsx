import React from 'react'
import Brands from './components/Brands'
import Features4 from './components/Features4'
import Features8 from './components/Features8'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews4 from './components/Reviews4'
export default function Page24() {
	return (
		<React.Fragment>



			<div id="page" className="page rtl-direction">


				<Header mainCssClass="header tra-menu navbar-dark" />



				{ //<!-- HERO-6

				}
				<section id="hero-6" className="hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-lg-6">
								<div className="hero-6-txt">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">أفكار جديدة. تصميم مدروس. نتائج قابلة للقياس</h2>

									{ //<!-- Text -->	
									}
									<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس
									</p>

									{ //<!-- HERO QUICK FORM -->	
									}
									<form name="quickform" className="quick-form shadow-form">

										{ //<!-- Form Inputs -->	
										}
										<div className="input-group">
											<span className="input-group-btn form-btn">
												<button type="submit" className="btn btn-md btn-stateblue black-hover submit">البدء</button>
											</span>
											<input type="email" name="email" className="form-control email" placeholder="عنوان بريدك الإلكتروني" autoComplete="off" required />
										</div>

										{ //<!-- Form Message -->	
										}
										<div className="quick-form-msg"><span className="loading"></span></div>

									</form>

								</div>
							</div>	{ //<!-- END HERO TEXT -->	
							}


							{ //<!-- HERO IMAGE -->	
							}
							<div className="col-lg-6">
								<div className="hero-6-img text-center">
									<img className="img-fluid" src="images/img-06.png" alt="hero-image" />
								</div>
							</div>


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}


					{ //<!-- WAVE SHAPE BOTTOM -->	
					}
					<div className="wave-shape-bottom">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 215"><path fill="#ffffff" fillOpacity="1" d="M0,128L120,149.3C240,171,480,213,720,208C960,203,1200,149,1320,122.7L1440,96L1440,320L1320,320C1200,320,960,320,720,320C480,320,240,320,120,320L0,320Z"></path></svg>
					</div>


				</section>	{ //<!-- END HERO-6 -->	
				}




<Features8/>



				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="bg-snow content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-09.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">محسن تمامًا</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">اعمل بذكاء مع ميزات قوية</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-lg-6 order-last order-lg-2">
									<div className="txt-block slim-column left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">الأداء المتقدم أصبح سهلاً</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">الحل البرمجي الكامل</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- CB WRAPPER -->	
								}
								<div className="col-lg-6 order-first order-lg-2">
									<div className="cb-wrapper">

										{ //<!-- CB HOLDER -->	
										}
										<div className="cb-holder wow fadeInLeft">

											{ //<!-- CB BOX #1 -->	
											}
											<div className="cb-single-box">
												<p className="p-lg cb-header">زبائن الجدد</p>
												<h2 className="h2-title-xs statistic-number"><sup>+</sup><span className="count-element">784</span></h2>
												<p className="p-md mt-5 ico-10">
													<span className="green-color"><span className="flaticon-"></span> 4.6%</span> مقابل آخر 7 أيام
												</p>
											</div>

											<hr className="divider" />

											{ //<!-- CB BOX #2 -->	
											}
											<div className="cb-single-box">
												<ul className="simple-list">
													<li className="list-item">
														<p className="p-md">وهذا ما يجعله أول مولّد نص لوريم إيبسوم حقيقي على الإنترنت.</p>
													</li>

													<li className="list-item">
														<p className="p-md">وهذا ما يجعله أول مولّد نص لوريم إيبسوم حقيقي على الإنترنت.</p>
													</li>
												</ul>
											</div>

											{ //<!-- CB BOX #3 -->	
											}
											<div className="cb-single-box cb-box-rounded bg-green white-color mt-25">
												<h4 className="h4-lg">98.245</h4>
												<p className="p-lg">بعض الأمثلة النصية</p>
											</div>

										</div>	{ //<!-- END CB HOLDER -->	
										}


										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-1">
											<img className="img-fluid" src="images/bg-shape-1.png" alt="content-image" />
										</div>

										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-2">
											<img className="img-fluid" src="images/bg-shape-2.png" alt="content-image" />
										</div>


									</div>
								</div>	{ //<!-- END CB WRAPPER -->	
								}


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 wide-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">مرنة للغاية</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">اكتشف الميزات القوية لزيادة إنتاجيتك</h2>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center video-preview wow fadeInUp">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-pink ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10 -->	
				}




<Features4/>




				{ //<!-- STATISTIC-1

				}
				<div id="statistic-1" className="bg-01 pt-70 pb-70 statistic-section division">
					<div className="container white-color">


						{ //<!-- STATISTIC-1 WRAPPER -->	
						}
						<div className="statistic-1-wrapper">
							<div className="row justify-content-md-center row-cols-1 row-cols-md-3">


								{ //<!-- STATISTIC BLOCK #1 -->	
								}
								<div id="sb-1-1" className="col">
									<div className="statistic-block wow fadeInUp">

										{ //<!-- Digit -->	
										}
										<h2 className="h2-xl statistic-number"><span className="count-element">28</span>%</h2>

										{ //<!-- Text -->	
										}
										<h5 className="h5-lg">وصول أسرع</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
										</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #2 -->	
								}
								<div id="sb-1-2" className="col">
									<div className="statistic-block wow fadeInUp">

										{ //<!-- Digit -->	
										}
										<h2 className="h2-xl statistic-number"><span className="count-element">54</span>%</h2>

										{ //<!-- Text -->	
										}
										<h5 className="h5-lg">إنتاجية</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
										</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #3 -->	
								}
								<div id="sb-1-3" className="col">
									<div className="statistic-block wow fadeInUp">

										{ //<!-- Digit -->	
										}
										<h2 className="h2-xl statistic-number"><span className="count-element">36</span>%</h2>

										{ //<!-- Text -->	
										}
										<h5 className="h5-lg">وصول آمن</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
										</p>

									</div>
								</div>


							</div>
						</div>	{ //<!-- END STATISTIC-1 WRAPPER -->	
						}


					</div>	 { //<!-- End container -->	
					}
				</div>	 { //<!-- END STATISTIC-1 -->	
				}




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">إبداعي وعملي</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">منصة متعددة. متزامن دائما</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">وهذا ما يجعله أول مولّد نص لوريم إيبسوم حقيقي على الإنترنت.</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-19.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




				{ //<!-- PROJECTS-2

				}
				<section id="projects-2" className="pb-60 projects-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">نحن نهتم بالتفاصيل</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PROJECTS-2 WRAPPER -->	
						}
						<div className="row">
							<div className="col gallery-items-list">
								<div className="masonry-wrap grid-loaded">


									{ //<!-- PROJECT #1 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-05.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">لوريم إيبسوم لوريم إيبسوم عبارة عن نص زائف لكتاب عينة الطباعة.</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">تصميم غرافيك</p>

										</div>

									</div>	{ //<!-- END PROJECT #1 -->	
									}


									{ //<!-- PROJECT #2 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-02.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">لوريم إيبسوم لوريم إيبسوم عبارة عن نص زائف لكتاب عينة الطباعة.</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">واجهة المستخدم ، تصميم التفاعل</p>

										</div>

									</div>	{ //<!-- END PROJECT #2 -->	
									}


									{ //<!-- PROJECT #3 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-04.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">لوريم إيبسوم لوريم إيبسوم عبارة عن نص زائف لكتاب عينة الطباعة.</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UX ، رسم توضيحي</p>

										</div>

									</div>	{ //<!-- END PROJECT #3 -->	
									}


									{ //<!-- PROJECT #4 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-01.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">لوريم إيبسوم لوريم إيبسوم عبارة عن نص زائف لكتاب عينة الطباعة.</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">تصميم المواقع</p>

										</div>

									</div>	{ //<!-- END PROJECT #4 -->	
									}


									{ //<!-- PROJECT #5 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-03.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">لوريم إيبسوم لوريم إيبسوم عبارة عن نص زائف لكتاب عينة الطباعة.</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">تصميم المواقع</p>

										</div>

									</div>	{ //<!-- END PROJECT #5 -->	
									}


									{ //<!-- PROJECT #6 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-06.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Link -->	
											}
											<h5 className="h5-md">
												<a href="project-details.html">لوريم إيبسوم لوريم إيبسوم عبارة عن نص زائف لكتاب عينة الطباعة.</a>
											</h5>

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">واجهة المستخدم ، تصميم التفاعل</p>

										</div>

									</div>	{ //<!-- END PROJECT #6 -->	
									}


								</div>
							</div>
						</div>	{ //<!-- END PROJECTS-1 WRAPPER -->	
						}


						{ //<!-- MORE PROJECTS -->	
						}
						<div className="row">
							<div className="col">
								<div className="more-btn mt-20">
									<a href="projects.html" className="btn btn-stateblue tra-grey-hover">عرض المزيد من المشاريع</a>
								</div>
							</div>
						</div>	{ //<!-- END DOWNLOAD BUTTON -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PROJECTS-2 -->	
				}




				
				<hr className="divider" />




				{ //<!-- STATISTIC-2

				}
				<section id="statistic-2" className="wide-100 statistic-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- STATISTIC BLOCK #2 -->	
							}
							<div className="col-sm-6 col-md-7 col-lg-2 order-last order-lg-2">
								<div className="statistic-block m-row wow fadeInUp">

									{ //<!-- Text -->	
									}
									<h2 className="h2-title-xs statistic-number">
										<span className="count-element">4</span>.<span className="count-element">86</span>
									</h2>

									{ //<!-- Rating -->	
									}
									<div className="txt-block-rating ico-15 yellow-color">
										<span className="flaticon-star-1"></span>
										<span className="flaticon-star-1"></span>
										<span className="flaticon-star-1"></span>
										<span className="flaticon-star-1"></span>
										<span className="flaticon-star-half-empty"></span>
									</div>

									<p className="p-lg txt-400">تقييم 8،376</p>
								</div>
							</div>


							{ //<!-- STATISTIC BLOCK #1 -->	
							}
							<div className="col-sm-6 col-md-5 col-lg-3 offset-lg-1 order-last order-lg-2">
								<div className="statistic-block m-row wow fadeInUp">

									{ //<!-- Text -->	
									}
									<h2 className="h2-title-xs statistic-number m-bottom">ألف <span className="count-element">65</span></h2>
									<p className="p-lg mt-20">التنزيلات النشطة من المجتمع</p>

								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-lg-6 order-first order-lg-2">
								<div className="txt-block right-column wow fadeInLeft">
									<h3 className="h3-xs">أكثر من 65000 مستخدم حول العالم يستخدمون بالفعل OLMO بنشاط</h3>
								</div>
							</div>


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END STATISTIC-2 -->	
				}




				
				<hr className="divider" />



				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column video-preview wow fadeInRight">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-pink ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/img-08.png" alt="video-preview" />

								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-20">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">جميع الأدوات في مكان واحد</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.
										</p>

									</div>

									<hr />

									{ //<!-- CONTENT BOX #1 -->	
									}
									<div className="cbox-3 mb-10">
										<div className="cbox-3-ico ico-15"><span className="flaticon-check purple-color"></span></div>
										<div className="cbox-3-txt"><h6 className="h6-lg">لوريم إيبسوم حقيقي على الإنترنت.</h6></div>
									</div>

									{ //<!-- CONTENT BOX #2 -->	
									}
									<div className="cbox-3 mb-10">
										<div className="cbox-3-ico ico-15"><span className="flaticon-check purple-color"></span></div>
										<div className="cbox-3-txt"><h6 className="h6-lg">لوريم إيبسوم حقيقي على الإنترنت.</h6></div>
									</div>

									{ //<!-- CONTENT BOX #3 -->	
									}
									<div className="cbox-3 mb-10">
										<div className="cbox-3-ico ico-15"><span className="flaticon-check purple-color"></span></div>
										<div className="cbox-3-txt"><h6 className="h6-lg">لوريم إيبسوم حقيقي على الإنترنت.</h6></div>
									</div>

									{ //<!-- CONTENT BOX #4 -->	
									}
									<div className="cbox-3 mb-10">
										<div className="cbox-3-ico ico-15"><span className="flaticon-check purple-color"></span></div>
										<div className="cbox-3-txt"><h6 className="h6-lg">لوريم إيبسوم حقيقي على الإنترنت.</h6></div>
									</div>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




<Reviews4/>




<Brands/>



				
				<hr className="divider" />




				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">سهولة التكامل</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">مميزات بديهية ونتائج قوية</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
											</p>
										</li>

									</ul>

									{ //<!-- Tools List -->	
									}
									<div className="tools-list ico-40 mt-30">

										{ //<!-- Text -->	
										}
										<h6 className="h6-lg">التقنيات التي نستخدمها:</h6>

										{ //<!-- Icons -->	
										}
										<span className="flaticon-html-5 text-black-50"></span>
										<span className="flaticon-css-3 text-black-50"></span>
										<span className="flaticon-wordpress-logo text-black-50"></span>
										<span className="flaticon-js text-black-50"></span>
										<span className="flaticon-diamond-1 text-black-50"></span>

									</div>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-05.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




				{ //<!-- FAQs-2

				}
				<section id="faqs-2" className="pb-60 faqs-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-80">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">هل حصلت على الاسئلة؟ انظر هنا</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس
									</p>

								</div>
							</div>
						</div>


						{ //<!-- FAQs-2 QUESTIONS -->	
						}
						<div className="faqs-2-questions">
							<div className="row row-cols-1 row-cols-lg-2">


								{ //<!-- QUESTIONS HOLDER -->	
								}
								<div className="col">
									<div className="questions-holder pr-15">


										{ //<!-- QUESTION #1 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">هل يمكنني رؤية OLMO أثناء العمل قبل الشراء؟</h5>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
											</p>

										</div>


										{ //<!-- QUESTION #2 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">ما هي متطلبات استخدام OLMO؟</h5>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
											</p>

										</div>


										{ //<!-- QUESTION #3 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">هل يمكنني استخدام OLMO على أجهزة مختلفة؟</h5>

											{ //<!-- Answer -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
													</p>
												</li>

											</ul>

										</div>


									</div>
								</div>	{ //<!-- END QUESTIONS HOLDER -->	
								}


								{ //<!-- QUESTIONS HOLDER -->	
								}
								<div className="col">
									<div className="questions-holder pl-15">


										{ //<!-- QUESTION #4 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">هل لديك نسخة تجريبية مجانية؟</h5>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
											</p>

										</div>


										{ //<!-- QUESTION #5 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">كيف يتعامل OLMO مع خصوصيتي؟</h5>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
											</p>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
											</p>

										</div>


										{ //<!-- QUESTION #6 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">لدي مشكلة مع حسابي</h5>

											{ //<!-- Answer -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">وهذا ما يجعله أول مولّد نص لوريم إيبسوم حقيقي على الإنترنت.</p>
												</li>

												<li className="list-item">
													<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
													</p>
												</li>

											</ul>

										</div>


									</div>
								</div>	{ //<!-- END QUESTIONS HOLDER -->	
								}


							</div>	{ //<!-- End row -->	
							}
						</div>	{ //<!-- END FAQs-2 QUESTIONS -->	
						}


						{ //<!-- MORE QUESTIONS BUTTON -->	
						}
						<div className="row">
							<div className="col">
								<div className="more-questions">
									<h5 className="h5-sm">هل لديك المزيد من الأسئلة؟ <a href="contacts.html">اطرح سؤالك هنا</a></h5>
								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END FAQs-2 -->	
				}




				{ //<!-- PRICING-2

				}
				<section id="pricing-2" className="bg-whitesmoke-gradient wide-60 pricing-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-80">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">تسعير بسيط ومرن</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">بطاقة الإئتمان غير مطالب بها. تغيير أو إلغاء خطتك في أي وقت</p>

								</div>
							</div>
						</div>


						{ //<!-- PRICING TABLES -->	
						}
						<div className="pricing-2-row pc-25">
							<div className="row row-cols-1 row-cols-md-3">


								{ //<!-- BASIC PLAN -->	
								}
								<div className="col">
									<div className="pricing-2-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price -->	
										}
										<div className="pricing-plan">

											{ //<!-- Plan Title -->	
											}
											<div className="pricing-plan-title">
												<h5 className="h5-xs">أساسي</h5>
												<h6 className="h6-sm bg-lightgrey">وفر 30٪</h6>
											</div>

											{ //<!-- Price -->	
											}
											<sup className="validity dark-color">شهر / <span>99.</span></sup>
											<span className="dark-color">7</span>
											<sup className="dark-color">$</sup>
											<p className="p-md">دفع 96 دولارًا سنويًا</p>

										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md">25 مشروع</p></li>
											<li><p className="p-md">10 قاعدة بيانات mySQL</p></li>
											<li><p className="p-md">25 جيجا بايت من التخزين</p></li>
											<li><p className="p-md">دعم متميز</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-sm btn-tra-grey tra-stateblue-hover">اختر خطة</a>

									</div>
								</div>	{ //<!-- END BASIC PLAN -->	
								}


								{ //<!-- AGENCY PLAN -->	
								}
								<div className="col">
									<div className="pricing-2-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price -->	
										}
										<div className="pricing-plan">

											{ //<!-- Plan Title -->	
											}
											<div className="pricing-plan-title">
												<h5 className="h5-xs">وكالة</h5>
												<h6 className="h6-sm bg-lightgrey">وفر 25٪</h6>
											</div>

											{ //<!-- Price -->	
											}
											<sup className="validity dark-color">شهر / <span>25.</span></sup>
											<span className="dark-color">11</span>
											<sup className="dark-color">$</sup>
											<p className="p-md">دفع 135 دولارًا سنويًا</p>

										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md">100 مشروع</p></li>
											<li><p className="p-md">25 قاعدة بيانات mySQL</p></li>
											<li><p className="p-md">80 جيجا بايت من التخزين</p></li>
											<li><p className="p-md">دعم متميز</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-sm btn-tra-grey tra-stateblue-hover">اختر خطة</a>

									</div>
								</div>	{ //<!-- END AGENCY PLAN  -->	
								}


								{ //<!-- ADVANCED PLAN -->	
								}
								<div className="col">
									<div className="pricing-2-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan highlight">

											{ //<!-- Plan Title -->	
											}
											<div className="pricing-plan-title">
												<h5 className="h5-xs">متقدم</h5>
												<h6 className="h6-sm bg-stateblue white-color">شائع</h6>
											</div>

											{ //<!-- Price -->	
											}
											<sup className="validity dark-color">شهر / <span>99.</span></sup>
											<span className="dark-color">15</span>
											<sup className="dark-color">$</sup>
											<p className="p-md">دفع 199 دولارًا سنويًا</p>

										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md">مشاريع غير محدودة</p></li>
											<li><p className="p-md">50 قاعدة بيانات mySQL</p></li>
											<li><p className="p-md">500 جيجا بايت من التخزين</p></li>
											<li><p className="p-md">دعم VIP</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-sm btn-stateblue tra-grey-hover">اختر خطة</a>

									</div>
								</div>	{ //<!-- END ADVANCED PLAN -->	
								}


							</div>
						</div>	{ //<!-- END PRICING TABLES -->	
						}


						{ //<!-- PRICING NOTICE TEXT -->	
						}
						<div className="row">
							<div className="col-lg-10 offset-lg-1">
								<div className="pricing-notice text-center mb-40">
									<p className="p-md">الأسعار المذكورة أعلاه لا تشمل الضرائب المطبقة بناءً على عنوان إرسال الفواتير الخاص بك. سيتم عرض السعر النهائي على صفحة الخروج ، قبل إتمام الدفع
									</p>
								</div>
							</div>
						</div>


						{ //<!-- PAYMENT METHODS -->	
						}
						<div className="payment-methods pc-30">
							<div className="row row-cols-1 row-cols-md-3">

								{ //<!-- Payment Methods -->	
								}
								<div className="col col-lg-5">
									<div className="pbox mb-40">

										{ //<!-- Title -->	
										}
										<h6 className="h6-md">طرق الدفع المقبولة</h6>

										{ //<!-- Payment Icons -->	
										}
										<ul className="payment-icons ico-50">
											<li><img src="images/png-icons/visa.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/am.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/discover.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/paypal.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/jcb.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/shopify.png" alt="payment-icon" /></li>
										</ul>

									</div>
								</div>


								{ //<!-- Payment Guarantee -->	
								}
								<div className="col col-lg-4">
									<div className="pbox mb-40">

										{ //<!-- Title -->	
										}
										<h6 className="h6-md">ضمان استعادة الاموال</h6>

										{ //<!-- Text -->	
										}
										<p>استكشف OLMO Premium لمدة 14 يومًا. إذا لم يكن ذلك مناسبًا تمامًا ، فاسترد أموالك بالكامل.</p>

									</div>
								</div>


								{ //<!-- Payment Encrypted -->	
								}
								<div className="col col-lg-3">
									<div className="pbox mb-40">

										{ //<!-- Title -->	
										}
										<h6 className="h6-md">الدفع المشفر SSL</h6>

										{ //<!-- Text -->	
										}
										<p>معلوماتك محمية بواسطة تشفير 256 بت SSL.</p>

									</div>
								</div>

							</div>
						</div>	{ //<!-- END PAYMENT METHODS -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PRICING-2 -->	
				}




				{ //<!-- CALL TO ACTION-11

				}
				<section id="cta-11" className="cta-section division">
					<div className="container">
						<div className="bg-tra-purple cta-11-wrapper">
							<div className="row d-flex align-items-center">


								{ //<!-- CALL TO ACTION TEXT -->	
								}
								<div className="col-lg-7 col-lg-7">
									<div className="cta-11-txt">

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">هل أنت جاهز للانضمام إلى OLMO؟</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
										</p>

										{ //<!-- Button -->	
										}
										<a href="pricing.html" className="btn btn-stateblue tra-stateblue-hover">نبدأ الآن</a>

									</div>
								</div>


								{ //<!-- CALL TO ACTION BUTTON -->	
								}
								<div className="col-lg-5">
									<div className="text-end">
										<div className="cta-11-img text-center">
											<img className="img-fluid" src="images/img-25.png" alt="cta-image" />
										</div>
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CALL TO ACTION-11 -->	
				}



				<Footer1 mainCssClass="footer division" />






			</div>
		</React.Fragment>
	)
}
