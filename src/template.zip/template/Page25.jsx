import React from 'react'
import Brands from './components/Brands'
import Features4 from './components/Features4'
import Features8 from './components/Features8'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews4 from './components/Reviews4'
export default function Page25() {
	return (
		<React.Fragment>

			<div id="page" className="page rtl-direction">


				<Header mainCssClass="header tra-menu navbar-dark" />




				{ //<!-- HERO-10

				}
				<section id="hero-10" className="bg-scroll rel hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">
							<div className="col text-center">


								{ //<!-- HERO TEXT -->	
								}
								<div className="hero-10-txt">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md wow fadeInUp">
										تكامل المعلومات والتصميم والتكنولوجيا
									</h2>

									{ //<!-- Buttons Group -->	
									}
									<div className="btns-group wow fadeInUp">
										<a href="#content-3" className="btn btn-violet-red tra-violet-red-hover mr-15">اكتشف المزيد</a>
										<a href="#features-4" className="btn btn-tra-black tra-violet-red-hover">الميزات الأساسية</a>
									</div>

								</div>


								{ //<!-- HERO IMAGE -->	
								}
								<div className="hero-10-img video-preview wow fadeInUp">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-violet-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-07.png" alt="video-preview" />

								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-10 -->	
				}




<Features8/>




				{ //<!-- CONTENT-5

				}
				<section id="content-5" className="content-5 ws-wrapper content-section division">
					<div className="container">
						<div className="content-5-wrapper bg-whitesmoke">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- Section ID -->	
										}
										<span className="section-id purple-color txt-upcase">أداء سريع</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">اعمل بذكاء مع ميزات قوية</h2>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">وهذا ما يجعله أول مولّد نص لوريم إيبسوم حقيقي على الإنترنت.</p>
											</li>

											<li className="list-item">
												<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
												</p>
											</li>

										</ul>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-13.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-5 -->	
				}




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">حلول إبداعية جميلة</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس
									</p>

								</div>
							</div>
						</div>


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-06.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id purple-color txt-upcase">مرنة للغاية</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">مزيد من الإنتاجية بجهد أقل</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6 order-last order-md-2">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">الأداء المتقدم أصبح سهلاً</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">الحلول البديلة الإبداعية</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6 order-first order-md-2">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-09.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 bg-04 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column video-preview wow fadeInRight">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-violet-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/img-08.png" alt="video-preview" />

								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column white-color wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id white-color txt-upcase">محسن تمامًا</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">اجعل الأمر أبسط باستخدام الأوامر السريعة</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">وهذا ما يجعله أول مولّد نص لوريم إيبسوم حقيقي على الإنترنت.</p>
										</li>

										<li className="list-item">
											<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-25">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">أدوات التحرير والصادرات</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">منصة متعددة. متزامن دائما</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-05.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




			<Features4/>



				
				<hr className="divider" />




				{ //<!-- STATISTIC-2

				}
				<section id="statistic-2" className="wide-100 statistic-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- STATISTIC BLOCK #2 -->	
							}
							<div className="col-sm-6 col-md-7 col-lg-2 order-last order-lg-2">
								<div className="statistic-block m-row wow fadeInUp">

									{ //<!-- Text -->	
									}
									<h2 className="h2-title-xs statistic-number">
										<span className="count-element">4</span>.<span className="count-element">86</span>
									</h2>

									{ //<!-- Rating -->	
									}
									<div className="txt-block-rating ico-15 yellow-color">
										<span className="flaticon-star-1"></span>
										<span className="flaticon-star-1"></span>
										<span className="flaticon-star-1"></span>
										<span className="flaticon-star-1"></span>
										<span className="flaticon-star-half-empty"></span>
									</div>

									<p className="p-lg txt-400">تقييم 8،376</p>
								</div>
							</div>


							{ //<!-- STATISTIC BLOCK #1 -->	
							}
							<div className="col-sm-6 col-md-5 col-lg-3 offset-lg-1 order-last order-lg-2">
								<div className="statistic-block m-row wow fadeInUp">

									{ //<!-- Text -->	
									}
									<h2 className="h2-title-xs statistic-number m-bottom">ألف <span className="count-element">65</span></h2>
									<p className="p-lg mt-20">التنزيلات النشطة من المجتمع</p>

								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-lg-6 order-first order-lg-2">
								<div className="txt-block right-column wow fadeInLeft">
									<h3 className="h3-xs">أكثر من 65000 مستخدم حول العالم يستخدمون بالفعل OLMO بنشاط</h3>
								</div>
							</div>


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END STATISTIC-2 -->	
				}




				
				<hr className="divider" />



				<Reviews4/>



<Brands/>




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 bg-whitesmoke-gradient wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">سريع وسهل وآمن</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">سجل في 30 ثانية</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">وهذا ما يجعله أول مولّد نص لوريم إيبسوم حقيقي على الإنترنت.</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-20.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




				{ //<!-- FAQs-2

				}
				<section id="faqs-2" className="pb-60 faqs-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-80">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">هل حصلت على الاسئلة؟ انظر هنا</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس
									</p>

								</div>
							</div>
						</div>


						{ //<!-- FAQs-2 QUESTIONS -->	
						}
						<div className="faqs-2-questions">
							<div className="row row-cols-1 row-cols-lg-2">


								{ //<!-- QUESTIONS HOLDER -->	
								}
								<div className="col">
									<div className="questions-holder pr-15">


										{ //<!-- QUESTION #1 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">هل يمكنني رؤية OLMO أثناء العمل قبل الشراء؟</h5>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
											</p>

										</div>


										{ //<!-- QUESTION #2 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">ما هي متطلبات استخدام OLMO؟</h5>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
											</p>

										</div>


										{ //<!-- QUESTION #3 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">هل يمكنني استخدام OLMO على أجهزة مختلفة؟</h5>

											{ //<!-- Answer -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
													</p>
												</li>

											</ul>

										</div>


									</div>
								</div>	{ //<!-- END QUESTIONS HOLDER -->	
								}


								{ //<!-- QUESTIONS HOLDER -->	
								}
								<div className="col">
									<div className="questions-holder pl-15">


										{ //<!-- QUESTION #4 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">هل لديك نسخة تجريبية مجانية؟</h5>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
											</p>

										</div>


										{ //<!-- QUESTION #5 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">كيف يتعامل OLMO مع خصوصيتي؟</h5>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
											</p>

											{ //<!-- Answer -->	
											}
											<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
											</p>

										</div>


										{ //<!-- QUESTION #6 -->	
										}
										<div className="question wow fadeInUp">

											{ //<!-- Question -->	
											}
											<h5 className="h5-md">لدي مشكلة مع حسابي</h5>

											{ //<!-- Answer -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">وهذا ما يجعله أول مولّد نص لوريم إيبسوم حقيقي على الإنترنت.</p>
												</li>

												<li className="list-item">
													<p className="p-lg">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر
													</p>
												</li>

											</ul>

										</div>


									</div>
								</div>	{ //<!-- END QUESTIONS HOLDER -->	
								}


							</div>	{ //<!-- End row -->	
							}
						</div>	{ //<!-- END FAQs-2 QUESTIONS -->	
						}


						{ //<!-- MORE QUESTIONS BUTTON -->	
						}
						<div className="row">
							<div className="col">
								<div className="more-questions">
									<h5 className="h5-sm">هل لديك المزيد من الأسئلة؟ <a href="contacts.html">اطرح سؤالك هنا</a></h5>
								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END FAQs-2 -->	
				}




				{ //<!-- CALL TO ACTION-11

				}
				<section id="cta-11" className="bg-snow cta-section division">
					<div className="container">
						<div className="bg-tra-purple cta-11-wrapper">
							<div className="row d-flex align-items-center">


								{ //<!-- CALL TO ACTION TEXT -->	
								}
								<div className="col-lg-7 col-lg-7">
									<div className="cta-11-txt">

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">هل أنت جاهز للانضمام إلى OLMO؟</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
										</p>

										{ //<!-- Button -->	
										}
										<a href="pricing.html" className="btn btn-violet-red tra-violet-red-hover">نبدأ الآن</a>

									</div>
								</div>


								{ //<!-- CALL TO ACTION BUTTON -->	
								}
								<div className="col-lg-5">
									<div className="text-end">
										<div className="cta-11-img text-center">
											<img className="img-fluid" src="images/img-25.png" alt="cta-image" />
										</div>
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CALL TO ACTION-11 -->	
				}




				{ //<!-- BLOG-1

				}
				<section id="blog-1" className="wide-60 blog-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">قصصنا وآخر الأخبار</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">لوريم إيبسوم هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس
									</p>

								</div>
							</div>
						</div>


						{ //<!-- BLOG POSTS -->	
						}
						<div className="row row-cols-1 row-cols-md-2 row-cols-lg-3">


							{ //<!-- BLOG POST #1 -->	
							}
							<div className="col">
								<div id="bp-1-1" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-1-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">أخبار OLMO &ensp;|&ensp; 12 يونيو 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">هناك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولك</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
										</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">9 تعليقات</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #1 -->	
							}


							{ //<!-- BLOG POST #2 -->	
							}
							<div className="col">
								<div id="bp-1-2" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-5-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">دروس &ensp;|&ensp; 3 يونيو 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">هناك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولك</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">وهذا ما يجعله أول مولّد نص لوريم إيبسوم حقيقي على الإنترنت.</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">12 تعليقات</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #2 -->	
							}


							{ //<!-- BLOG POST #3 -->	
							}
							<div className="col">
								<div id="bp-1-3" className="blog-1-post mb-40 wow fadeInUp">

									{ //<!-- BLOG POST IMAGE -->	
									}
									<div className="blog-post-img">
										<div className="hover-overlay">
											<img className="img-fluid" src="images/blog/post-2-img.jpg" alt="blog-post-image" />
											<div className="item-overlay"></div>
										</div>
									</div>

									{ //<!-- BLOG POST TEXT -->	
									}
									<div className="blog-post-txt">

										{ //<!-- Post Tag -->	
										}
										<p className="p-md post-tag">إلهام &ensp;|&ensp; 18 مايو 2021</p>

										{ //<!-- Post Link -->	
										}
										<h5 className="h5-md">
											<a href="single-post.html">هناك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولك</a>
										</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.
										</p>

										{ //<!-- Post Meta -->	
										}
										<div className="post-meta"><p className="p-md">4 تعليقات</p></div>

									</div>	{ //<!-- END BLOG POST TEXT -->	
									}

								</div>
							</div>	{ //<!-- END  BLOG POST #3 -->	
							}


						</div>	{ //<!-- END BLOG POSTS -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END BLOG-1 -->	
				}




				
				<hr className="divider" />




				{ //<!-- NEWSLETTER-2

				}
				<section id="newsletter-2" className="pt-60 pb-60 newsletter-section division">
					<div className="container">
						<div className="row d-flex align-items-center row-cols-1 row-cols-lg-2">


							{ //<!-- NEWSLETTER FORM -->	
							}
							<div className="col order-last order-lg-2">
								<form className="newsletter-form">

									<div className="input-group">
										<span className="input-group-btn">
											<button type="submit" className="btn btn-violet-red black-hover">إشترك الآن</button>
										</span>
										<input type="email" autoComplete="off" className="form-control" placeholder="عنوان بريدك الإلكتروني" required id="s-email" />
									</div>

									{ //<!-- Newsletter Form Notification -->	
									}
									<label for="s-email" className="form-notification"></label>

								</form>
							</div>	  { //<!-- END NEWSLETTER FORM -->	
							}


							{ //<!-- NEWSLETTER TEXT -->	
							}
							<div className="col order-first order-lg-2">
								<div className="newsletter-txt pl-20">
									<h4 className="h4-xl">ابق على اطلاع بأخبارنا وأفكارنا وتحديثاتنا</h4>
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END NEWSLETTER-2 -->	
				}




				
				<hr className="divider" />


				<Footer1 mainCssClass="footer division" />






			</div>
		</React.Fragment>
	)
}
