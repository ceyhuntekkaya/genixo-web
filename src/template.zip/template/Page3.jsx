import React from 'react'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Features4 from './components/Features4'
import Features8 from './components/Features8'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews1 from './components/Reviews1'
import Statistic4 from './components/Statistic4'
import TrialLink from './components/TrialLink'

export default function Page3() {
	return (
		<React.Fragment>
			<div id="page" className="page">
				<Header mainCssClass="header tra-menu navbar-light" />

				<section id="hero-3" className="bg-scroll hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">

							{ //<!-- HERO TEXT -->	
							}
							<div className="col-lg-6">
								<div className="hero-3-txt white-color">
									{ //<!-- Title -->	
									}
									<h2 className="h2-lg wow fadeInUp">Impressive Web Marketing Solutions</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl wow fadeInUp">
										Feugiat primis a ligula undo auctor mauris auctor laoreet pretium augue egestas mauris in
										cubilia rutrum justo and mullam donec nihil impedit ligula risus donec
									</p>

									{ //<!-- Buttons Group -->	
									}
									<div className="btns-group mb-30 wow fadeInUp">
										<a href="#content-2" className="btn btn-green tra-white-hover mr-15">Get Started</a>
										<a href="https://www.youtube.com/watch?v=7e90gBu4pas" className="video-popup2 btn btn-md btn-transparent ico-20 ico-left">
											<span className="flaticon-play"></span> See how it works
										</a>
									</div>

									{ //<!-- Advantages List -->	
									}
									<ul className="advantages clearfix wow fadeInUp">
										<li className="first-li"><p>Free 30 days trial</p></li>
										<li><p>Exclusive Support</p></li>
										<li className="last-li"><p>No Fees</p></li>
									</ul>

								</div>
							</div>	{ //<!-- END HERO TEXT -->	
							}

							{ //<!-- HERO IMAGE -->	
							}
							<div className="col-lg-6">
								<div className="hero-3-img wow fadeInRight">
									<img className="img-fluid" src="images/tablet-01.png" alt="hero-image" />
								</div>
							</div>


						</div>	    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}


					{ //<!-- WAVE SHAPE BOTTOM -->	
					}
					<div className="wave-shape-bottom">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 195"><path fill="#ffffff" fillOpacity="1" d="M0,192L1440,96L1440,320L0,320Z"></path></svg>
					</div>


				</section>	{ //<!-- END HERO-3 -->	
				}
				<Brands />
				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-15.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Digital Strategy</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Start your online business with OLMO</h2>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
										laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
									</p>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
										laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
										turpis dolores aliquam quaerat sodales a sapien
									</p>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}

				{ //<!-- FEATURES-8

				}
				<Features8/>

				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 bg-whitesmoke wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-25">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Advanced Analytics Review</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Search Engine Optimization (SEO)</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}


								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-01.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Security, Simplicity, Easiness</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-14.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">All-in-One Marketing Solutions</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Strategy and Analytics Consulting</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-lg-6 order-last order-lg-2">
									<div className="txt-block slim-column left-column wow fadeInRight">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Totally Optimized</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">More productivity with less effort</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- CB WRAPPER -->	
								}
								<div className="col-lg-6 order-first order-lg-2">
									<div className="cb-wrapper">

										{ //<!-- CB HOLDER -->	
										}
										<div className="cb-holder wow fadeInLeft">

											{ //<!-- CB BOX #1 -->	
											}
											<div className="cb-single-box">
												<p className="p-lg cb-header">New Customers</p>
												<h2 className="h2-title-xs statistic-number"><sup>+</sup><span className="count-element">784</span></h2>
												<p className="p-md mt-5 ico-10">
													<span className="green-color"><span className="flaticon-"></span> 4.6%</span> vs last 7 days
												</p>
											</div>

											<hr className="divider" />

											{ //<!-- CB BOX #2 -->	
											}
											<div className="cb-single-box">
												<ul className="simple-list">
													<li className="list-item">
														<p className="p-md">Fringilla risus luctus mauris auctor and purus euismod purus</p>
													</li>

													<li className="list-item">
														<p className="p-md">Nemo ipsam volute turpis dolores ut quaerat sodales sapien</p>
													</li>
												</ul>
											</div>

											{ //<!-- CB BOX #3 -->	
											}
											<div className="cb-single-box cb-box-rounded bg-green white-color mt-25">
												<h4 className="h4-lg">98.245</h4>
												<p className="p-lg">Ligula risus auctor tempus</p>
											</div>

										</div>	{ //<!-- END CB HOLDER -->	
										}


										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-1">
											<img className="img-fluid" src="images/bg-shape-1.png" alt="content-image" />
										</div>

										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-2">
											<img className="img-fluid" src="images/bg-shape-2.png" alt="content-image" />
										</div>


									</div>
								</div>	{ //<!-- END CB WRAPPER -->	
								}


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}

				<Features4 />

				{ //<!-- CONTENT-2A

				}
				<section id="content-2a" className="content-2 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-16.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Online Marketing</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Committed to top quality and results</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2A -->	
				}

				{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 pb-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Your road to success</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Marketing solutions that fuel your business growth</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque at dolor primis libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center video-preview">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-green ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/seo-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


						{ //<!-- ADVANTAGES LIST -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-10-btn">
									<ul className="advantages mt-25 clearfix">
										<li className="first-li"><p>Free 30 days trial</p></li>
										<li><p>Exclusive Support</p></li>
										<li className="last-li"><p>No Fees</p></li>
									</ul>
								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10 -->	
				}

				
				<hr className="divider" />

				<Statistic4 />

				
				<hr className="divider" />

				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Advanced Analytics Review</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit undo vitae ipsum primis and cubilia
											a laoreet augue and luctus magna dolor egestas luctus
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Email Marketing Campaigns</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris an auctor purus euismod iaculis luctus
													magna purus pretium ligula and quaerat luctus magna
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													sodales
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-20.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}

				<Reviews1 />

				{ //<!-- CONTENT-1

				}
				<section id="content-1" className="content-1 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Extremely Flexible</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Organize your business fast & easily</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6 order-first order-md-2">
								<div className="rel img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-17.png" alt="content-image" />
								</div>
							</div>


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-1 -->	
				}


				{ //<!-- STATISTIC-3

				}
				<section id="statistic-3" className="bg-02 statistic-section division">
					<div className="container">
						<div className="statistic-3-wrapper white-color text-center">
							<div className="row row-cols-1 row-cols-sm-2 row-cols-md-4">


								{ //<!-- STATISTIC BLOCK #1 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65">
											<span className="flaticon-web-programming"></span>
										</div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">4,<span className="count-element">497</span></h3>
										<p className="p-lg txt-400">Finished Projects</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #2 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65">
											<span className="flaticon-shuttle"></span>
										</div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">3,<span className="count-element">889</span></h3>
										<p className="p-lg txt-400">Websites Improved</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #3 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65">
											<span className="flaticon-speech-bubble-3"></span>
										</div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">5,<span className="count-element">179</span></h3>
										<p className="p-lg txt-400">Happy Customers</p>

									</div>
								</div>


								{ //<!-- STATISTIC BLOCK #4 -->	
								}
								<div className="col">
									<div className="statistic-block mb-40 wow fadeInUp">

										{ //<!-- Icon  -->	
										}
										<div className="statistic-ico ico-65"><span className="flaticon-help"></span></div>

										{ //<!-- Text -->	
										}
										<h3 className="h3-md statistic-number">1,<span className="count-element">473</span></h3>
										<p className="p-lg txt-400">Tickets Closed</p>

									</div>
								</div>


							</div>    { //<!-- End row -->	
							}
						</div>    { //<!-- End statistic-3-wrapper -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END STATISTIC-3 -->	
				}

				<Faq2 />

				{ //<!-- PRICING-2

				}
				<section id="pricing-2" className="bg-whitesmoke wide-60 pricing-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-80">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Simple And Flexible Pricing</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">No credit card required. Change or cancel your plan anytime</p>

								</div>
							</div>
						</div>


						{ //<!-- PRICING TABLES -->	
						}
						<div className="pricing-2-row pc-25">
							<div className="row row-cols-1 row-cols-md-3">


								{ //<!-- BASIC PLAN -->	
								}
								<div className="col">
									<div className="pricing-2-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price -->	
										}
										<div className="pricing-plan">

											{ //<!-- Plan Title -->	
											}
											<div className="pricing-plan-title">
												<h5 className="h5-xs">Basic</h5>
												<h6 className="h6-sm bg-lightgrey">Save 30%</h6>
											</div>

											{ //<!-- Price -->	
											}
											<sup className="dark-color">$</sup>
											<span className="dark-color">7</span>
											<sup className="validity dark-color"><span>.99</span> / month</sup>
											<p className="p-md">Billed as $96 per year</p>

										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md"><span>25</span> Projects</p></li>
											<li><p className="p-md"><span>10</span> mySQL Database</p></li>
											<li><p className="p-md"><span>25 GB</span> of Storage</p></li>
											<li><p className="p-md"><span>Premium</span> Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-sm btn-tra-grey tra-green-hover">Select Plan</a>

									</div>
								</div>	{ //<!-- END BASIC PLAN -->	
								}


								{ //<!-- AGENCY PLAN -->	
								}
								<div className="col">
									<div className="pricing-2-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price -->	
										}
										<div className="pricing-plan">

											{ //<!-- Plan Title -->	
											}
											<div className="pricing-plan-title">
												<h5 className="h5-xs">Agency</h5>
												<h6 className="h6-sm bg-lightgrey">Save 25%</h6>
											</div>

											{ //<!-- Price -->	
											}
											<sup className="dark-color">$</sup>
											<span className="dark-color">11</span>
											<sup className="validity dark-color"><span>.25</span> / month</sup>
											<p className="p-md">Billed as $135 per year</p>

										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md"><span>100</span> Projects</p></li>
											<li><p className="p-md"><span>25</span> mySQL Database</p></li>
											<li><p className="p-md"><span>80 GB</span> of Storage</p></li>
											<li><p className="p-md"><span>Premium</span> Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-sm btn-tra-grey tra-green-hover">Select Plan</a>

									</div>
								</div>	{ //<!-- END AGENCY PLAN  -->	
								}


								{ //<!-- ADVANCED PLAN -->	
								}
								<div className="col">
									<div className="pricing-2-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan highlight">

											{ //<!-- Plan Title -->	
											}
											<div className="pricing-plan-title">
												<h5 className="h5-xs">Advanced</h5>
												<h6 className="h6-sm bg-green white-color">Popular</h6>
											</div>

											{ //<!-- Price -->	
											}
											<sup className="dark-color">$</sup>
											<span className="dark-color">15</span>
											<sup className="validity dark-color"><span>.99</span> / month</sup>
											<p className="p-md">Billed as $199 per year</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md"><span>Unlimited</span> Projects</p></li>
											<li><p className="p-md"><span>50</span> mySQL Database</p></li>
											<li><p className="p-md"><span>500 GB</span> of Storage</p></li>
											<li><p className="p-md"><span>VIP</span> Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-sm btn-green tra-grey-hover">Select Plan</a>

									</div>
								</div>	{ //<!-- END ADVANCED PLAN -->	
								}


							</div>
						</div>	{ //<!-- END PRICING TABLES -->	
						}


						{ //<!-- PRICING NOTICE TEXT -->	
						}
						<div className="row">
							<div className="col-lg-10 offset-lg-1">
								<div className="pricing-notice text-center mb-40">
									<p className="p-md">The above prices do not include applicable taxes based on your billing address.
										The final price will be displayed on the checkout page, before the payment is completed
									</p>
								</div>
							</div>
						</div>


						{ //<!-- PAYMENT METHODS -->	
						}
						<div className="payment-methods pc-30">
							<div className="row row-cols-1 row-cols-md-3">

								{ //<!-- Payment Methods -->	
								}
								<div className="col col-lg-5">
									<div className="pbox mb-40">

										{ //<!-- Title -->	
										}
										<h6 className="h6-md">Accepted Payment Methods</h6>

										{ //<!-- Payment Icons -->	
										}
										<ul className="payment-icons ico-50">
											<li><img src="images/png-icons/visa.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/am.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/discover.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/paypal.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/jcb.png" alt="payment-icon" /></li>
											<li><img src="images/png-icons/shopify.png" alt="payment-icon" /></li>
										</ul>

									</div>
								</div>


								{ //<!-- Payment Guarantee -->	
								}
								<div className="col col-lg-4">
									<div className="pbox mb-40">

										{ //<!-- Title -->	
										}
										<h6 className="h6-md">Money Back Guarantee</h6>

										{ //<!-- Text -->	
										}
										<p>Explore OLMO Premium for 14 days. If it’s not a perfect fit, receive a full refund.</p>

									</div>
								</div>


								{ //<!-- Payment Encrypted -->	
								}
								<div className="col col-lg-3">
									<div className="pbox mb-40">

										{ //<!-- Title -->	
										}
										<h6 className="h6-md">SSL Encrypted Payment</h6>

										{ //<!-- Text -->	
										}
										<p>Your information is protected by 256-bit SSL encryption.</p>

									</div>
								</div>

							</div>
						</div>	{ //<!-- END PAYMENT METHODS -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PRICING-2 -->	
				}

				<TrialLink />
				<Footer1 mainCssClass="footer division" />
			</div>
		</React.Fragment>
	)
}
