import React from 'react'
import Footer1 from './components/Footer1'
import Header from './components/Header'

const lang = require('../data/pages.json')

export default function Page404() {
    return (
        <React.Fragment>
            <div id="page" className="page">
                <Header mainCssClass="header tra-menu navbar-dark" />
                <section id="hero-24" className="bg-tra-blue hero-section division">
                    <div className="container">
                        <div className="row d-flex align-items-center">
                            <div className="col-md-8 col-lg-6 offset-md-2 offset-lg-3">
                                <div className="hero-24-txt text-center">
                                    <div className="rel hero-24-img">
                                        <img className="img-fluid" src="images/error-404.png" alt="error-404-img" />
                                        <h2 className="tra-header">{lang.NotFound.number}</h2>
                                    </div>
                                    <h2 className="h2-md">{lang.NotFound.text}</h2>
                                    <h5 className="h5-md">{lang.NotFound.explain} </h5>
                                    <a href="/" className="btn btn-skyblue tra-grey-hover">{lang.NotFound.button}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <Footer1 mainCssClass="bg-tra-blue footer division" />
            </div>
        </React.Fragment>
    )
}
