import React from 'react'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Features8 from './components/Features8'
import Reviews1 from './components/Reviews1'
import Statistic2 from './components/Statistic2'
import Features4 from './components/Features4'
import Journey from '../pages/Journey'

export default function Page5() {
	return (
		<React.Fragment>

			<div id="page" className="page">

				<Header mainCssClass="header tra-menu navbar-dark" />


				<section id="hero-5" className="bg-snow hero-section division">
					<div className="container">
						<div className="row justify-content-md-center d-flex align-items-center">


							{ //<!-- HERO IMAGE -->	
							}
							<div className="col-md-7 col-lg-7">
								<div className="hero-5-img">
									<img className="img-fluid" src="images/hero-5-img.png" alt="hero-image" />
								</div>
							</div>


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-md-5 col-lg-4">
								<div className="hero-5-txt">
									<ul className="hero-5-list">

										<li className="first-li"><h4 className="h4-xl">OLMO</h4></li>

										<li>
											<h5 className="h5-xl">2.4.11</h5>
											<span className="grey-color">Current version</span>
										</li>

										<li>
											<h5 className="h5-xl">macOS</h5>
											<span className="grey-color">For Mac OS X 10.8.5+</span>
										</li>

										<li className="last-li ico-left">
											<a href="download.html" className="btn btn-violet-red tra-grey-hover ico-15 ico-left">
												<span className="flaticon-down-arrow"></span> Download Now
											</a>
										</li>

									</ul>
								</div>
							</div>	{ //<!-- END HERO TEXT -->	
							}


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END HERO-5 -->	
				}




<Statistic2/>




				
				<hr className="divider" />




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="bg-snow content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-09.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Fast Performance</span>

										{ //<!-- Title -->	
										}
										<h2 className="h2-xs">More productivity with less effort</h2>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-lg-6 order-last order-lg-2">
									<div className="txt-block slim-column left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">Advanced Performance Made Easy</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-lg">The Complete Software Solution</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- CB WRAPPER -->	
								}
								<div className="col-lg-6 order-first order-lg-2">
									<div className="cb-wrapper">

										{ //<!-- CB HOLDER -->	
										}
										<div className="cb-holder wow fadeInLeft">

											{ //<!-- CB BOX #1 -->	
											}
											<div className="cb-single-box">
												<p className="p-lg cb-header">New Customers</p>
												<h2 className="h2-title-xs statistic-number"><sup>+</sup><span className="count-element">784</span></h2>
												<p className="p-md mt-5 ico-10">
													<span className="violet-red-color"><span className="flaticon-"></span> 4.6%</span> vs last 7 days
												</p>
											</div>

											<hr className="divider" />

											{ //<!-- CB BOX #2 -->	
											}
											<div className="cb-single-box">
												<ul className="simple-list">
													<li className="list-item">
														<p className="p-md">Fringilla risus luctus mauris auctor and purus euismod purus</p>
													</li>

													<li className="list-item">
														<p className="p-md">Nemo ipsam volute turpis dolores ut quaerat sodales sapien</p>
													</li>
												</ul>
											</div>

											{ //<!-- CB BOX #3 -->	
											}
											<div className="cb-single-box cb-box-rounded bg-violet-red white-color mt-25">
												<h4 className="h4-lg">98.245</h4>
												<p className="p-lg">Ligula risus auctor tempus</p>
											</div>

										</div>	{ //<!-- END CB HOLDER -->	
										}


										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-1">
											<img className="img-fluid" src="images/bg-shape-1.png" alt="content-image" />
										</div>

										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-2">
											<img className="img-fluid" src="images/bg-shape-2.png" alt="content-image" />
										</div>


									</div>
								</div>	{ //<!-- END CB WRAPPER -->	
								}


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




<Features8/>




				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 bg-04 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column video-preview wow fadeInRight">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-violet-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/img-08.png" alt="video-preview" />

								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column white-color wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id white-color txt-upcase">Totally Optimized</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Work smarter with powerful features</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 bg-snow wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Editing Tools and Exports</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit undo vitae ipsum primis and cubilia
											a laoreet augue and luctus magna dolor egestas luctus sapien vitae nemo egestas volute
											and turpis
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-lg">Multiplatform. Always Synced</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris an auctor purus euismod iaculis luctus
													magna purus pretium ligula and quaerat luctus magna
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													sodales
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-19.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




				{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 bg-snow pb-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Extremely Flexible</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Discover powerful features to boost your productivity</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque at dolor primis libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center video-preview wow fadeInUp">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-violet-red ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/dashboard-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10 -->	
				}




<Features4/>



<Reviews1/>




				{ //<!-- CONTENT-2A

				}
				<section id="content-2a" className="content-2 bg-snow wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/img-06.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Handling With Ease</span>

									{ //<!-- Title -->	
									}
									<h2 className="h2-xs">Make it simpler with Quick Commands</h2>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2A -->	
				}




				
				<hr className="divider" />




				<Brands/>


				
				<hr className="divider" />




				<Faq2/>



				{ //<!-- CALL TO ACTION-11

				}

<Journey className="bg-snow cta-section division"/>




				<Footer1 mainCssClass="bg-snow footer division" />






			</div>
		</React.Fragment>
	)
}
