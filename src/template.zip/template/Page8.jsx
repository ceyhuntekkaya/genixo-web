import React from 'react'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Features4 from './components/Features4'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews1 from './components/Reviews1'
import Statistic4 from './components/Statistic4'
import TrialLink from './components/TrialLink'
export default function Page8() {
	return (
		<React.Fragment>



			<div id="page" className="page">




				<Header mainCssClass="header tra-menu navbar-dark" />





				{ //<!-- HERO-8

				}
				<section id="hero-8" className="bg-fixed hero-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- HERO IMAGE -->	
							}
							<div className="col-lg-6 order-last order-lg-2">
								<div className="hero-8-img pc-20 text-center">
									<img className="img-fluid" src="images/hero-8-img.png" alt="hero-image" />
								</div>
							</div>


							{ //<!-- HERO TEXT -->	
							}
							<div className="col-lg-6 order-first order-lg-2">
								<div className="hero-8-txt">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">Generating leads with social media marketing</h2>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Feugiat primis ligula risus auctor egestas and augue viverra mauri tortor
										in iaculis magna feugiat mauris ipsum and placerat viverra tortor gravida purus
									</p>

									{ //<!-- HERO QUICK FORM -->	
									}
									<form name="quickform" className="quick-form shadow-form">

										{ //<!-- Form Inputs -->	
										}
										<div className="input-group">
											<input type="email" name="email" className="form-control email" placeholder="Your email address" autoComplete="off" required />
											<span className="input-group-btn form-btn">
												<button type="submit" className="btn btn-md btn-skyblue black-hover submit">Get Started</button>
											</span>
										</div>

										{ //<!-- Form Message -->	
										}
										<div className="quick-form-msg"><span className="loading"></span></div>

									</form>

								</div>
							</div>	{ //<!-- END HERO TEXT -->	
							}


						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}


					{ //<!-- WAVE SHAPE BOTTOM -->	
					}
					<div className="wave-shape-bottom">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 140"><path fill="#ffffff" fillOpacity="1" d="M0,64L120,74.7C240,85,480,107,720,117.3C960,128,1200,128,1320,128L1440,128L1440,320L1320,320C1200,320,960,320,720,320C480,320,240,320,120,320L0,320Z"></path></svg>
					</div>


				</section>	{ //<!-- END HERO-8 -->	
				}




				{ //<!-- FEATURES-5

				}
				<section id="features-5" className="wide-60 features-section division">
					<div className="container">


						{ //<!-- FEATURES-5 WRAPPER -->	
						}
						<div className="fbox-5-wrapper text-center">
							<div className="row row-cols-1 row-cols-md-3">


								{ //<!-- FEATURE BOX #1 -->	
								}
								<div className="col">
									<div className="fbox-5 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="ico-70 skyblue-color">
											<span className="flaticon-analytics"></span>
										</div>

										{ //<!-- Title -->	
										}
										<h5 className="h5-sm">Digital Marketing</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Porta semper lacus and cursus blandit at feugiat primis ultrice a purus
											euismod neque
										</p>

									</div>
								</div>


								{ //<!-- FEATURE BOX #2 -->	
								}
								<div className="col">
									<div className="fbox-5 bg-white mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="ico-70 skyblue-color">
											<span className="flaticon-web-search-engine"></span>
										</div>

										{ //<!-- Title -->	
										}
										<h5 className="h5-sm">SEO Services</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Porta semper lacus and cursus blandit at feugiat primis ultrice a purus
											euismod neque
										</p>

									</div>
								</div>


								{ //<!-- FEATURE BOX #3 -->	
								}
								<div className="col">
									<div className="fbox-5 mb-40 wow fadeInUp">

										{ //<!-- Icon -->	
										}
										<div className="ico-70 skyblue-color">
											<span className="flaticon-line-graph-1"></span>
										</div>

										{ //<!-- Title -->	
										}
										<h5 className="h5-sm">Business Analytics</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Porta semper lacus and cursus blandit at feugiat primis ultrice a purus
											euismod neque
										</p>

									</div>
								</div>


							</div>  { //<!-- End row -->	
							}
						</div>	{ //<!-- END FEATURES-5 WRAPPER -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END FEATURES-5 -->	
				}




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 pb-60 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-sm">Get More Customers Online</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-30">

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Advanced Analytics Review</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit undo vitae ipsum primis and cubilia
											a laoreet augue and luctus magna dolor egestas luctus sapien vitae nemo egestas volute
											and turpis
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Email Marketing Campaigns</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris an auctor purus euismod iaculis luctus
													magna purus pretium ligula and quaerat luctus magna
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													sodales
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/seo-06.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 pb-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/seo-01.png" alt="video-preview" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Right Strategies and Implementations</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
													magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
													quaerat at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




				{ //<!-- CONTENT-5

				}
				<section id="content-5" className="content-5 ws-wrapper content-section division">
					<div className="container">
						<div className="content-5-wrapper bg-whitesmoke">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Quick and Secure</span>

										{ //<!-- Title -->	
										}
										<h3 className="h3-lg">Committed to top quality and results</h3>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat sapien rutrum mauris auctor
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores ligula and aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/seo-04.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-5 -->	
				}




				<Features4 />





				<hr className="divider" />




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-70">

									{ //<!-- Title -->	
									}
									<h2 className="h2-sm">Ready to Grow Your Business?</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/seo-03.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Section ID -->	
										}
										<span className="section-id txt-upcase">Digital Strategy</span>

										{ //<!-- Title -->	
										}
										<h3 className="h3-lg">First page rankings. First name basis</h3>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-lg-6 order-last order-lg-2">
									<div className="txt-block slim-column left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">All-in-One Marketing Solutions</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">Strategy and Analytics Consulting</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- CB WRAPPER -->	
								}
								<div className="col-lg-6 order-first order-lg-2">
									<div className="cb-wrapper">

										{ //<!-- CB HOLDER -->	
										}
										<div className="cb-holder wow fadeInLeft">

											{ //<!-- CB BOX #1 -->	
											}
											<div className="cb-single-box">
												<p className="p-lg cb-header">New Customers</p>
												<h2 className="h2-title-xs statistic-number"><sup>+</sup><span className="count-element">784</span></h2>
												<p className="p-md mt-5 ico-10">
													<span className="skyblue-color"><span className="flaticon-"></span> 4.6%</span> vs last 7 days
												</p>
											</div>

											<hr className="divider" />

											{ //<!-- CB BOX #2 -->	
											}
											<div className="cb-single-box">
												<ul className="simple-list">
													<li className="list-item">
														<p className="p-md">Fringilla risus luctus mauris auctor and purus euismod purus</p>
													</li>

													<li className="list-item">
														<p className="p-md">Nemo ipsam volute turpis dolores ut quaerat sodales sapien</p>
													</li>
												</ul>
											</div>

											{ //<!-- CB BOX #3 -->	
											}
											<div className="cb-single-box cb-box-rounded bg-stateblue white-color mt-25">
												<h4 className="h4-lg">98.245</h4>
												<p className="p-lg">Ligula risus auctor tempus</p>
											</div>

										</div>	{ //<!-- END CB HOLDER -->	
										}


										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-1">
											<img className="img-fluid" src="images/bg-shape-1.png" alt="content-image" />
										</div>

										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-2">
											<img className="img-fluid" src="images/bg-shape-2.png" alt="content-image" />
										</div>


									</div>
								</div>	{ //<!-- END CB WRAPPER -->	
								}


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}



				<Reviews1 />


				{ //<!-- CONTENT-2A

				}
				<section id="content-2a" className="content-2 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column wow fadeInRight">
									<img className="img-fluid" src="images/seo-02.png" alt="content-image" />
								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Ultimate solution to website traffic</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
													magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
													quaerat at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2A -->	
				}





				<hr className="divider" />




				<Statistic4 />





				<hr className="divider" />




				{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 wide-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Section ID -->	
									}
									<span className="section-id txt-upcase">Your road to success</span>

									{ //<!-- Title -->	
									}
									<h3 className="h3-xl">Our SEO services will help you to dominate the search engines</h3>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center video-preview">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-skyblue ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/seo-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10 -->	
				}




				<Brands />




				{ //<!-- PRICING-3

				}
				<section id="pricing-3" className="bg-whitesmoke wide-60 pricing-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-80">

									{ //<!-- Title -->	
									}
									<h2 className="h2-sm">Simple And Flexible Pricing</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PRICING TABLES -->	
						}
						<div className="pricing-3-row pc-20">
							<div className="row row-cols-1 row-cols-md-3">


								{ //<!-- STARTER PLAN -->	
								}
								<div className="col">
									<div className="pricing-3-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan">
											<h6 className="h6-md">SEO Starter</h6>
											<sup className="dark-color">$</sup>
											<span className="price dark-color">8</span>
											<sup className="coins dark-color">99</sup>
											<p className="p-lg">Monthly Payment</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md">10 Analytics Campaign</p></li>
											<li><p className="p-md"><span>800 Change Keywords</span></p></li>
											<li><p className="p-md"><span>3 Free Optimization</span></p></li>
											<li><p className="p-md"><span>25 Social Media Reviews</span></p></li>
											<li><p className="p-md">Upgrate Options</p></li>
											<li><p className="p-md">Extra Features</p></li>
											<li><p className="p-md">12/5 Free Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-tra-grey tra-skyblue-hover">Get Started</a>

									</div>
								</div>	{ //<!-- END STARTER PLAN -->	
								}


								{ //<!-- BASIC PLAN -->	
								}
								<div className="col">
									<div className="pricing-3-table bg-white rel mb-40 wow fadeInUp">

										{ //<!-- Hightlight Badge -->	
										}
										<div className="badge-wrapper">
											<div className="highlight-badge bg-skyblue white-color">
												<h6 className="h6-md">Most Popular</h6>
											</div>
										</div>

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan">
											<h6 className="h6-md">SEO Basic</h6>
											<sup className="dark-color">$</sup>
											<span className="price dark-color">16</span>
											<sup className="coins dark-color">99</sup>
											<p className="p-lg">Monthly Payment</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md">20 Analytics Campaign</p></li>
											<li><p className="p-md"><span>1,200 Change Keywords</span></p></li>
											<li><p className="p-md"><span>15 Optimization</span></p></li>
											<li><p className="p-md"><span>1K Social Media Reviews</span></p></li>
											<li><p className="p-md">Upgrate Options</p></li>
											<li><p className="p-md">Extra Features</p></li>
											<li><p className="p-md">12/7 Free Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-skyblue tra-grey-hover">Get Started</a>

									</div>
								</div>	{ //<!-- END BASIC PLAN -->	
								}


								{ //<!-- PREMIUM PLAN -->	
								}
								<div className="col">
									<div className="pricing-3-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan">
											<h6 className="h6-md">SEO Premium</h6>
											<sup className="dark-color">$</sup>
											<span className="price dark-color">39</span>
											<sup className="coins dark-color">99</sup>
											<p className="p-lg">Monthly Payment</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md">Unlimited Analytics Campaign</p></li>
											<li><p className="p-md"><span>Unlimited Change Keywords</span></p></li>
											<li><p className="p-md"><span>Unlimited Optimization</span></p></li>
											<li><p className="p-md"><span>5K Social Media Reviews</span></p></li>
											<li><p className="p-md">Upgrate Options</p></li>
											<li><p className="p-md">Extra Features</p></li>
											<li><p className="p-md">24/7 Free Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-tra-grey tra-skyblue-hover">Get Started</a>

									</div>
								</div>	{ //<!-- END PREMIUM PLAN -->	
								}


							</div>
						</div>	{ //<!-- END PRICING TABLES -->	
						}


						{ //<!-- PRICING NOTICE TEXT -->	
						}
						<div className="row">
							<div className="col-lg-10 offset-lg-1">
								<div className="pricing-notice text-center mb-40">
									<p className="p-md">The above prices do not include applicable taxes based on your billing address.
										The final price will be displayed on the checkout page, before the payment is completed
									</p>
								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PRICING-3 -->	
				}


				{ //<!-- CONTENT-1

				}
				<section id="content-1" className="content-1 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInRight">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Scale your business to the next level</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
													magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
													quaerat at sodales sapien purus
												</p>
											</li>

										</ul>

									</div>	{ //<!-- END TEXT BOX -->	
									}

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6 order-first order-md-2">
								<div className="rel img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/seo-05.png" alt="content-image" />
								</div>
							</div>


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-1 -->	
				}
				<Faq2 />
				<TrialLink />
				<Footer1 mainCssClass="bg-lightgrey footer division" />
			</div>
		</React.Fragment>
	)
}
