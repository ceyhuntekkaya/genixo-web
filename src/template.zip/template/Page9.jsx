import React from 'react'
import Journey from '../pages/Journey'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Features4 from './components/Features4'
import Features8 from './components/Features8'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import Reviews1 from './components/Reviews1'
import Statistic4 from './components/Statistic4'
import TrialLink from './components/TrialLink'
export default function Page9() {
	return (
		<React.Fragment>




			<div id="page" className="page">



				<Header mainCssClass="header tra-menu navbar-dark" />

			

				<Journey className="bg-fixed hero-section division"/>

			



<Features4/>


				{ //<!-- CONTENT-5

				}
				<section id="content-5" className="content-5 ws-wrapper content-section division">
					<div className="container">
						<div className="content-5-wrapper bg-whitesmoke">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block left-column wow fadeInRight">

										{ //<!-- Title -->	
										}
										<h3 className="h3-xl">We work towards your business goals</h3>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat sapien rutrum mauris auctor
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores ligula and aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>
									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block right-column wow fadeInLeft">
										<img className="img-fluid" src="images/img-14.png" alt="content-image" />
									</div>
								</div>


							</div>
						</div>    { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-5 -->	
				}




				{ //<!-- CONTENT-2

				}
				<section id="content-2" className="content-2 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-5 col-lg-6">
								<div className="rel img-block left-column video-preview wow fadeInRight">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-skyblue ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/img-15.png" alt="video-preview" />

								</div>
							</div>


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-7 col-lg-6">
								<div className="txt-block right-column wow fadeInLeft">

									{ //<!-- Title -->	
									}
									<h3 className="h3-xl">Work smarter with powerful features</h3>

									{ //<!-- List -->	
									}
									<ul className="simple-list">

										<li className="list-item">
											<p className="p-lg">Fringilla risus, luctus mauris orci auctor euismod iaculis luctus
												magna purus pretium ligula purus undo quaerat tempor sapien rutrum mauris quaerat ultrice
											</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Quaerat sodales sapien euismod purus blandit</p>
										</li>

										<li className="list-item">
											<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam
												quaerat at sodales sapien purus
											</p>
										</li>

									</ul>

								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


						</div>	   { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-2 -->	
				}




<Features8/>




				{ //<!-- CONTENT-7

				}
				<section id="content-7" className="content-7 bg-whitesmoke wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 order-last order-md-2">
								<div className="txt-block left-column wow fadeInLeft">

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box mb-25">

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Advanced Analytics Review</h5>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
											cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
											volute and turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>

									{ //<!-- TEXT BOX -->	
									}
									<div className="txt-box">

										{ //<!-- Title -->	
										}
										<h5 className="h5-md">Search Engine Optimization (SEO)</h5>

										{ //<!-- List -->	
										}
										<ul className="simple-list">

											<li className="list-item">
												<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
													magna purus pretium ligula purus and quaerat
												</p>
											</li>

											<li className="list-item">
												<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
													at sodales sapien purus
												</p>
											</li>

										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#faqs-2" className="btn btn-skyblue tra-grey-hover">Read The FAQs</a>

									</div>	{ //<!-- END TEXT BOX -->	
									}


								</div>
							</div>	{ //<!-- END TEXT BLOCK -->	
							}


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 order-first order-md-2">
								<div className="content-7-img wow fadeInRight">
									<img className="img-fluid" src="images/dashboard-01.png" alt="content-image" />
								</div>
							</div>


						</div>	  { //<!-- End row -->	
						}
					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-7 -->	
				}




				{ //<!-- CONTENT-3

				}
				<section id="content-3" className="content-3 wide-60 content-section division">
					<div className="container">


						{ //<!-- TOP ROW -->	
						}
						<div className="top-row pb-50">
							<div className="row d-flex align-items-center">


								{ //<!-- IMAGE BLOCK -->	
								}
								<div className="col-md-5 col-lg-6">
									<div className="img-block left-column wow fadeInRight">
										<img className="img-fluid" src="images/img-17.png" alt="content-image" />
									</div>
								</div>


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-md-7 col-lg-6">
									<div className="txt-block right-column wow fadeInLeft">

										{ //<!-- Title -->	
										}
										<h3 className="h3-xl">Committed to top quality and results</h3>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit purus a purus ipsum primis in cubilia
											laoreet augue luctus magna dolor luctus and egestas sapien egestas vitae nemo volute
										</p>

										{ //<!-- Text -->	
										}
										<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and cubilia
											laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas volute and
											turpis dolores aliquam quaerat sodales a sapien
										</p>

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


							</div>
						</div>	{ //<!-- END TOP ROW -->	
						}


						{ //<!-- BOTTOM ROW -->	
						}
						<div className="bottom-row">
							<div className="row d-flex align-items-center">


								{ //<!-- TEXT BLOCK -->	
								}
								<div className="col-lg-6 order-last order-lg-2">
									<div className="txt-block slim-column left-column wow fadeInRight">

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box mb-20">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">All-in-One Marketing Solutions</h5>

											{ //<!-- Text -->	
											}
											<p className="p-lg">Quaerat sodales sapien euismod blandit at vitae ipsum primis undo and
												cubilia laoreet augue and luctus magna dolor luctus at egestas sapien vitae nemo egestas
												volute and turpis dolores aliquam quaerat sodales a sapien
											</p>

										</div>

										{ //<!-- TEXT BOX -->	
										}
										<div className="txt-box">

											{ //<!-- Title -->	
											}
											<h5 className="h5-md">Strategy and Analytics Consulting</h5>

											{ //<!-- List -->	
											}
											<ul className="simple-list">

												<li className="list-item">
													<p className="p-lg">Fringilla risus, luctus mauris auctor euismod an iaculis luctus
														magna purus pretium ligula purus and quaerat
													</p>
												</li>

												<li className="list-item">
													<p className="p-lg">Nemo ipsam egestas volute turpis dolores undo ultrice aliquam quaerat
														at sodales sapien purus
													</p>
												</li>

											</ul>

										</div>	{ //<!-- END TEXT BOX -->	
										}

									</div>
								</div>	{ //<!-- END TEXT BLOCK -->	
								}


								{ //<!-- CB WRAPPER -->	
								}
								<div className="col-lg-6 order-first order-lg-2">
									<div className="cb-wrapper">

										{ //<!-- CB HOLDER -->	
										}
										<div className="cb-holder wow fadeInLeft">

											{ //<!-- CB BOX #1 -->	
											}
											<div className="cb-single-box">
												<p className="p-lg cb-header">New Customers</p>
												<h2 className="h2-title-xs statistic-number"><sup>+</sup><span className="count-element">784</span></h2>
												<p className="p-md mt-5 ico-10">
													<span className="skyblue-color"><span className="flaticon-"></span> 4.6%</span> vs last 7 days
												</p>
											</div>

											<hr className="divider" />

											{ //<!-- CB BOX #2 -->	
											}
											<div className="cb-single-box">
												<ul className="simple-list">
													<li className="list-item">
														<p className="p-md">Fringilla risus luctus mauris auctor and purus euismod purus</p>
													</li>

													<li className="list-item">
														<p className="p-md">Nemo ipsam volute turpis dolores ut quaerat sodales sapien</p>
													</li>
												</ul>
											</div>

											{ //<!-- CB BOX #3 -->	
											}
											<div className="cb-single-box cb-box-rounded bg-stateblue white-color mt-25">
												<h4 className="h4-lg">98.245</h4>
												<p className="p-lg">Ligula risus auctor tempus</p>
											</div>

										</div>	{ //<!-- END CB HOLDER -->	
										}

										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-1">
											<img className="img-fluid" src="images/bg-shape-1.png" alt="content-image" />
										</div>

										{ //<!-- CB SHAPE -->	
										}
										<div className="cb-shape-2">
											<img className="img-fluid" src="images/bg-shape-2.png" alt="content-image" />
										</div>

									</div>
								</div>	{ //<!-- END CB WRAPPER -->	
								}


							</div>
						</div>	{ //<!-- END BOTTOM ROW -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-3 -->	
				}




				{ //<!-- CONTENT-10

				}
				<section id="content-10" className="content-10 pb-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">

									{ //<!-- Title -->	
									}
									<h3 className="h3-xl">Get more sales with SEO, PPC, and Email Marketing</h3>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque at dolor primis libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center wow fadeInUp">
									<img className="img-fluid" src="images/startup.png" alt="content-image" />
								</div>
							</div>
						</div>


						{ //<!-- ACTION BUTTON -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-10-btn">

									{ //<!-- Button -->	
									}
									<a href="https://www.youtube.com/watch?v=7e90gBu4pas" className="video-popup2 btn btn-md btn-skyblue tra-grey-hover ico-15 ico-left"><span className="flaticon-play"></span> See OLMO in Action</a>

									{ //<!-- Advantages List -->	
									}
									<ul className="advantages mt-25 clearfix">
										<li className="first-li"><p>Free 30 days trial</p></li>
										<li><p>Exclusive Support</p></li>
										<li className="last-li"><p>No Fees</p></li>
									</ul>

								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10 -->	
				}




<Reviews1/>




<Brands/>




				{ //<!-- CONTENT-6

				}
				<section id="content-6" className="content-6 bg-03 wide-60 content-section division">
					<div className="container">
						<div className="row d-flex align-items-center">


							{ //<!-- TEXT BLOCK -->	
							}
							<div className="col-md-6 col-lg-5">
								<div className="txt-block left-column white-color wow fadeInRight">

									{ //<!-- Title -->	
									}
									<h3 className="h3-xl">One brilliant idea for every client</h3>

									{ //<!-- Text -->	
									}
									<p className="p-lg">Aliqum  mullam blandit tempor sapien gravida at donec ipsum porta justo. Velna
										vitae auctor and congue magna impedit luctus dolor volute
									</p>

									{ //<!-- Button -->	
									}
									<a href="#pricing-3" className="btn btn-skyblue tra-white-hover">Let's Get Started</a>

								</div>
							</div>


							{ //<!-- IMAGE BLOCK -->	
							}
							<div className="col-md-6 col-lg-7">
								<div className="img-block right-column wow fadeInLeft">
									<img className="img-fluid" src="images/img-20.png" alt="content-image" />
								</div>
							</div>


						</div>     { //<!-- End row -->	
						}
					</div>      { //<!-- End container -->	
					}
				</section>	 { //<!-- END CONTENT-6 -->	
				}




				{ //<!-- CONTENT-10A

				}
				<section id="content-10a" className="content-10 wide-100 content-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-60">
									<h3 className="h3-xl">Our SEO services will help you to dominate the search engines</h3>
								</div>
							</div>
						</div>


						{ //<!-- IMAGE BLOCK -->	
						}
						<div className="row">
							<div className="col">
								<div className="img-block text-center video-preview">

									{ //<!-- Play Icon -->	
									}
									<a className="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">
										<div className="video-btn video-btn-xl bg-skyblue ico-90">
											<div className="video-block-wrapper"><span className="flaticon-play-button"></span></div>
										</div>
									</a>

									{ //<!-- Preview Image -->	
									}
									<img className="img-fluid" src="images/seo-07.png" alt="video-preview" />

								</div>
							</div>
						</div>


						{ //<!-- ADVANTAGES LIST -->	
						}
						<div className="row">
							<div className="col">
								<div className="content-10-btn">
									<ul className="advantages mt-25 clearfix">
										<li className="first-li"><p>Free 30 days trial</p></li>
										<li><p>Exclusive Support</p></li>
										<li className="last-li"><p>No Fees</p></li>
									</ul>
								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END CONTENT-10A -->	
				}




				
				<hr className="divider" />




				<Statistic4/>




				
				<hr className="divider" />




			<Faq2/>




				{ //<!-- PRICING-3

				}
				<section id="pricing-3" className="bg-whitesmoke wide-60 pricing-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-85">
									<h3 className="h3-xl">Scale your business to the next level with our experts</h3>
								</div>
							</div>
						</div>


						{ //<!-- PRICING TABLES -->	
						}
						<div className="pricing-3-row pc-20">
							<div className="row row-cols-1 row-cols-md-3">


								{ //<!-- STARTER PLAN -->	
								}
								<div className="col">
									<div className="pricing-3-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan">
											<h6 className="h6-md">SEO Starter</h6>
											<sup className="dark-color">$</sup>
											<span className="price dark-color">8</span>
											<sup className="coins dark-color">99</sup>
											<p className="p-lg">Monthly Payment</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md">10 Analytics Campaign</p></li>
											<li><p className="p-md"><span>800 Change Keywords</span></p></li>
											<li><p className="p-md"><span>3 Free Optimization</span></p></li>
											<li><p className="p-md"><span>25 Social Media Reviews</span></p></li>
											<li><p className="p-md">Upgrate Options</p></li>
											<li><p className="p-md">Extra Features</p></li>
											<li><p className="p-md">12/5 Free Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-tra-grey tra-skyblue-hover">Get Started</a>

									</div>
								</div>	{ //<!-- END STARTER PLAN -->	
								}


								{ //<!-- BASIC PLAN -->	
								}
								<div className="col">
									<div className="pricing-3-table bg-white rel mb-40 wow fadeInUp">

										{ //<!-- Hightlight Badge -->	
										}
										<div className="badge-wrapper">
											<div className="highlight-badge bg-skyblue white-color">
												<h6 className="h6-md">Most Popular</h6>
											</div>
										</div>

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan">
											<h6 className="h6-md">SEO Basic</h6>
											<sup className="dark-color">$</sup>
											<span className="price dark-color">16</span>
											<sup className="coins dark-color">99</sup>
											<p className="p-lg">Monthly Payment</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md">20 Analytics Campaign</p></li>
											<li><p className="p-md"><span>1,200 Change Keywords</span></p></li>
											<li><p className="p-md"><span>15 Optimization</span></p></li>
											<li><p className="p-md"><span>1K Social Media Reviews</span></p></li>
											<li><p className="p-md">Upgrate Options</p></li>
											<li><p className="p-md">Extra Features</p></li>
											<li><p className="p-md">12/7 Free Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-skyblue tra-grey-hover">Get Started</a>

									</div>
								</div>	{ //<!-- END BASIC PLAN -->	
								}


								{ //<!-- PREMIUM PLAN -->	
								}
								<div className="col">
									<div className="pricing-3-table bg-white mb-40 wow fadeInUp">

										{ //<!-- Plan Price  -->	
										}
										<div className="pricing-plan">
											<h6 className="h6-md">SEO Premium</h6>
											<sup className="dark-color">$</sup>
											<span className="price dark-color">39</span>
											<sup className="coins dark-color">99</sup>
											<p className="p-lg">Monthly Payment</p>
										</div>

										{ //<!-- Plan Features  -->	
										}
										<ul className="features">
											<li><p className="p-md">Unlimited Analytics Campaign</p></li>
											<li><p className="p-md"><span>Unlimited Change Keywords</span></p></li>
											<li><p className="p-md"><span>Unlimited Optimization</span></p></li>
											<li><p className="p-md"><span>5K Social Media Reviews</span></p></li>
											<li><p className="p-md">Upgrate Options</p></li>
											<li><p className="p-md">Extra Features</p></li>
											<li><p className="p-md">24/7 Free Support</p></li>
										</ul>

										{ //<!-- Pricing Plan Button -->	
										}
										<a href="#" className="btn btn-tra-grey tra-skyblue-hover">Get Started</a>

									</div>
								</div>	{ //<!-- END PREMIUM PLAN -->	
								}


							</div>
						</div>	{ //<!-- END PRICING TABLES -->	
						}


						{ //<!-- PRICING NOTICE TEXT -->	
						}
						<div className="row">
							<div className="col-lg-10 offset-lg-1">
								<div className="pricing-notice text-center mb-40">
									<p className="p-md">The above prices do not include applicable taxes based on your billing address.
										The final price will be displayed on the checkout page, before the payment is completed
									</p>
								</div>
							</div>
						</div>


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PRICING-3 -->	
				}




<TrialLink/>



				<Footer1 mainCssClass="footer division" />





			</div>
		</React.Fragment>
	)
}
