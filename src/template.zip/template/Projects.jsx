import React from 'react'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import TrialLink from './components/TrialLink'
export default function Projects() {
	return (
		<React.Fragment>

			<div id="page" className="page">


				<Header mainCssClass="header tra-menu navbar-dark" />





				{ //<!-- PROJECTS-1

				}
				<section id="projects-1" className="wide-50 inner-page-hero projects-section division">
					<div className="container">


						{ //<!-- SECTION TITLE -->	
						}
						<div className="row justify-content-center">
							<div className="col-lg-10 col-xl-8">
								<div className="section-title title-01 mb-80">

									{ //<!-- Title -->	
									}
									<h2 className="h2-md">We Care About The Details</h2>

									{ //<!-- Text -->	
									}
									<p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
										tempus, blandit and cursus varius and magnis sapien
									</p>

								</div>
							</div>
						</div>


						{ //<!-- PROJECTS-1 WRAPPER -->	
						}
						<div className="row">
							<div className="col gallery-items-list">
								<div className="masonry-wrap grid-loaded">


									{ //<!-- PROJECT #1 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-05.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Graphic Design</p>

											{ //<!-- Link -->	
											}
											<h5 className="h5-lg">
												<a href="project-details.html">A ligula risus auctor and justo tempus blandit</a>
											</h5>

											{ //<!-- Project Rating -->	
											}
											<div className="project-rating clearfix ico-20">
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-half-empty mr-5"></span>
												4.69 (173)
											</div>

										</div>

									</div>	{ //<!-- END PROJECT #1 -->	
									}


									{ //<!-- PROJECT #2 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-02.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

											{ //<!-- Link -->	
											}
											<h5 className="h5-lg">
												<a href="project-details.html">Integer urna turpis donec and ipsum porta justo</a>
											</h5>

											{ //<!-- Project Rating -->	
											}
											<div className="project-rating clearfix ico-20">
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1 mr-5"></span>
												5.0 (48)
											</div>

										</div>

									</div>	{ //<!-- END PROJECT #2 -->	
									}


									{ //<!-- PROJECT #3 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-04.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UX, Illustration</p>

											{ //<!-- Link -->	
											}
											<h5 className="h5-lg">
												<a href="project-details.html">Donec sapien augue integer turpis urna cursus porta</a>
											</h5>

											{ //<!-- Project Rating -->	
											}
											<div className="project-rating clearfix ico-20">
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-half-empty mr-5"></span>
												4.39 (87)
											</div>

										</div>

									</div>	{ //<!-- END PROJECT #3 -->	
									}


									{ //<!-- PROJECT #4 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-03.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">Web Design</p>

											{ //<!-- Link -->	
											}
											<h5 className="h5-lg">
												<a href="project-details.html">Donec sapien an augue integer turpis cursus</a>
											</h5>

											{ //<!-- Project Rating -->	
											}
											<div className="project-rating clearfix ico-20">
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-half-empty mr-5"></span>
												4.87 (284)
											</div>

										</div>

									</div>	{ //<!-- END PROJECT #4 -->	
									}


									{ //<!-- PROJECT #2 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-06.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

											{ //<!-- Link -->	
											}
											<h5 className="h5-lg">
												<a href="project-details.html">Integer urna turpis donec and ipsum porta justo</a>
											</h5>

											{ //<!-- Project Rating -->	
											}
											<div className="project-rating clearfix ico-20">
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-half-empty mr-5"></span>
												4.87 (68)
											</div>

										</div>

									</div>	{ //<!-- END PROJECT #2 -->	
									}


									{ //<!-- PROJECT #2 -->	
									}
									<div className="project-details masonry-image">

										{ //<!-- Image -->	
										}
										<div className="project-preview rel">
											<div className="hover-overlay">
												<img className="img-fluid" src="images/projects/project-07.jpg" alt="project-preview" />
												<div className="item-overlay"></div>
											</div>
										</div>

										{ //<!-- Text -->	
										}
										<div className="project-txt">

											{ //<!-- Text -->	
											}
											<p className="p-md grey-color">UI, Interaction Design</p>

											{ //<!-- Link -->	
											}
											<h5 className="h5-lg">
												<a href="project-details.html">Integer urna turpis donec and ipsum porta justo</a>
											</h5>

											{ //<!-- Project Rating -->	
											}
											<div className="project-rating clearfix ico-20">
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-1"></span>
												<span className="flaticon-star-half-empty mr-5"></span>
												4.53 (70)
											</div>

										</div>

									</div>	{ //<!-- END PROJECT #2 -->	
									}


								</div>
							</div>
						</div>	{ //<!-- END PROJECTS-1 WRAPPER -->	
						}


					</div>	   { //<!-- End container -->	
					}
				</section>	{ //<!-- END PROJECTS-1 -->	
				}




				{ //<!-- PAGE PAGINATION

				}
				<div className="pb-100 page-pagination division">
					<div className="container">
						<div className="row">
							<div className="col-md-12">
								<nav aria-label="Page navigation example">
									<ul className="pagination ico-20 justify-content-center">
										<li className="page-item disabled">
											<a className="page-link" href="#" tabindex="-1">
												<span className="flaticon-back"></span>
											</a>
										</li>
										<li className="page-item active" aria-current="page"><a className="page-link" href="#">1</a></li>
										<li className="page-item"><a className="page-link" href="#">2</a></li>
										<li className="page-item"><a className="page-link" href="#">3</a></li>
										<li className="page-item">
											<a className="page-link" href="#" aria-label="Next">
												<span className="flaticon-next"></span>
											</a>
										</li>
									</ul>
								</nav>
							</div>
						</div>  { //<!-- End row -->	
						}
					</div> { //<!-- End container -->	
					}
				</div>	{ //<!-- END PAGE PAGINATION -->	
				}




				<TrialLink/>


				<Footer1 mainCssClass="bg-lightgrey footer division" />







			</div>
		</React.Fragment>
	)
}
