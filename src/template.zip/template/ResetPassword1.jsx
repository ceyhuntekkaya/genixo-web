import React from 'react'
export default function ResetPassword1() {
	return (
		<React.Fragment>
			<div id="page" className="page">
				<section id="reset-password-1" className="reset-password-section division">
					<div className="container">
						<div className="row">
							<div className="col-md-8 col-lg-6 offset-md-2 offset-lg-3">
								<div className="login-page-logo">
									<img className="img-fluid" src="images/logo-01.png" alt="logo-image" />
								</div>
								<div className="register-form">
									<form name="resetpasswordform" className="row reset-password-form">
										<div className="col-md-12">
											<div className="register-form-title text-center">
												<h4 className="h4-xl">Forgot your password?</h4>
												<p className="p-md">Enter your email address, if an account exists we‘ll send you a link
													to reset your password.
												</p>
											</div>
										</div>
										<div className="col-md-12 text-center">
											<input className="form-control email" type="email" name="email" placeholder="Enter Your Email" />
										</div>
										<div className="col-md-12">
											<button type="submit" className="btn btn-md btn-skyblue tra-black-hover submit">Reset My Password</button>
										</div>
										<div className="col-md-12">
											<div className="form-data text-center">
												<p className="forgot-password"><a href="login-1.html">Never mind, I remembered!</a></p>
											</div>
										</div>
										<div className="col-lg-12 reset-form-msg">
											<span className="loading"></span>
										</div>
									</form>
								</div>	
								<div className="sign-in-footer text-center">
									<p>Copyright 2021 OLMO. All Rights Reserved</p>
								</div>
							</div>
						</div>	  
					</div>	   
				</section>	
			</div>	
		</React.Fragment>
	)
}
