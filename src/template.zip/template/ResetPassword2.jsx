import React from 'react'
import Footer1 from './components/Footer1'
import Header from './components/Header'
export default function ResetPassword2() {
	return (
		<React.Fragment>
			<div id="page" className="page">
				<Header mainCssClass="header tra-menu navbar-dark reg-nav" />
				<section id="reset-password-2" className="reset-password-section division">
					<div className="container">
						<div className="row">
							<div className="col-md-6 col-lg-7">
								<div className="reset-password-img text-center">
									<img className="img-fluid" src="images/reset-password.png" alt="reset-password-image" />
								</div>
							</div>
							<div className="col-md-6 col-lg-5">
								<div className="register-form">
									<form name="resetpasswordform" className="row reset-password-form">
										<div className="col-md-12">
											<div className="register-form-title text-center">
												<h4 className="h4-xs">Forgot your password?</h4>
												<p className="p-md">Enter your email address, if an account exists we‘ll send you a link
													to reset your password.
												</p>
											</div>
										</div>
										<div className="col-md-12">
											<input className="form-control email" type="text" name="email" placeholder="Enter Your Email" />
										</div>
										<div className="col-md-12">
											<button type="submit" className="btn btn-md btn-skyblue tra-black-hover submit">Reset My Password</button>
										</div>
										<div className="col-md-12">
											<div className="d-flex justify-content-around align-items-center form-data">
												<p className="forgot-password"><a href="login-2.html">Never mind, I remembered!</a></p>
											</div>
										</div>
										<div className="col-lg-12 reset-form-msg">
											<span className="loading"></span>
										</div>
									</form>
								</div>	
								<div className="sign-in-footer text-center">
									<p>Copyright 2021 OLMO. All Rights Reserved</p>
								</div>
							</div>	
						</div>	  
					</div>	  
				</section>	
			</div>
		</React.Fragment>
	)
}
