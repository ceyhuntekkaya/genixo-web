import React from 'react'
const lang = require('../data/pages.json')


export default function SingUpBoxed() {
	return (
		<React.Fragment>
			<div id="page" className="page">
				<section id="signup-2" className="signup-section division">
					<div className="container">
						<div className="row">
							<div className="col-md-8 col-lg-6 offset-md-2 offset-lg-3">
								<div className="login-page-logo">
									<img className="img-fluid" src={lang.login.logo} alt="logo-image" />
								</div>
								<div className="register-form">
									<form name="signupform" className="row sign-up-form">
										<div className="col-md-12">
											<div className="register-form-title text-center">
												<h4 className="h4-lg">{lang.login.createAccountHeader}</h4>
												<p className="p-xl">{lang.login.createAccountExplain}</p>
											</div>
										</div>
										<div className="col-md-12">
											<input className="form-control name" type="text" name="name" placeholder={lang.login.name} />
										</div>
										<div className="col-md-12">
											<input className="form-control email" type="email" name="email" placeholder={lang.login.mail} />
										</div>
										<div className="col-md-12">
											<div className="wrap-input">
												<span className="btn-show-pass ico-20"><span className="flaticon-visible eye-pass"></span></span>
												<input className="form-control password" type="password" name="password" placeholder={lang.login.createPassword} />
											</div>
										</div>
										<div className="col-md-12">
											<button type="submit" className="btn btn-md btn-skyblue tra-black-hover submit">{lang.login.createAccountButton}</button>
										</div>
										<div className="col-md-12">
											<div className="form-data">
												<div className="form-check">
													<input type="checkbox" className="form-check-input" id="exampleCheck1" checked />
													<label className="form-check-label" for="exampleCheck1">
														<span>{lang.login.termsText}</span>
													</label>
												</div>
											</div>
										</div>
										<div className="col-md-12 text-center">
											<div className="login-separator">
												<span className="login-separator-txt">{lang.login.or}</span>
											</div>
										</div>
										<div className="col-md-12">
											<a href="#" className="btn btn-google ico-left mb-10">
												<img src="images/png-icons/google.png" alt="google-icon" /> {lang.login.GoogleSingUp}
											</a>
										</div>
										<div className="col-md-12">
											<a href="#" className="btn btn-facebook ico-left">
												<img src="images/png-icons/facebook.png" alt="google-icon" /> {lang.login.FacebookSingUp}
											</a>
										</div>
										<div className="col-md-12 text-center">
											<p className="create-account">
												Already have an account? <a href="login-2.html" className="skyblue-color">Log in</a>
											</p>
										</div>
									</form>
								</div>
								<div className="sign-in-footer text-center">
									<p>{lang.login.copyright}</p>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>
		</React.Fragment>
	)
}
