import React from 'react'
import Brands from './components/Brands'
import Faq2 from './components/Faq2'
import Header from './components/Header'
import Loading from './components/Loading'
import Reviews3 from './components/Reviews3'
import TrialLink from './components/TrialLink'
import Footer1 from './components/Footer1'

const teamMembers = require('../data/team.json')
const lang = require('../data/pages.json')

export default function Team() {

	return (
		<React.Fragment>
			<div id="page" className="page">
				<Header mainCssClass="header white-menu navbar-dark" />
				<section id="team-1" className="wide-50 inner-page-hero team-section division">
					<div className="container">
						<div className="row justify-content-center">
							<div className="col-md-10 col-lg-8">
								<div className="section-title title-02 mb-75">
									<span className="section-id txt-upcase">{lang.team.header}</span>
									<h2 className="h2-xs">{lang.team.explain}</h2>
								</div>
							</div>
						</div>
						<div className="team-members-wrapper text-center">
							<div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4">
								{
									teamMembers.teams.map((member, key) =>
										<div className="col" key={key}>
											<div className="team-member wow fadeInUp">
												<div className="team-member-photo">
													<img className="img-fluid" src={member.photo} alt="team-member-foto" />
												</div>
												<div className="team-member-data">
													<h5 className="h5-sm">{member.name}</h5>
													<p className="p-lg">{member.mission}</p>
													<p className="p-lg tm-social"><a href="#" className="text-secondary">{member.social}</a></p>
												</div>
											</div>
										</div>
									)
								}
							</div>
						</div>
					</div>
				</section>
				<Reviews3 />
				<Brands />
				<hr className="divider" />
				<Faq2 />
				<TrialLink />
				<Footer1 mainCssClass="bg-lightgrey footer division"/>
			</div>
		</React.Fragment>
	)
}
