import React from 'react'
import Footer1 from './components/Footer1'
import Header from './components/Header'
import TrialLink from './components/TrialLink'

const terms = require('../data/terms.json')
const lang = require('../data/pages.json')

export default function Terms() {
	return (
		<React.Fragment>
			<div id="page" className="page">
				<Header mainCssClass="header tra-menu navbar-dark" />
				<section id="terms-page" className="bg-snow wide-70 inner-page-hero terms-section division">
					<div className="container">
						<div className="row justify-content-center">
							<div className="col-lg-10">
								<div className="terms-title text-center">
									<h2 className="h2-md">{lang.terms.header}</h2>
									<p className="p-xl grey-color">{lang.terms.explain}</p>
								</div>

								<hr className="divider" />
								{
									terms.map((term, key) =>
										<div className="terms-box mt-60" key={key}>
											<h5 className="h5-xl">{term.question}</h5>
											<p className="p-lg">{term.reply}</p>
										</div>
									)
								}
							</div>
						</div>
					</div>
				</section>
				<TrialLink />
				<Footer1 mainCssClass="bg-snow footer division" />
			</div>
		</React.Fragment>
	)
}
