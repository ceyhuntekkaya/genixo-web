import React from 'react'

export default function Content5() {
    return (
        <section id="content-5" className="content-5 ws-wrapper content-section division">
            <div className="container">
                <div className="content-5-wrapper bg-whitesmoke">
                    <div className="row d-flex align-items-center">


                        <div className="col-md-7 col-lg-6">
                            <div className="txt-block left-column wow fadeInRight">

                                <div className="cbox mb-40">

                                    <div className="cbox-ico">
                                        <div className="orange-red-color ico-65">
                                            <span className="flaticon-speech-bubble-2"></span>
                                        </div>
                                    </div>

                                    <div className="cbox-txt">
                                        <h5 className="h5-md">Text, Voice & Video Calls</h5>
                                        <p className="p-lg">Ligula risus auctor tempus dolor feugiat undo lacinia purus lipsum
                                            quaerat primis ultrice tellus and viverra purus suscipit
                                        </p>
                                    </div>

                                </div>

                                <div className="cbox mb-40">

                                    <div className="cbox-ico">
                                        <div className="orange-red-color ico-65">
                                            <span className="flaticon-tongue"></span>
                                        </div>
                                    </div>

                                    <div className="cbox-txt">
                                        <h5 className="h5-md">Stickers, Emojis, Themes</h5>
                                        <p className="p-lg">Ligula risus auctor tempus dolor feugiat undo lacinia purus lipsum
                                            quaerat primis ultrice tellus and viverra purus suscipit
                                        </p>
                                    </div>

                                </div>

                                <div className="cbox mb-40">

                                    <div className="cbox-ico">
                                        <div className="orange-red-color ico-65">
                                            <span className="flaticon-shield-2"></span>
                                        </div>
                                    </div>

                                    <div className="cbox-txt">
                                        <h5 className="h5-md">Spam Protection</h5>
                                        <p className="p-lg">Ligula risus auctor tempus dolor feugiat undo lacinia purus lipsum
                                            quaerat primis ultrice tellus and viverra purus suscipit
                                        </p>
                                    </div>

                                </div>

                            </div>
                        </div>


                        <div className="col-md-5 col-lg-6">
                            <div className="img-block right-column wow fadeInLeft">
                                <img className="img-fluid" src="images/img-12.png" alt="content-image" />
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </section>
    )
}
