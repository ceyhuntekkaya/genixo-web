import React from 'react'
const faqs = require('../../data/faq.json')
const lang = require('../../data/pages.json')

export default function Faq2() {
    return (
        <section id="faqs-2" className="wide-60 faqs-section division">
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-lg-10 col-xl-8">
                        <div className="section-title title-01 mb-80">
                            <h2 className="h2-md">{lang.faq.header}</h2>
                            <p className="p-xl">{lang.faq.explain}</p>
                        </div>
                    </div>
                </div>
                <div className="faqs-2-questions">
                    <div className="row row-cols-1 row-cols-lg-2">
                        {
                            faqs.map((faq, key) =>
                                <div className="col" key={key}>
                                    <div className="questions-holder pr-15">
                                        {
                                            faq.faqs.map((f, key) =>
                                                <div className="question wow fadeInUp" key={key}>
                                                    <h5 className="h5-md">{f.question}</h5>
                                                    <p className="p-lg">{f.reply} </p>
                                                </div>
                                            )
                                        }
                                    </div>
                                </div>
                            )
                        }
                    </div>
                </div>
                <div className="row">
                    <div className="col">
                        <div className="more-questions">
                            <h5 className="h5-sm">{lang.faq.footer} <a href="contacts.html">{lang.faq.footerLink}</a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
