import React from 'react'

export default function Features4() {
    return (
        <section id="features-4" className="wide-60 features-section division">
            <div className="container">


                <div className="row justify-content-center">
                    <div className="col-lg-10 col-xl-8">
                        <div className="section-title title-01 mb-70">

                            <h2 className="h2-md">We’re Better. Here’s Why…</h2>

                            <p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
                                tempus, blandit and cursus varius and magnis sapien
                            </p>

                        </div>
                    </div>
                </div>


                <div className="fbox-4-wrapper">
                    <div className="row row-cols-1 row-cols-md-2">


                        <div className="col">
                            <div className="fbox-4 pc-25 mb-40 wow fadeInUp">

                                <div className="fbox-ico">
                                    <div className="ico-60 shape-ico violet-red-color">
                                        <img className="ico-bkg" src="images/ico-bkg.png" alt="ico-bkg" />
                                        <span className="flaticon-double-click"></span>
                                    </div>
                                </div>

                                <div className="fbox-txt">

                                    <h5 className="h5-md">Quick Access</h5>

                                    <p className="p-lg">Porta semper lacus cursus feugiat primis ultrice ligula risus at auctor
                                        tempus feugiat impedit felis undo auctor augue mauris
                                    </p>

                                </div>

                            </div>
                        </div>


                        <div className="col">
                            <div className="fbox-4 pc-25 mb-40 wow fadeInUp">

                                <div className="fbox-ico">
                                    <div className="ico-60 shape-ico violet-red-color">
                                        <img className="ico-bkg" src="images/ico-bkg.png" alt="ico-bkg" />
                                        <span className="flaticon-folder-3"></span>
                                    </div>
                                </div>

                                <div className="fbox-txt">

                                    <h5 className="h5-md">File Manager</h5>

                                    <p className="p-lg">Porta semper lacus cursus feugiat primis ultrice ligula risus at auctor
                                        tempus feugiat impedit felis undo auctor augue mauris
                                    </p>

                                </div>

                            </div>
                        </div>


                        <div className="col">
                            <div className="fbox-4 pc-25 mb-40 wow fadeInUp">

                                <div className="fbox-ico">
                                    <div className="ico-60 shape-ico violet-red-color">
                                        <img className="ico-bkg" src="images/ico-bkg.png" alt="ico-bkg" />
                                        <span className="flaticon-puzzle"></span>
                                    </div>
                                </div>

                                <div className="fbox-txt">

                                    <h5 className="h5-md">Convert Media Files</h5>

                                    <p className="p-lg">Porta semper lacus cursus feugiat primis ultrice ligula risus at auctor
                                        tempus feugiat impedit felis undo auctor augue mauris
                                    </p>

                                </div>

                            </div>
                        </div>


                        <div className="col">
                            <div className="fbox-4 pc-25 mb-40 wow fadeInUp">

                                <div className="fbox-ico">
                                    <div className="ico-60 shape-ico violet-red-color">
                                        <img className="ico-bkg" src="images/ico-bkg.png" alt="ico-bkg" />
                                        <span className="flaticon-share"></span>
                                    </div>
                                </div>

                                <div className="fbox-txt">

                                    <h5 className="h5-md">Files Sharing</h5>

                                    <p className="p-lg">Porta semper lacus cursus feugiat primis ultrice ligula risus at auctor
                                        tempus feugiat impedit felis undo auctor augue mauris
                                    </p>

                                </div>

                            </div>
                        </div>


                        <div className="col">
                            <div className="fbox-4 pc-25 mb-40 wow fadeInUp">

                                <div className="fbox-ico">
                                    <div className="ico-60 shape-ico violet-red-color">
                                        <img className="ico-bkg" src="images/ico-bkg.png" alt="ico-bkg"/>
                                            <span className="flaticon-server-1"></span>
                                    </div>
                                </div>

                                <div className="fbox-txt">

                                    <h5 className="h5-md">Storage & Backup</h5>

                                    <p className="p-lg">Porta semper lacus cursus feugiat primis ultrice ligula risus at auctor
                                        tempus feugiat impedit felis undo auctor augue mauris
                                    </p>

                                </div>

                            </div>
                        </div>


                        <div className="col">
                            <div className="fbox-4 pc-25 mb-40 wow fadeInUp">

                                <div className="fbox-ico">
                                    <div className="ico-60 shape-ico violet-red-color">
                                        <img className="ico-bkg" src="images/ico-bkg.png" alt="ico-bkg" />
                                        <span className="flaticon-shield"></span>
                                    </div>
                                </div>

                                <div className="fbox-txt">

                                    <h5 className="h5-md">Spam Protection</h5>

                                    <p className="p-lg">Porta semper lacus cursus feugiat primis ultrice ligula risus at auctor
                                        tempus feugiat impedit felis undo auctor augue mauris
                                    </p>

                                </div>

                            </div>
                        </div>


                    </div>
                </div>


            </div>
        </section>
    )
}
