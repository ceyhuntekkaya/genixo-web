import React from 'react'

export default function Features8() {
    return (
        <section id="features-8" className="wide-60 features-section division">
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-lg-10 col-xl-8">
                        <div className="section-title title-01 mb-70">
                            <h2 className="h2-md">We’re Better. Here’s Why…</h2>
                            <p className="p-xl">Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis a libero
                                tempus, blandit and cursus varius and magnis sapien
                            </p>
                        </div>
                    </div>
                </div>
                <div className="fbox-8-wrapper text-center">
                    <div className="row row-cols-1 row-cols-md-3">
                        <div className="col">
                            <div className="fbox-8 mb-40 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-21.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Friendly Interface</h5>
                                <p className="p-lg">Feugiat primis ultrice semper lacus cursus feugiat undo primis ultrice a
                                    ligula an auctor tempus magnis
                                </p>
                            </div>
                        </div>
                        <div className="col">
                            <div className="fbox-8 mb-40 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-22.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Extremely Flexible</h5>
                                <p className="p-lg">Feugiat primis ultrice semper lacus cursus feugiat undo primis ultrice a
                                    ligula an auctor tempus magnis
                                </p>
                            </div>
                        </div>
                        <div className="col">
                            <div className="fbox-8 mb-40 wow fadeInUp">
                                <div className="fbox-img bg-whitesmoke-gradient">
                                    <img className="img-fluid" src="images/img-23.png" alt="feature-icon" />
                                </div>
                                <h5 className="h5-md">Strong Encryption</h5>
                                <p className="p-lg">Feugiat primis ultrice semper lacus cursus feugiat undo primis ultrice a
                                    ligula an auctor tempus magnis
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
