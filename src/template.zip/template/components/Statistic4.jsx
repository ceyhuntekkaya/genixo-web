import React from 'react'

export default function Statistic4() {
  return (
    <div id="statistic-4" className="pt-70 pb-70 statistic-section division">
    <div className="container">
        <div className="statistic-4-wrapper">
            <div className="row justify-content-md-center row-cols-1 row-cols-md-3">
                <div id="sb-4-1" className="col">
                    <div className="statistic-block pr-15 d-flex align-items-center wow fadeInUp">
                        <div className="statistic-block-digit">
                            <h2 className="h2-lg statistic-number"><span className="count-element">65</span>K</h2>
                        </div>
                        <div className="statistic-block-txt grey-color">
                            <h6 className="h6-md">Porta justo integer and velna vitae auctor</h6>
                        </div>

                    </div>
                </div>
                <div id="sb-4-2" className="col">
                    <div className="statistic-block pr-15 d-flex align-items-center wow fadeInUp">
                        <div className="statistic-block-digit">
                            <h2 className="h2-lg statistic-number"><span className="count-element">54</span>%</h2>
                        </div>
                        <div className="statistic-block-txt grey-color">
                            <h6 className="h6-md">Ligula magna suscipit vitae and rutrum</h6>
                        </div>

                    </div>
                </div>
                <div id="sb-4-3" className="col">
                    <div className="statistic-block pr-15 d-flex align-items-center wow fadeInUp">
                        <div className="statistic-block-digit">
                            <h2 className="h2-lg statistic-number">
                                <span className="count-element">4</span>.<span className="count-element">86</span>
                            </h2>
                        </div>
                        <div className="statistic-block-txt grey-color">
                            <h6 className="h6-md">Sagittis congue augue egestas an egestas</h6>
                        </div>

                    </div>
                </div>
            </div>
        </div>	
    </div>	
</div>
  )
}
